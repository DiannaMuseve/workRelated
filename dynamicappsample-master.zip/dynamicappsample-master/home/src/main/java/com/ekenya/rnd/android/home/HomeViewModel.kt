package com.ekenya.rnd.android.home

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.ekenya.rnd.android.common.models.NotificationItem
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.qss.beans.SsNotification
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers
import javax.inject.Inject

class HomeViewModel @Inject constructor(
    val app:Application,
    private val repo:IAppRepo
): AndroidViewModel(app) {
    val TAG = "HomeViewModel"
    public var service: MutableLiveData<EclecticsQssService>  = repo.getService()

    private val _alertListener = MutableLiveData<NotificationItem>()

    val alertObserver: LiveData<NotificationItem> get() = _alertListener

    init {

        service.observeForever(object : Observer<EclecticsQssService> {
            //
            override fun onChanged(eclecticsQssService: EclecticsQssService) {
                //
                eclecticsQssService.subscribeForNotifications()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : io.reactivex.functions.Consumer<SsNotification> {
                        @Throws(Exception::class)
                        override fun accept(alert: SsNotification) {
                            //
                            _alertListener.postValue(alert as NotificationItem)
                        }
                    })
                //Connect
                eclecticsQssService.connectQss(false).subscribe({
                    Log.i(TAG, "Connected ? $it")
                }, {
                    Log.i(TAG, "Connection Failed with $it.message")
                })
            }
        })
    }
}