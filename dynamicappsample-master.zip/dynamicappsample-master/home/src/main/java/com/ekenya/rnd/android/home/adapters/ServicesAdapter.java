package com.ekenya.rnd.android.home.adapters;

import android.content.Context;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ekenya.rnd.android.common.services.apputils.IAppUtils;
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader;
import com.ekenya.rnd.android.common.ui.adapters.GenericRecyclerAdapter;
import com.ekenya.rnd.android.home.R;
import com.ekenya.rnd.android.home.models.ServiceItem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

public class ServicesAdapter extends GenericRecyclerAdapter<ServiceItem> {
    private static final String TAG = ServicesAdapter.class.getSimpleName();

    @Inject
    public IImageLoader mImageLoader;

    @Inject
    public IAppUtils mAppUtils;

    public enum Orientation {
        VERTICAL,HORIZONTAL
    }

    @Override
    protected List<ServiceItem> getFilteredResults(String constraint) {
        List<ServiceItem> results = new ArrayList<>();
        for (ServiceItem item : mOriginalItems) {
            if (item.getName().toLowerCase().contains(constraint)) {
                results.add(item);
            }
        }
        return results;
    }


    public interface ServicesCallback {
        void onMenuClicked(View row, ServiceItem service, MenuItem menu);

        void onClick(View row, ServiceItem service);

        void onLongClick(View row, ServiceItem service);
    }

    private final LinkedList<ServicesCallback> mCallbacks = new LinkedList<>();

    private Orientation mMode = Orientation.VERTICAL;

    public void setMode(Orientation mode){
        mMode = mode;
    }
    public List<ServicesCallback> getCallbacks() {
        return mCallbacks;
    }

    @Inject
    public ServicesAdapter(Context context){
        super(context);
    }

    public ServicesAdapter(Context context, List<ServiceItem> items, Orientation mode) {
        super(context);
        //
        mMode = mode;
        mOriginalItems = items;
        mFilteredItems = mOriginalItems;

    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public long getItemId(int position) {
        //return mFilteredList.get(position).getId();
        return mFilteredItems.get(position).getId();
    }

    @Override
    public int getItemCount() {
        //Log.i(TAG, "Get count :; Returned  = " + mFilteredList.size());
        //
        //Sort descending by date
        Collections.sort(mFilteredItems, new Comparator<ServiceItem>() {
            @Override
            public int compare(ServiceItem lhs, ServiceItem rhs) {
                // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                return lhs.getId() > rhs.getId() ? -1 : (lhs.getId() < rhs.getId()) ? 1 : 0;
            }
        });
        //
        return mFilteredItems.size();
    }


    @Override
    public ServicesAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //
        View rootView = null;
        if(mMode == Orientation.VERTICAL)
            rootView = LayoutInflater.from(mContext).inflate(R.layout.service_row_item, parent, false);
        else//
            rootView = LayoutInflater.from(mContext).inflate(R.layout.service_row_item, parent, false);

        return new ViewHolder(rootView);
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int position) {
        //Log.d(TAG,"Get view at "+position);

        ServicesAdapter.ViewHolder holder = (ServicesAdapter.ViewHolder)h;
        //
        final ServiceItem item = mFilteredItems.get(position);
        //

        //
        holder.Name.setText(item.getName());
        //
        Animation spinAnimation = AnimationUtils.loadAnimation(mContext, com.ekenya.rnd.android.common.R.anim.spin_animation);
        Drawable loader = null;
        //
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                loader = ImageDecoder.decodeDrawable(ImageDecoder.createSource(mContext.getResources(), com.ekenya.rnd.android.common.R.drawable.loading));
            } catch (IOException e) {
                e.printStackTrace();
            }
            //
            if (loader != null && loader instanceof AnimatedImageDrawable) {
                ((AnimatedImageDrawable) loader).start();
            }
        }else{
            loader = mContext.getResources().getDrawable(com.ekenya.rnd.android.common.R.drawable.logo);
        }
        //
        mImageLoader.loadImage(item.getIconPath(),loader,holder.Image);
        //
//        holder.Options.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                //Creating the instance of PopupMenu
//                PopupMenu popup = new PopupMenu(mContext, v);
//                //Inflating the Popup using xml file
//                //popup.getMenuInflater().inflate(R.menu.building_menu, popup.getMenu());
//                //registering popup with OnMenuItemClickListener
//                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//                    public boolean onMenuItemClick(MenuItem menu) {
//                        for(ServicesCallback callback: mCallbacks)
//                            callback.onMenuClicked(holder.RootView,item,menu);
//                        return true;
//                    }
//                });
//                //
//                mAppUtils.showPopupMenuIcons(popup);
//                //
//                popup.show(); //showing popup menu
//            }
//        });
        //
        holder.RootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (ServicesCallback cb : mCallbacks)
                    cb.onClick(v, item);
            }
        });
        //
        holder.RootView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                for (ServicesCallback cb : mCallbacks)
                    cb.onLongClick(v, item);
                //
                return true;
            }

        });
    }

    @Override
    public void addAll(List<ServiceItem> items) {
        //Clear first
        mOriginalItems.clear();
        mFilteredItems.clear();
        //
        for (ServiceItem item : items) {
            //
            boolean added = false;
            //
            for (ServiceItem key : mOriginalItems) {
                //Found source
                if (key.getId() == item.getId()) {
                    added = true;
                    break;
                }
            }
            //
            if (!added) {
                mOriginalItems.add(item);
            }
        }
        //Apply any active filter
        getFilter().filter(currentFilterConstraint);
    }

    @Override
    public boolean addItem(ServiceItem item) {
        //All sources
        boolean added = false;
        //
        for (ServiceItem key : mOriginalItems) {
            //Found source
            if (key.getId() == item.getId()) {
                added = true;
                break;
            }
        }
        //
        if (!added) {
            mOriginalItems.add(item);
        }
        //Apply any active filter
        getFilter().filter(currentFilterConstraint);
        //
        return added;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView Image;
        public TextView Name;
        //
        public View RootView;

        public ViewHolder(final View root) {
            super(root);
            Name = (TextView) root.findViewById(R.id.tv_title);
            //
            RootView = root;
        }
    }
}
