package com.ekenya.rnd.android.home.ui.notifications

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.ekenya.rnd.android.common.abstractions.BaseBottomSheetDialogFragment
import com.ekenya.rnd.android.common.models.NotificationItem
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.ui.adapters.GenericRecyclerAdapter
import com.ekenya.rnd.android.home.HomeViewModel
import com.ekenya.rnd.android.home.adapters.NotificationsAdapter
import com.ekenya.rnd.android.home.databinding.HomeNotificationsFragmentBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import javax.inject.Inject


class NotificationsFragment : BaseBottomSheetDialogFragment() {

    companion object {
        fun newInstance() = NotificationsFragment()
    }
    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    @Inject
    lateinit var mAppRepo: IAppRepo
    @Inject
    lateinit var mAdapter: NotificationsAdapter

    private lateinit var mListView:RecyclerView

    private lateinit var mRefreshLayout:SwipeRefreshLayout

    private lateinit var mEmptyLayout:View

    private val mViewModel by lazy {
        ViewModelProviders.of(requireActivity(), viewModelFactory).get(NotificationsViewModel::class.java)
    }

    private val mHomeViewModel by lazy {
        ViewModelProviders.of(requireActivity(), viewModelFactory).get(HomeViewModel::class.java)
    }
    private var _binding: HomeNotificationsFragmentBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = HomeNotificationsFragmentBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //
        val wrapper: ViewGroup = binding.notificationsContent//root.findViewById<ViewGroup>(R.id.dashboard_content)

        //
        val listGroup: View = inflater.inflate(com.ekenya.rnd.android.common.R.layout.list_rv_item, container, false)
        mListView = listGroup.findViewById(com.ekenya.rnd.android.common.R.id.list)
        //
        val manager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
        mListView.layoutManager = manager
        //
        //
        val controller = AnimationUtils.loadLayoutAnimation(
            activity, com.ekenya.rnd.android.common.R.anim.layout_animation_fall_down
        )
        mListView.layoutAnimation = controller
        mListView.isNestedScrollingEnabled = false
//        mListView.setOnTouchListener(OnTouchListener { v, event ->
//            v.parent.requestDisallowInterceptTouchEvent(true)
//            v.onTouchEvent(event)
//            true
//        })
        mRefreshLayout = listGroup.findViewById<SwipeRefreshLayout>(com.ekenya.rnd.android.common.R.id.refresh)

        mEmptyLayout = listGroup.findViewById<View>(com.ekenya.rnd.android.common.R.id.empty_wrapper)
        val emptyCaption = listGroup.findViewById<View>(com.ekenya.rnd.android.common.R.id.empty_caption) as TextView
        //emptyCaption.setTextColor(getResources().getColor(android.R.color.white));
        emptyCaption.text = "No Alerts"
        wrapper.removeAllViews()
        //
        wrapper.addView(listGroup)

        return root
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        //
        (requireView().parent as View).setBackgroundColor(resources.getColor(android.R.color.transparent))
        //
        mHomeViewModel.alertObserver.observe(this){

            //
        }

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //
        mAdapter.setMode(GenericRecyclerAdapter.Orientation.VERTICAL)
        mAdapter.callbacks.add(object :
            NotificationsAdapter.NotificationsCallback{
            override fun onMenuClicked(row: View?, service: NotificationItem, menu: MenuItem?) {
                //
            }

            override fun onClick(row: View?, service: NotificationItem) {
                //
            }

            override fun onLongClick(row: View?, service: NotificationItem) {
                //
            }
        })
        mListView.adapter = mAdapter

        mRefreshLayout.setOnRefreshListener {
            updateContent()
        }
        updateContent()
        //
        binding.closeButton.setOnClickListener {

            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(BottomSheetDialogFragment.STYLE_NORMAL, com.ekenya.rnd.android.common.R.style.BottomSheetTheme)
        //
    }


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        //
        return dialog
    }

    private fun updateContent(){
        //
        mViewModel.alerts.observe(viewLifecycleOwner, Observer {list ->
            //
            mAdapter.addAll(list as List<NotificationItem>)
            //
            if(list.isEmpty()){
                mEmptyLayout.visibility = View.VISIBLE
            }else{
                mEmptyLayout.visibility = View.GONE
            }
            mRefreshLayout.isRefreshing = false

            //
            var new = list.filter { !it.isSeen }
            if(new.isNotEmpty()){
                //binding.tvTitle.text = String.format("%s\n%s",binding.tvTitle.text,"(${new.size} unread)")
                binding.tvTitle.text = String.format("%s %s",binding.tvTitle.text,"(${new.size} unread)")
            }
            //
            //mListView .getLayoutManager().scrollToPositionWithOffset(0, 0)
            mListView.layoutManager?.smoothScrollToPosition(mListView, null, 0)
        })
    }
}