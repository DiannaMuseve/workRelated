package com.ekenya.rnd.android.home.ui.dashboard

import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.home.models.ServiceItem
import javax.inject.Inject

class DashboardViewModel @Inject constructor(
): ViewModel() {
    //
    private val _userName = MutableLiveData<String>().apply {
        value = "Samir"
    }
    //
    private val _servicesList = MutableLiveData<List<ServiceItem>>().apply {
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            var list = ArrayList<ServiceItem>()
            //Buy Airtime
            val service1 = ServiceItem()
            service1.id = 1
            service1.name = "Buy Airtime"
            service1.code = "BUYAIRTIME"
            list.add(service1)
            //Funds Transfer
            val service2 = ServiceItem()
            service2.id = 2
            service2.name = "Funds Transfer"
            service2.code = "FT"
            list.add(service2)
            //PAY BILLS
            val service3 = ServiceItem()
            service3.id = 3
            service3.name = "Pay Bills"
            service3.code = "PAYBILLS"
            list.add(service3)
            //Loans
            val service4 = ServiceItem()
            service4.id = 4
            service4.name = "Loans"
            service4.code = "LOANS"
            list.add(service4)
            //Savings
            val service5 = ServiceItem()
            service5.id = 5
            service5.name = "Savings"
            service5.code = "SAVINGS"
            list.add(service5)
            //Accounts
            val service6 = ServiceItem()
            service6.id = 6
            service6.name = "My Accounts"
            service6.code = "BANKACCOUNT"
            list.add(service6)
            //Merchants
            val service7 = ServiceItem()
            service7.id = 7
            service7.name = "Pay Merchant"
            service7.code = "MERCHANT"
            list.add(service7)
            //Remittance
            val service8 = ServiceItem()
            service8.id = 8
            service8.name = "Remittance"
            service8.code = "REMITTANCE"
            list.add(service8)
            //Cards
            val service9 = ServiceItem()
            service9.id = 9
            service9.name = "My Cards"
            service9.code = "CARDS"
            list.add(service9)
            //
            value = list
        },2000)
    }
    //
    val UserName: LiveData<String> = _userName
    val ServicesList : LiveData<List<ServiceItem>> = _servicesList
}