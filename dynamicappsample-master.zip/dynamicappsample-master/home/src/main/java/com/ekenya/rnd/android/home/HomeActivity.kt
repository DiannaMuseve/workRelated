package com.ekenya.rnd.android.home

import android.app.ProgressDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.*
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.lifecycle.*
import androidx.navigation.Navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import androidx.viewpager.widget.ViewPager
import androidx.wear.remote.interactions.RemoteActivityHelper
import com.ekenya.rnd.android.common.abstractions.BaseActivity
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.mobile.di.helpers.activities.ActivityHelperKt
import com.ekenya.rnd.android.mobile.di.helpers.activities.AddressableActivity
import com.ekenya.rnd.android.mobile.di.helpers.features.FeatureModule
import com.ekenya.rnd.android.mobile.di.helpers.features.Modules
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.common.services.qssservice.WakeReceiver
import com.ekenya.rnd.android.home.adapters.CardsPagerAdapter
import com.ekenya.rnd.android.home.databinding.ActivityHomeBinding
import com.ekenya.rnd.android.home.ui.notifications.NotificationsFragment
import com.ekenya.rnd.android.qss.QSSClientService
import com.ekenya.rnd.android.qss.QssServiceResultReceiver
import com.google.android.gms.wearable.*
import com.google.android.gms.wearable.CapabilityClient.OnCapabilityChangedListener
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.splitcompat.SplitCompat
import com.google.android.play.core.splitinstall.SplitInstallManager
import com.google.android.play.core.splitinstall.SplitInstallManagerFactory
import com.google.android.play.core.splitinstall.SplitInstallRequest
import com.google.android.play.core.splitinstall.SplitInstallStateUpdatedListener
import com.google.android.play.core.splitinstall.model.SplitInstallSessionStatus
import dagger.android.AndroidInjector
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.guava.await
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject


class HomeActivity : BaseActivity(), OnCapabilityChangedListener {
    private val TAG = HomeActivity::class.java.name
    // Name of capability listed in Wear app's wear.xml.
    // IMPORTANT NOTE: This should be named differently than your Phone app's capability.
    private lateinit var CAPABILITY_WEAR_APP :String

    // Links to Wear app (Play Store).
    // TODO: Replace with your links/packages.
//    private val PLAY_STORE_APP_URI =
//        "https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}&hl=en"
    private val PLAY_STORE_APP_URI =
        "https://play.google.com/store/apps/details?id=com.ekenya.rnd.android.demoapp&hl=en"

    private lateinit var binding: ActivityHomeBinding
    private var mAppBarConfiguration: AppBarConfiguration? = null

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    private val mViewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(HomeViewModel::class.java)
    }


    private var mApp: DemoApplication? = null
    private var progressDialog: ProgressDialog? = null

    private lateinit var capabilityClient: CapabilityClient
    private lateinit var nodeClient: NodeClient
    private lateinit var remoteActivityHelper: RemoteActivityHelper

    private var wearNodesWithApp: Set<Node>? = null
    private var allConnectedNodes: List<Node>? = null
    private var mWearAlertBar:Snackbar? = null

    private val splitInstallManager: SplitInstallManager by lazy {
        SplitInstallManagerFactory.create(this)
    }

    private val listener = SplitInstallStateUpdatedListener { state ->
        when (state.status()) {
            SplitInstallSessionStatus.DOWNLOADING -> {
                setStatus("DOWNLOADING")
            }
            SplitInstallSessionStatus.INSTALLING -> {
                setStatus("INSTALLING")
            }
            SplitInstallSessionStatus.INSTALLED -> {

                // Enable module immediately
                SplitCompat.install(this)

                setStatus("Module has been installed\n\nTap the menu again to continue ..")
                //
                Handler(Looper.getMainLooper()).postDelayed({
                    progressDialog?.dismiss()
                }, 4000)
            }
            SplitInstallSessionStatus.FAILED -> {
                setStatus("MODULE Installation FAILED")
                //
                Handler(Looper.getMainLooper()).postDelayed({
                    progressDialog?.dismiss()
                }, 4000)
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //
        mApp = application as DemoApplication
        CAPABILITY_WEAR_APP = getString(R.string.mobile_app_capability)
        //

        //Log.d("Main Activity", "Main: $" + mViewModel.text)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val toolbar: Toolbar = binding.collapsingToolbar.findViewById(com.ekenya.rnd.android.common.R.id.toolbar)
        setSupportActionBar(toolbar)

        //
        supportActionBar?.setLogo(com.ekenya.rnd.android.common.R.drawable.logo_sm)
        supportActionBar?.setDisplayUseLogoEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(this, R.id.nav_host_fragment_activity_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = AppBarConfiguration.Builder(
            setOf(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications
            )
        )
        //.setDrawerLayout(drawer)
        .build();

        setupActionBarWithNavController(this, navController, mAppBarConfiguration!!)
        NavigationUI.setupWithNavController(navView, navController)

        //
        val collapsingToolbarLayout =
                findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar)
        collapsingToolbarLayout.setExpandedTitleTextAppearance(com.ekenya.rnd.android.common.R.style.CollapsedAppBar)
        //
        //
        val appBarLayout = findViewById<AppBarLayout>(R.id.toolbar_layout)
        appBarLayout?.addOnOffsetChangedListener(object :
            AppBarLayout.OnOffsetChangedListener {
            var isShow = true
            var scrollRange = -1
            override fun onOffsetChanged(appBarLayout: AppBarLayout, verticalOffset: Int) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.totalScrollRange
                }
                if (scrollRange + verticalOffset == 0) {
                    collapsingToolbarLayout.title = getString(com.ekenya.rnd.android.common.R.string.app_name)
                    isShow = true
                } else if (isShow) {
                    collapsingToolbarLayout.title =
                        " " //carefull there should a space between double quote otherwise it wont work
                    isShow = false
                }
            }
        })
        //
        val viewPager = findViewById<ViewPager>(R.id.topViewpager)
        val tabsLayout= binding.tabLayout
        tabsLayout?.setupWithViewPager(viewPager)

        viewPager?.adapter = CardsPagerAdapter(this,supportFragmentManager)
        //
        binding.bottomBar.setOnMenuItemClickListener(Toolbar.OnMenuItemClickListener { item ->
            var consumed = false
            when (item.itemId) {
                R.id.menu_settings ->{
                    //
                }
                R.id.menu_logout -> {
                    //
//                    var intent = Intent(this, SplashActivity::class.java)
//                    //
//                    startActivity(intent)
                    finish()
                    //
                    overridePendingTransition(0, android.R.anim.fade_out)
                    //
                    consumed = true
                }
            }
            consumed
        })

        //click event over navigation menu like back arrow or hamburger icon
        binding.bottomBar.setNavigationOnClickListener(View.OnClickListener {
            //open bottom sheet
            Log.i("MainActivity", "Bottom Bar Nav Clicked..")
        })
        //
        binding.fabCall.setOnClickListener {
            navigateToModule(Modules.FeatureSupport.INSTANCE.name, "")
        }

        //
        capabilityClient = Wearable.getCapabilityClient(this)
        nodeClient = Wearable.getNodeClient(this)
        remoteActivityHelper = RemoteActivityHelper(this)

        //Show Wear devices advice
        updateWearUI()
        //Check for connected wearables
        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
                launch {
                    // Initial request for devices with our capability, aka, our Wear app installed.
                    findWearDevicesWithApp()
                }
                launch {
                    // Initial request for all Wear devices connected (with or without our capability).
                    // Additional Note: Because there isn't a listener for ALL Nodes added/removed from network
                    // that isn't deprecated, we simply update the full list when the Google API Client is
                    // connected and when capability changes come through in the onCapabilityChanged() method.
                    findAllWearDevices()
                }
            }
        }

        Log.i(TAG, "Launch service..")
        // Starts the service..
        WakeReceiver.setQssWakeAlarm(true,this, QssServiceResultReceiver(Handler(),mQssServiceBinder)) /* true will force the broadcast */
    }

    override fun onSupportNavigateUp(): Boolean {
        //return super.onSupportNavigateUp();
        val navController = findNavController(this, R.id.nav_host_fragment_activity_main)
        return (NavigationUI.navigateUp(navController, mAppBarConfiguration!!)
                || super.onSupportNavigateUp())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)

        for(i in 0 until menu.size()){
            val item = menu.getItem(i)
            val newIcon = item.icon as Drawable
            newIcon.mutate().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            item.icon = newIcon
        }
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem) :Boolean{

        when(item.itemId){
            //
            R.id.menu_notifications -> {
                var tag = "notificationsFragment"
                val fragment: NotificationsFragment =
                    supportFragmentManager.findFragmentByTag(tag) as? NotificationsFragment
                        ?: NotificationsFragment.newInstance()
                //
                fragment.show(supportFragmentManager, tag)
                return true
            }
        }
        return false
    }

    override fun onResume() {
        super.onResume()
        splitInstallManager.registerListener(listener)
        capabilityClient.addListener(this, CAPABILITY_WEAR_APP)
    }

    override fun onPause() {
        splitInstallManager.unregisterListener(listener)
        super.onPause()
        capabilityClient.removeListener(this, CAPABILITY_WEAR_APP)
    }
    override fun onStart()
    {
        super.onStart()
        var intent = Intent(
            this,
            EclecticsQssService::class.java)
        //
        bindService(intent,
            mServiceConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        super.onStop()
        //
        unbindService(mServiceConnection)
    }


    override fun supportFragmentInjector(): AndroidInjector<Fragment> {
        // Fragment Injector should use the Application class
        // If necessary, I will use AndroidInjector as well as App class (I have not done this time)
        return (application as DemoApplication).supportFragmentInjector()
    }

    private fun setStatus(label: String){
        if (progressDialog == null){
            progressDialog =  ProgressDialog(this, android.R.style.Theme_Holo_Dialog)
            progressDialog!!.isIndeterminate = true
            progressDialog!!.setTitle("Please Wait ..")
            progressDialog!!.setMessage(label)
            progressDialog!!.show()
        }else{
            progressDialog!!.setMessage(label)
        }
        //Snackbar.make(binding.root, label, Snackbar.LENGTH_SHORT).show()
    }

    private fun navigateToModule(moduleName: String, action: String){

        if (splitInstallManager.installedModules.contains(moduleName)) {
            setStatus("$moduleName already installed\nLaunching ..")
            //
            showFeatureModule(Modules.INSTANCE.getModuleFromName(moduleName), action)
            return
        }
        //
        val request = SplitInstallRequest
            .newBuilder()
            .addModule(moduleName)
            .build()
        //
        splitInstallManager.startInstall(request)
        setStatus("Module Not Installed\n\nStarting install for $moduleName")
    }

    private fun showFeatureModule(module: FeatureModule, action: String)
    {
        try {
            //Inject
            mApp!!.addModuleInjector(module)
            //
            var intent  = ActivityHelperKt.intentTo(this, module as AddressableActivity)
            //
            intent.action = action
            this.startActivity(intent)

            //
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (e: Exception) {
            e.message?.let { Log.d("Home Fragment", it) };
        }
        //
        progressDialog?.dismiss()
        progressDialog = null
    }


    private val mServiceConnection: ServiceConnection = object : ServiceConnection {

        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            Log.i(TAG, "Service connected.")
//            var mService = (service as QSSClientService.LocalBinder).service as EclecticsQssService
//            //
//            //Update callbacks
//            mViewModel.service?.postValue(mService)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            //notify callbacks
            mViewModel.service?.postValue(null)
        }
    }

    private val mQssServiceBinder = object : QssServiceResultReceiver.IQssServiceBinder {
        override fun onBind(service: QSSClientService) {
            Log.i(TAG, "Service connected.")
        //Update callbacks
            val srv = service as EclecticsQssService
            srv.mAlertEntryActivity =  this@HomeActivity
            mViewModel.service?.postValue(srv)
        }

        override fun onUnbind() {
            //
        }

    }

    override fun onCapabilityChanged(capabilityInfo: CapabilityInfo) {
        Log.d(TAG, "onCapabilityChanged(): $capabilityInfo")
        wearNodesWithApp = capabilityInfo.nodes

        lifecycleScope.launch {
            // Because we have an updated list of devices with/without our app, we need to also update
            // our list of active Wear devices.
            findAllWearDevices()
        }
    }
    private suspend fun findWearDevicesWithApp() {
        Log.d(TAG, "findWearDevicesWithApp()")

        try {
            val capabilityInfo = capabilityClient
                .getCapability(CAPABILITY_WEAR_APP, CapabilityClient.FILTER_ALL)
                .result//.await()

            withContext(Dispatchers.Main) {
                Log.d(TAG, "Capability request succeeded.")
                wearNodesWithApp = capabilityInfo.nodes
                Log.d(TAG, "Capable Nodes: $wearNodesWithApp")
                updateWearUI()
            }
        } catch (cancellationException: CancellationException) {
            // Request was cancelled normally
            throw cancellationException
        } catch (throwable: Throwable) {
            Log.d(TAG, "Capability request failed to return any results.")
        }
    }

    private suspend fun findAllWearDevices() {
        Log.d(TAG, "findAllWearDevices()")

        try {
            val connectedNodes = nodeClient.connectedNodes.result//.await()

            withContext(Dispatchers.Main) {
                allConnectedNodes = connectedNodes
                updateWearUI()
            }
        } catch (cancellationException: CancellationException) {
            // Request was cancelled normally
        } catch (throwable: Throwable) {
            Log.d(TAG, "Node request failed to return any results.")
        }
    }

    private fun updateWearUI() {
        Log.d(TAG, "updateWearUI()")

        val wearNodesWithApp = wearNodesWithApp
        val allConnectedNodes = allConnectedNodes
        //
        if(mWearAlertBar == null ){
            mWearAlertBar = Snackbar.make(binding.navView,"",
                Snackbar.LENGTH_INDEFINITE)
        }
        val textView = mWearAlertBar?.getView()?.findViewById<View>(com.google.android.material.R.id.snackbar_text) as TextView?
        textView?.maxLines = 8
        when {
            wearNodesWithApp == null || allConnectedNodes == null -> {
                Log.d(TAG, "Waiting on Results for both connected nodes and nodes with app")
                mWearAlertBar?.setText(R.string.message_checking)
                mWearAlertBar?.setAction("Dismiss") { mWearAlertBar?.dismiss() }
            }
            allConnectedNodes.isEmpty() -> {
                Log.d(TAG, "No devices")
                mWearAlertBar?.setText(R.string.message_checking)
                mWearAlertBar?.setAction("Dismiss") { mWearAlertBar?.dismiss() }
            }
            wearNodesWithApp.isEmpty() -> {
                Log.d(TAG, "Missing on all devices")
                //
                mWearAlertBar?.setText(R.string.message_missing_all)
                mWearAlertBar?.setAction("Install ..") {
                    openPlayStoreOnWearDevicesWithoutApp()
                    mWearAlertBar?.dismiss()
                }
            }
            wearNodesWithApp.size < allConnectedNodes.size -> {
                // TODO: Add your code to communicate with the wear app(s) via Wear APIs
                //       (MessageClient, DataClient, etc.)
                Log.d(TAG, "Installed on some devices")
                mWearAlertBar?.setText(getString(R.string.message_some_installed, wearNodesWithApp.toString()))
                mWearAlertBar?.setAction("Install ..") {
                    openPlayStoreOnWearDevicesWithoutApp()
                    mWearAlertBar?.dismiss()
                }
            }
            else -> {
                Log.d(TAG, "Installed on all devices")
                mWearAlertBar?.setText(getString(R.string.message_all_installed, wearNodesWithApp.toString()))
                mWearAlertBar?.setAction("Dismiss") { mWearAlertBar?.dismiss() }
                // TODO: Add your code to communicate with the wear app(s) via Wear APIs
                //       (MessageClient, DataClient, etc.)
            }
        }
        mWearAlertBar?.show()
    }

    private fun openPlayStoreOnWearDevicesWithoutApp() {
        Log.d(TAG, "openPlayStoreOnWearDevicesWithoutApp()")

        val wearNodesWithApp = wearNodesWithApp ?: return
        val allConnectedNodes = allConnectedNodes ?: return

        // Determine the list of nodes (wear devices) that don't have the app installed yet.
        val nodesWithoutApp = allConnectedNodes - wearNodesWithApp

        Log.d(TAG, "Number of nodes without app: " + nodesWithoutApp.size)
        val intent = Intent(Intent.ACTION_VIEW)
            .addCategory(Intent.CATEGORY_BROWSABLE)
            .setData(Uri.parse(PLAY_STORE_APP_URI))

        // In parallel, start remote activity requests for all wear devices that don't have the app installed yet.
        nodesWithoutApp.forEach { node ->
            lifecycleScope.launch {
                try {
                    remoteActivityHelper
                        .startRemoteActivity(
                            targetIntent = intent,
                            targetNodeId = node.id
                        )
                        .await()

                    Toast.makeText(
                        this@HomeActivity,
                        getString(R.string.store_request_successful),
                        Toast.LENGTH_SHORT
                    ).show()
                } catch (cancellationException: CancellationException) {
                    // Request was cancelled normally
                } catch (throwable: Throwable) {
                    Toast.makeText(
                        this@HomeActivity,
                        getString(R.string.store_request_unsuccessful),
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }
}

