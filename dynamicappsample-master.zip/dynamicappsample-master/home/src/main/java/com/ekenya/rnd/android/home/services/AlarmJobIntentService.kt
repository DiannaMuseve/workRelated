package com.ekenya.rnd.android.home.services

import android.content.Context
import android.content.Intent
import androidx.core.app.JobIntentService

class AlarmJobIntentService : JobIntentService() {

    override fun onHandleWork(intent: Intent) {
        /* your code here */
        /* reset the alarm */
       // Util.showDebugLog("setAlarmCtx", "started Bottom")
        AlarmReceiver.setAlarm(false,this)
        //stopSelf()
    }

    companion object {

        /* Give the Job a Unique Id */
        private val JOB_ID = 1000

        fun enqueueWork(ctx: Context, intent: Intent) {
            JobIntentService.enqueueWork(ctx, AlarmJobIntentService::class.java, JOB_ID, intent)
        }
    }
}