package com.ekenya.rnd.android.home.di

import android.app.Application
import android.content.Context
import com.ekenya.rnd.android.mobile.di.AppComponent
import com.ekenya.rnd.android.mobile.di.ModuleScope
import com.ekenya.rnd.android.mobile.di.injectables.ViewModelModule
import com.ekenya.rnd.android.home.di.injectables.HomeActivityModules
import com.ekenya.rnd.android.home.di.injectables.HomeFragmentModules
import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule

@ModuleScope
@Component(
    dependencies = [
        AppComponent::class
    ],
    modules = [
        AndroidSupportInjectionModule::class,
        HomeActivityModules::class,
        HomeFragmentModules::class,
        ViewModelModule::class
    ]
)
interface HomeComponent {
    fun inject(injector: HomeInjector)
}