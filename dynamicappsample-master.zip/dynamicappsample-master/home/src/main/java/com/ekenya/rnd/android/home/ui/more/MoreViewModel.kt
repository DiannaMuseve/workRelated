package com.ekenya.rnd.android.home.ui.more

import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.home.models.ServiceItem
import javax.inject.Inject

class MoreViewModel  @Inject constructor(
    private val app: Application
): AndroidViewModel(app) {

    //
    private val _userName = MutableLiveData<String>().apply {
        value = "Samir"
    }
    //
    private val _servicesList = MutableLiveData<List<ServiceItem>>().apply {
        val handler = Handler(Looper.getMainLooper())
        handler.postDelayed({
            var list = ArrayList<ServiceItem>()
            //Insuretech
            val service1 = ServiceItem()
            service1.id = 1
            service1.name = "Insurance"
            service1.code = "BANCASSURANCER"
            list.add(service1)
            //Chama
            val service2 = ServiceItem()
            service2.id = 2
            service2.name = "Group Banking"
            service2.code = "CHAMA"
            list.add(service2)
            //PAY BILLS
            val service3 = ServiceItem()
            service3.id = 3
            service3.name = "Investment"
            service3.code = "INVESTMENT"
            list.add(service3)
            //Loans
            val service4 = ServiceItem()
            service4.id = 4
            service4.name = "My BIZ"
            service4.code = "SME"
            list.add(service4)

            value = list
        },2000)
    }
    //
    val UserName: LiveData<String> = _userName
    val ServicesList : LiveData<List<ServiceItem>> = _servicesList
}