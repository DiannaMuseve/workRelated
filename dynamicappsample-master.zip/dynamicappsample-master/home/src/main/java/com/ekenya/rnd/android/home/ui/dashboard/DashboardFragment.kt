package com.ekenya.rnd.android.home.ui.dashboard

import android.app.Application
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.mobile.di.helpers.activities.ActivityHelperKt
import com.ekenya.rnd.android.mobile.di.helpers.activities.AddressableActivity
import com.ekenya.rnd.android.mobile.di.helpers.features.FeatureModule
import com.ekenya.rnd.android.mobile.di.helpers.features.Modules
import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.home.R
import com.ekenya.rnd.android.home.adapters.ServicesAdapter
import com.ekenya.rnd.android.home.models.ServiceItem
import com.ekenya.rnd.android.home.adapters.ServicesAdapter.ServicesCallback
import com.ekenya.rnd.android.home.databinding.HomeDashboardFragmentBinding
import com.google.android.play.core.splitcompat.SplitCompat
import com.google.android.play.core.splitinstall.SplitInstallManager
import com.google.android.play.core.splitinstall.SplitInstallManagerFactory
import com.google.android.play.core.splitinstall.SplitInstallRequest
import com.google.android.play.core.splitinstall.SplitInstallStateUpdatedListener
import com.google.android.play.core.splitinstall.model.SplitInstallSessionStatus
import javax.inject.Inject

class DashboardFragment : BaseDaggerFragment() {

    companion object {
        fun newInstance() = DashboardFragment()
    }
    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    @Inject
    lateinit var mApp:Application

    @Inject
    lateinit var mAppRepo: IAppRepo

    private val mViewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(DashboardViewModel::class.java)
    }
    private var _binding: HomeDashboardFragmentBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    //private var mApp: MobileBankingApp? = null
    private lateinit var mRefreshLayout:SwipeRefreshLayout

    private lateinit var mListView:RecyclerView
    private lateinit var mEmptyLayout:View

    private  var progressDialog:ProgressDialog? = null

    @Inject
    public lateinit var mAdapter: ServicesAdapter

    private val splitInstallManager: SplitInstallManager by lazy {
        SplitInstallManagerFactory.create(requireActivity())
    }

    private val listener = SplitInstallStateUpdatedListener { state ->
        when (state.status()) {
            SplitInstallSessionStatus.DOWNLOADING -> {
                setStatus("DOWNLOADING")
            }
            SplitInstallSessionStatus.INSTALLING -> {
                setStatus("INSTALLING")
            }
            SplitInstallSessionStatus.INSTALLED -> {

                // Enable module immediately
                SplitCompat.install(requireContext())

                setStatus("Module has been installed\n\nTap the menu again to continue ..")

                //
                Handler(Looper.getMainLooper()).postDelayed({
                    progressDialog?.dismiss()
                },4000)
            }
            SplitInstallSessionStatus.FAILED -> {
                setStatus("MODULE Installation FAILED")
                //
                Handler(Looper.getMainLooper()).postDelayed({
                    progressDialog?.dismiss()
                },4000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = HomeDashboardFragmentBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //
        //
        val wrapper: ViewGroup = binding.dashboardContent//root.findViewById<ViewGroup>(R.id.dashboard_content)

        //
        val listGroup: View = inflater.inflate(com.ekenya.rnd.android.common.R.layout.list_rv_item, container, false)
        mListView = listGroup.findViewById(com.ekenya.rnd.android.common.R.id.list)

        if (requireActivity().findViewById<View?>(R.id.content_tablet) != null) {
            val manager = GridLayoutManager(activity, 4, RecyclerView.VERTICAL, false)
            mListView.layoutManager = manager
        } else {
            val manager = GridLayoutManager(activity, 3, RecyclerView.VERTICAL, false)
            //val manager = LinearLayoutManager(activity, RecyclerView.VERTICAL, false)
            mListView.layoutManager = manager
        }
        //
        //
        val controller = AnimationUtils.loadLayoutAnimation(
            activity, com.ekenya.rnd.android.common.R.anim.layout_animation_fall_down
        )
        mListView.layoutAnimation = controller

        mRefreshLayout = listGroup.findViewById<SwipeRefreshLayout>(com.ekenya.rnd.android.common.R.id.refresh)

        mEmptyLayout = listGroup.findViewById<View>(com.ekenya.rnd.android.common.R.id.empty_wrapper)
        val emptyCaption = listGroup.findViewById<View>(com.ekenya.rnd.android.common.R.id.empty_caption) as TextView
        //emptyCaption.setTextColor(getResources().getColor(android.R.color.white));
        emptyCaption.text = "No Active Services"
        wrapper.removeAllViews()
        //
        wrapper.addView(listGroup)
        //
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val textView: TextView = binding.tvUserName
        mViewModel.UserName.observe(viewLifecycleOwner, Observer {
            textView.text = "Hello $it\nWelcome to our mobile banking app"
        })
        //
        mAdapter.setMode(ServicesAdapter.Orientation.VERTICAL)
        mListView.adapter = mAdapter
        mAdapter.callbacks.add(object : ServicesCallback {
            override fun onMenuClicked(row: View?, service: ServiceItem?, menu: MenuItem?) {}
            override fun onClick(row: View?, service: ServiceItem?) {
                if (service != null) {
                    when(service.code){
                        //Buy Airtime
                        "BUYAIRTIME" ->{
                            navigateToModule(
                                Modules.FeatureWallet.INSTANCE.name,
                                Modules.FeatureWallet.ACTION_BUY_AIRTIME
                            )
                        }
                        //
                        "FT" ->{
                            navigateToModule(
                                Modules.FeatureWallet.INSTANCE.name,
                                Modules.FeatureWallet.ACTION_FUNDS_TRANSFER
                            )
                        }
                        //
                        "PAYBILLS" -> {
                            navigateToModule(
                                Modules.FeatureWallet.INSTANCE.name,
                                Modules.FeatureWallet.ACTION_PAY_BILLS
                            )
                        }
                    }
                }
            }
            override fun onLongClick(row: View?, service: ServiceItem?) {}
        })
        mRefreshLayout.isRefreshing = true
        //
        mRefreshLayout.setOnRefreshListener {
            updateContent()
        }
        updateContent()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onResume() {
        super.onResume()
        splitInstallManager.registerListener(listener)
    }

    override fun onPause() {
        splitInstallManager.unregisterListener(listener)
        super.onPause()
    }

    private fun updateContent(){

        mViewModel.ServicesList.observe(viewLifecycleOwner, Observer { list ->
            //
            mAdapter?.let {
                it.addAll(list)
                it.notifyDataSetChanged()
            }
            //
            if(list.isEmpty()){
                mEmptyLayout.visibility = View.VISIBLE
            }else{
                mEmptyLayout.visibility = View.GONE
            }
            //
            mRefreshLayout.isRefreshing = false
        })
    }

    private fun setStatus(label: String){
        if (progressDialog == null){
            progressDialog =  ProgressDialog(requireActivity())
            progressDialog!!.isIndeterminate = true
            progressDialog!!.setTitle("Please Wait ..")
            progressDialog!!.setMessage(label)
            progressDialog!!.show()
        }else{
            progressDialog!!.setMessage(label)
        }
        //Snackbar.make(binding.root, label, Snackbar.LENGTH_SHORT).show()
    }

    private fun navigateToModule(moduleName: String, action: String){
        for( m in splitInstallManager.installedModules){
            Log.i("HomeFragment","Installed => $m")
        }

        if (splitInstallManager.installedModules.contains(moduleName)) {
            setStatus("${moduleName} already installed\nLaunching ..")
            //
            showFeatureModule(Modules.INSTANCE.getModuleFromName(moduleName), action)
            return
        }
        //
        val request = SplitInstallRequest
            .newBuilder()
            .addModule(moduleName)
            .build()
        //
        splitInstallManager.startInstall(request)
        setStatus("Module Not Installed. Starting install for $moduleName")
    }

    private fun showFeatureModule(module: FeatureModule, action: String)
    {
        try {
            //Inject
            (mApp as DemoApplication)!!.addModuleInjector(module)
            var intent:Intent? = null
            //
            when (action) {
                Modules.FeatureWallet.ACTION_BUY_AIRTIME -> {
                    //Create the Intent for launching this action
                    intent  = ActivityHelperKt.intentTo( activity, module as AddressableActivity )
                }
                Modules.FeatureWallet.ACTION_FUNDS_TRANSFER -> {
                    //Create the Intent for launching this action
                    intent  = ActivityHelperKt.intentTo( activity, module as AddressableActivity )
                }
                Modules.FeatureWallet.ACTION_LOANS -> {
                    //Create the Intent for launching this action
                    intent  = ActivityHelperKt.intentTo( activity, module as AddressableActivity )
                }
                Modules.FeatureWallet.ACTION_PAY_BILLS -> {
                    //Create the Intent for launching this action
                    intent  = ActivityHelperKt.intentTo( activity, module as AddressableActivity )
                }
                else -> {
                    //
                    intent  = ActivityHelperKt.intentTo( activity, module as AddressableActivity )
                }
            }
            //
            intent.action = action
            this.startActivity(intent)
            //
            requireActivity().overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (e: Exception) {
            e.message?.let { Log.d("Home Fragment", it) };
        }
        //
        progressDialog?.dismiss()
        progressDialog = null
    }
}