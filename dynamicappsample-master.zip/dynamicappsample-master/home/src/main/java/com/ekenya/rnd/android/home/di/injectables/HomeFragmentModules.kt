package com.ekenya.rnd.android.home.di.injectables

import androidx.lifecycle.ViewModel
import com.ekenya.rnd.android.mobile.di.ViewModelKey
import com.ekenya.rnd.android.home.HomeViewModel
import com.ekenya.rnd.android.home.ui.dashboard.DashboardFragment
import com.ekenya.rnd.android.home.ui.dashboard.DashboardViewModel
import com.ekenya.rnd.android.home.ui.more.MoreFragment
import com.ekenya.rnd.android.home.ui.more.MoreViewModel
import com.ekenya.rnd.android.home.ui.notifications.NotificationsFragment
import com.ekenya.rnd.android.home.ui.notifications.NotificationsViewModel
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector
import dagger.multibindings.IntoMap

@Module
abstract class HomeFragmentModules {

    @ContributesAndroidInjector(modules = [DashboardFragmentModule::class])
    abstract fun contributeDashboardFragment(): DashboardFragment

    @Module
    abstract class DashboardFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(DashboardViewModel::class)
        abstract fun bindDashboardViewModel(viewModel: DashboardViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [NotificationsFragmentModule::class])
    abstract fun contributeNotificationsFragment(): NotificationsFragment

    @Module
    abstract class NotificationsFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(NotificationsViewModel::class)
        abstract fun bindNotificationsViewModel(viewModel: NotificationsViewModel): ViewModel
        @Binds
        @IntoMap
        @ViewModelKey(HomeViewModel::class)
        abstract fun bindHomeViewModel(viewModel: HomeViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [MoreFragmentModule::class])
    abstract fun contributeMoreFragment(): MoreFragment

    @Module
    abstract class MoreFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(MoreViewModel::class)
        abstract fun bindMoreViewModel(viewModel: MoreViewModel): ViewModel
    }

    //LIST THE OTHER INJECTABLE FRAGMENTS AS ABOVE
}
