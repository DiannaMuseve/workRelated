package com.ekenya.rnd.android.home.services

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.annotation.RequiresApi

class AlarmReceiver:BroadcastReceiver() {


    override fun onReceive(context: Context, intent: Intent) {
        /* enqueue the job */
        AlarmJobIntentService.enqueueWork(context, intent)
    }

    companion object {

        val CUSTOM_INTENT = "com.test.intent.action.ALARM"

        fun cancelAlarm(ctx:Context) {
            val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

            /* cancel any pending alarm */

            alarm.cancel(pendingIntent(ctx))
        }


        fun setAlarm(force: Boolean, ctx:Context) {
            cancelAlarm(ctx)
            val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            // EVERY N MINUTES
            val N = 1
            val delay = (1000 * 60 * N).toLong()
            var `when` = System.currentTimeMillis()
            if (!force) {
                `when` += delay
            }

            /* fire the broadcast */
            val SDK_INT = Build.VERSION.SDK_INT
            when {
                SDK_INT < Build.VERSION_CODES.KITKAT ->
                    alarm.set(AlarmManager.RTC_WAKEUP, `when`, pendingIntent(ctx))
                SDK_INT < Build.VERSION_CODES.M ->
                    alarm.setExact(AlarmManager.RTC_WAKEUP, `when`, pendingIntent(ctx))
                else ->
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, `when`, pendingIntent(ctx))
            }
        }

        private fun pendingIntent(ctx:Context): PendingIntent{
            val alarmIntent = Intent(ctx, AlarmReceiver::class.java)
            alarmIntent.action = CUSTOM_INTENT

            return PendingIntent.getBroadcast(ctx, 0, alarmIntent, PendingIntent.FLAG_MUTABLE)
        }
    }
}