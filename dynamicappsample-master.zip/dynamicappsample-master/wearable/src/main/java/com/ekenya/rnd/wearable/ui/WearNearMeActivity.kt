package com.ekenya.rnd.wearable.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.wear.activity.ConfirmationActivity
import androidx.wear.ambient.AmbientModeSupport
import androidx.wear.widget.SwipeDismissFrameLayout
import com.ekenya.rnd.android.common.abstractions.BaseActivity
import com.ekenya.rnd.wearable.R
import com.ekenya.rnd.wearable.databinding.WearActivityNearMeBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions


class WearNearMeActivity : BaseActivity(), OnMapReadyCallback,
    AmbientModeSupport.AmbientCallbackProvider {

    private val TAG = WearMainActivity.javaClass.simpleName

    val ACTIVITY_RESULT_MARKER_NAVIGATE = 0x35

    private var mapFragment:SupportMapFragment? = null
    /**
     * Map is initialized when it"s fully loaded and ready to be used.
     * See [onMapReady]
     */
    private lateinit var mMap: GoogleMap
    private lateinit var swipeDismissRootContainer: SwipeDismissFrameLayout
    private lateinit var binding: WearActivityNearMeBinding
    /*
         * Declare an ambient mode controller, which will be used by
         * the activity to determine if the current mode is ambient.
         */
    private lateinit var ambientController: AmbientModeSupport.AmbientController
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedState: Bundle?) {
        super.onCreate(savedState)

        binding = WearActivityNearMeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Enables the Swipe-To-Dismiss Gesture via the root layout (SwipeDismissFrameLayout).
        // Swipe-To-Dismiss is a standard pattern in Wear for closing an app and needs to be
        // manually enabled for any Google Maps Activity. For more information, review our docs:
        // https://developer.android.com/training/wearables/ui/exit.html
        swipeDismissRootContainer = binding.swipeDismissRootContainer
        swipeDismissRootContainer.addCallback(object : SwipeDismissFrameLayout.Callback() {
            override fun onDismissed(layout: SwipeDismissFrameLayout?) {
                // Hides view before exit to avoid stutter.
                layout?.visibility = View.GONE
                //finish()
                onBackPressed()
            }
        })

        // Adjusts margins to account for the system window insets when they become available.
        swipeDismissRootContainer.setOnApplyWindowInsetsListener { _, insetsArg ->
            val insets = swipeDismissRootContainer.onApplyWindowInsets(insetsArg)
            val mapContainer = binding.mapContainer
            val params = mapContainer.layoutParams as FrameLayout.LayoutParams

            // Add Wearable insets to FrameLayout container holding map as margins
            params.setMargins(
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetTop,
                insets.systemWindowInsetRight,
                insets.systemWindowInsetBottom
            )
            mapContainer.layoutParams = params

            insets
        }

        // Enable ambient support, so the map remains visible in simplified, low-color display
        // when the user is no longer actively using the app but the app is still visible on the
        // watch face.
        ambientController = AmbientModeSupport.attach(this)
        Log.d(TAG, "Is ambient enabled: " + ambientController.isAmbient)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Obtain the MapFragment and set the async listener to be notified when the map is ready.
        mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment?.getMapAsync(this)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(resultCode == ACTIVITY_RESULT_MARKER_NAVIGATE){
            //
        }
    }

    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        // Map is ready to be used.
        mMap = googleMap

        // Inform user how to close app (Swipe-To-Close).
        val duration = Toast.LENGTH_LONG
        val toast = Toast.makeText(getApplicationContext(), R.string.intro_text, duration)
        toast.setGravity(Gravity.CENTER, 0, 0)
        toast.show()


        if (!hasGps()) {
            Log.d(TAG, "This hardware doesn't have GPS.")
            // Fall back to functionality that doesn't use location or
            // warn the user that location function isn't available.
            fusedLocationClient?.lastLocation
                ?.addOnSuccessListener { location : Location? ->
                    // Got last known location. In some rare situations this can be null.
                }
        }else {
            val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
            // getting GPS status
            // getting GPS status
            val isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            // getting network status
            // getting network status
            val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)


            var myLocation:Location? = null

            if (isGPSEnabled == false && isNetworkEnabled == false) {
                myLocation = null
            } else if (isGPSEnabled) {
                myLocation = locationManager
                    .getLastKnownLocation(LocationManager.GPS_PROVIDER)
            }
            if (isNetworkEnabled && myLocation == null) {
                myLocation = locationManager
                    .getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }
            if (myLocation != null) {
                val latLng = LatLng(myLocation.latitude,myLocation.longitude)
                //
                val options = MarkerOptions().position(latLng).title("My Location")
                    .snippet("This is my spot!")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
                //
                val marker = mMap.addMarker(options)
                marker.setTag(latLng)
                mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng))
            }
        }
        //
        mMap.setOnMarkerClickListener { marker ->
            //
            //TODO: Send message to phone with marker location for launching navigation ..
            //
            val intent = Intent(this@WearNearMeActivity, ConfirmationActivity::class.java).apply {
                //putExtra(ConfirmationActivity.EXTRA_ANIMATION_TYPE, ConfirmationActivity.SUCCESS_ANIMATION)
                putExtra(
                    ConfirmationActivity.EXTRA_ANIMATION_TYPE,
                    ConfirmationActivity.OPEN_ON_PHONE_ANIMATION
                )
                putExtra(ConfirmationActivity.EXTRA_MESSAGE, "Navigation route opened on phone")
            }
            startActivityForResult(intent, ACTIVITY_RESULT_MARKER_NAVIGATE)

            true
        }
    }

    private fun hasGps(): Boolean = packageManager.hasSystemFeature(PackageManager.FEATURE_LOCATION_GPS)

    override fun getAmbientCallback(): AmbientModeSupport.AmbientCallback {
        //
        return object : AmbientModeSupport.AmbientCallback() {

            override fun onEnterAmbient(ambientDetails: Bundle?) {
                // Handle entering ambient mode
                mapFragment?.onEnterAmbient(ambientDetails)
            }

            override fun onExitAmbient() {
                // Handle exiting ambient mode
                mapFragment?.onExitAmbient()
            }

            override fun onUpdateAmbient() {
                // Update the content
            }
        }
    }
}