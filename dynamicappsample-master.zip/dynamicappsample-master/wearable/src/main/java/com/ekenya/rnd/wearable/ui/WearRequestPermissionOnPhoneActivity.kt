package com.ekenya.rnd.wearable.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContract
import com.ekenya.rnd.android.common.abstractions.BaseActivity
import com.ekenya.rnd.wearable.databinding.WearActivityRequestPermissionOnPhoneBinding

class WearRequestPermissionOnPhoneActivity: BaseActivity() {
    private lateinit var binding: WearActivityRequestPermissionOnPhoneBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = WearActivityRequestPermissionOnPhoneBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.openOnPhoneContainer.setOnClickListener {
            setResult(RESULT_OK)
            finish()
        }
    }

    companion object {

        /**
         * An [ActivityResultContract] for checking that the user wants to request permission on
         * their phone.
         */
        object RequestPermissionOnPhone : ActivityResultContract<Unit, Boolean>() {
            override fun createIntent(context: Context, input: Unit): Intent =
                Intent(context, WearRequestPermissionOnPhoneActivity::class.java)

            override fun parseResult(resultCode: Int, intent: Intent?): Boolean =
                resultCode == Activity.RESULT_OK
        }
    }
}