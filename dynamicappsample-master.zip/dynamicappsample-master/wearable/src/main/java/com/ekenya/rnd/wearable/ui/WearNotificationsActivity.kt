package com.ekenya.rnd.wearable.ui

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import androidx.recyclerview.widget.RecyclerView
import androidx.wear.ambient.AmbientModeSupport
import androidx.wear.widget.SwipeDismissFrameLayout
import androidx.wear.widget.WearableLinearLayoutManager
import com.ekenya.rnd.android.common.abstractions.BaseActivity
import com.ekenya.rnd.wearable.databinding.WearNotificationsActivityBinding

class WearNotificationsActivity: BaseActivity() , AmbientModeSupport.AmbientCallbackProvider {

    private lateinit var binding:WearNotificationsActivityBinding

    private lateinit var swipeDismissRootContainer: SwipeDismissFrameLayout

    private val audioManager = applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    override fun onCreate(savedState: Bundle?) {
        super.onCreate(savedState)

        binding = WearNotificationsActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Enables the Swipe-To-Dismiss Gesture via the root layout (SwipeDismissFrameLayout).
        // Swipe-To-Dismiss is a standard pattern in Wear for closing an app and needs to be
        // manually enabled for any Google Maps Activity. For more information, review our docs:
        // https://developer.android.com/training/wearables/ui/exit.html
        swipeDismissRootContainer = binding.swipeDismissRootContainer
        swipeDismissRootContainer.addCallback(object : SwipeDismissFrameLayout.Callback() {
            override fun onDismissed(layout: SwipeDismissFrameLayout?) {
                // Hides view before exit to avoid stutter.
                layout?.visibility = View.GONE
                //finish()
                onBackPressed()
            }
        })

        // Adjusts margins to account for the system window insets when they become available.
        swipeDismissRootContainer.setOnApplyWindowInsetsListener { _, insetsArg ->
            val insets = swipeDismissRootContainer.onApplyWindowInsets(insetsArg)
            val listContainer = binding.listContainer
            val params = listContainer.layoutParams as FrameLayout.LayoutParams

            // Add Wearable insets to FrameLayout container holding map as margins
            params.setMargins(
                insets.systemWindowInsetLeft,
                insets.systemWindowInsetTop,
                insets.systemWindowInsetRight,
                insets.systemWindowInsetBottom
            )
            listContainer.layoutParams = params

            insets
        }
        //
        val recyclerView = binding.notificationsList
        recyclerView.apply {
            // To align the edge children (first and last) with the center of the screen
            isEdgeItemsCenteringEnabled = true
            //
            layoutManager = WearableLinearLayoutManager(this@WearNotificationsActivity,
                customScrollingLayoutCallback)
        }
    }

    fun getAudioDevice(){
        //
        if(!audioOutputAvailable(AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) &&
            audioOutputAvailable(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)){
            //No Audio Devices
        }else if(audioOutputAvailable(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)){
            //Not connected ...
            audioManager.registerAudioDeviceCallback(object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                    super.onAudioDevicesAdded(addedDevices)
                    if (audioOutputAvailable(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)) {
                        // a bluetooth headset has just been connected
                    }
                }
                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                    super.onAudioDevicesRemoved(removedDevices)
                    if (!audioOutputAvailable(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)) {
                        // a bluetooth headset is no longer connected
                    }
                }
            }, null)
        }
    }

    fun audioOutputAvailable(type: Int): Boolean {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_AUDIO_OUTPUT)) {
            return false
        }
        return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type == type }
    }


    override fun getAmbientCallback(): AmbientModeSupport.AmbientCallback {
        //
        return object : AmbientModeSupport.AmbientCallback() {

            override fun onEnterAmbient(ambientDetails: Bundle?) {
                // Handle entering ambient mode
            }

            override fun onExitAmbient() {
                // Handle exiting ambient mode
            }

            override fun onUpdateAmbient() {
                // Update the content
            }
        }
    }

    val customScrollingLayoutCallback  = object: WearableLinearLayoutManager.LayoutCallback() {
        /** How much should we scale the icon at most.  */
        private val MAX_ICON_PROGRESS = 0.65f
        private var progressToCenter: Float = 0f

        override fun onLayoutFinished(child: View, parent: RecyclerView) {
            child.apply {
                // Figure out % progress from top to bottom
                val centerOffset = height.toFloat() / 2.0f / parent.height.toFloat()
                val yRelativeToCenterOffset = y / parent.height + centerOffset

                // Normalize for center
                progressToCenter = Math.abs(0.5f - yRelativeToCenterOffset)
                // Adjust to the maximum scale
                progressToCenter = Math.min(progressToCenter, MAX_ICON_PROGRESS)

                scaleX = 1 - progressToCenter
                scaleY = 1 - progressToCenter
            }
        }
    }
}