package com.ekenya.rnd.android.mobile.di.injectables

import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ServicesModule {

    @ContributesAndroidInjector
    abstract fun contributeQssService(): EclecticsQssService
}