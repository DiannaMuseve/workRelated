package com.ekenya.rnd.android.mobile.ui

import androidx.lifecycle.AndroidViewModel
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.mobile.DemoApplication
import javax.inject.Inject

class MainViewModel @Inject constructor(
    private val IAppRepo: IAppRepo,
    private val app: DemoApplication
): AndroidViewModel(app) {

    //
}