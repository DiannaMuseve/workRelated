package com.ekenya.rnd.android.mobile.di.helpers.activities;

public interface AddressableActivity {
    String getClassName();
}
// ActivityHelperKt.java

