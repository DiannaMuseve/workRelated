package com.ekenya.rnd.android.mobile.di.helpers.activities;


import com.ekenya.rnd.android.common.Constants;

// Activities.java
public final class Activities {

    public static final Activities INSTANCE;

    private Activities() {
    }

    static {
        Activities var0 = new Activities();
        INSTANCE = var0;
    }
}
