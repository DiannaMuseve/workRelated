package com.ekenya.rnd.android.mobile.di.helpers.features;

import com.ekenya.rnd.android.mobile.di.helpers.activities.AddressableActivity;
import com.ekenya.rnd.android.common.Constants;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public final class Modules {


    private static final List<FeatureModule> modules;

    public static final Modules INSTANCE;

    public final FeatureModule getModuleFromName(String moduleName) {

        Iterator var4 = modules.iterator();

        FeatureModule it;
        do {
            if (!var4.hasNext()) {
                throw new IllegalArgumentException(moduleName + " is not found");
            }
            Object element$iv = var4.next();
            it = (FeatureModule) element$iv;
        } while (!it.getName().equalsIgnoreCase(moduleName));

        return it;
    }

    private Modules() {
    }

    static {
        Modules var0 = new Modules();
        INSTANCE = var0;
        modules = Arrays.asList(new FeatureModule[]{
                (FeatureModule) FeatureSupport.INSTANCE,
                (FeatureModule) FeatureWallet.INSTANCE,
                (FeatureModule) FeatureOnboarding.INSTANCE,
                (FeatureModule) FeatureAccountOpening.INSTANCE,
                (FeatureModule) FeatureAuth.INSTANCE,
                (FeatureModule) FeatureHome.INSTANCE}.clone()
        );
    }

    public static final class FeatureHome implements FeatureModule, AddressableActivity  {

        private static final String name;

        private static final String injectorName;
        private static final String className;

        public static final FeatureHome INSTANCE;

        public String getName() {
            return name;
        }

        public String getClassName() {
            return className;
        }

        public String getInjectorName() {
            return injectorName;
        }

        private FeatureHome() {
        }

        static {
            FeatureHome var0 = new FeatureHome();
            INSTANCE = var0;
            name = "home";
            injectorName = Constants.BASE_PACKAGE_NAME+".home.di.HomeInjector";
            //
            className = Constants.BASE_PACKAGE_NAME +".home.HomeActivity";
        }
    }

    public static final class FeatureSupport implements FeatureModule, AddressableActivity {

        private static final String name;

        private static final String injectorName;
        private static final String className;

        public static final FeatureSupport INSTANCE;

        public String getName() {
            return name;
        }

        public String getClassName() {
            return className;
        }

        public String getInjectorName() {
            return injectorName;
        }

        private FeatureSupport() {
        }

        static {
            FeatureSupport var0 = new FeatureSupport();
            INSTANCE = var0;
            name = "support";
            injectorName = Constants.BASE_PACKAGE_NAME+".support.di.SupportInjector";
            //
            className = Constants.BASE_PACKAGE_NAME +".support.SupportActivity";
        }
    }

    public static final class FeatureWallet implements FeatureModule, AddressableActivity {

        private static final String name;

        private static final String injectorName;

        public static final FeatureWallet INSTANCE;

        private static final String className;


        public String getClassName() {
            return className;
        }

        public String getName() {
            return name;
        }

        public String getInjectorName() {
            return injectorName;
        }

        public static final String ACTION_BUY_AIRTIME = "buyAirtime";
        public static final String ACTION_SAVINGS = "savings";
        public static final String ACTION_PAY_BILLS = "paybills";
        public static final String ACTION_LOANS = "loans";
        public static final String ACTION_FUNDS_TRANSFER = "ft";

        private FeatureWallet() {
        }

        static {
            FeatureWallet var0 = new FeatureWallet();
            INSTANCE = var0;
            name = "wallet";
            injectorName = Constants.BASE_PACKAGE_NAME+".wallet.di.WalletInjector";
            //
            className = Constants.BASE_PACKAGE_NAME +".wallet.MainActivity";
        }
    }

    public static final class FeatureOnboarding implements FeatureModule,AddressableActivity {

        private static final String name;

        private static final String injectorName;

        public static final FeatureOnboarding INSTANCE;

        private static final String className;

        public String getClassName() {
            return className;
        }

        public String getName() {
            return name;
        }

        public String getInjectorName() {
            return injectorName;
        }

        private FeatureOnboarding() {
        }

        static {
            FeatureOnboarding var0 = new FeatureOnboarding();
            INSTANCE = var0;
            name = "onboarding";
            injectorName = Constants.BASE_PACKAGE_NAME+".onboarding.di.OnboardingInjector";
            //
            className = Constants.BASE_PACKAGE_NAME +".onboarding.MainActivity";
        }
    }

    public static final class FeatureAuth implements FeatureModule,AddressableActivity {

        private static final String name;

        private static final String injectorName;

        public static final FeatureAuth INSTANCE;

        private static final String className;

        public String getClassName() {
            return className;
        }

        public String getName() {
            return name;
        }

        public String getInjectorName() {
            return injectorName;
        }

        private FeatureAuth() {
        }

        static {
            FeatureAuth var0 = new FeatureAuth();
            INSTANCE = var0;
            name = "auth";
            injectorName = Constants.BASE_PACKAGE_NAME+".auth.di.AuthInjector";
            //
            className = Constants.BASE_PACKAGE_NAME +".auth.MainActivity";
        }
    }

    public static final class FeatureAccountOpening implements FeatureModule,AddressableActivity {
        private static final String className;

        private static final String name;

        private static final String injectorName;

        public static final FeatureAccountOpening INSTANCE;

        public String getName() {
            return name;
        }

        public String getClassName() {
            return className;
        }

        public String getInjectorName() {
            return injectorName;
        }

        private FeatureAccountOpening() {
        }

        static {
            FeatureAccountOpening var0 = new FeatureAccountOpening();
            INSTANCE = var0;
            name = "accountopening";
            injectorName = Constants.BASE_PACKAGE_NAME+".accountopening.di.InvestmentInjector";
            //
            className = Constants.BASE_PACKAGE_NAME +".accountopening.MainActivity";
        }
    }


}
