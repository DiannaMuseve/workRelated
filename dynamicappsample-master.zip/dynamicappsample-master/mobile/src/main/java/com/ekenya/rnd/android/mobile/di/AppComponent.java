package com.ekenya.rnd.android.mobile.di;

import android.app.Application;
import android.content.Context;

import com.eclectics.securitymodule.IEclecticsSecService;
import com.ekenya.rnd.android.mobile.di.injectables.FragmentModule;
import com.ekenya.rnd.android.mobile.di.injectables.ServicesModule;
import com.ekenya.rnd.android.common.models.UserAccount;
import com.ekenya.rnd.android.common.repo.IAppRepo;
import com.ekenya.rnd.android.mobile.DemoApplication;
import com.ekenya.rnd.android.mobile.di.injectables.ActivityModule;
import com.ekenya.rnd.android.mobile.di.injectables.ViewModelModule;
import com.ekenya.rnd.android.common.services.alertsservice.IAlertsService;
import com.ekenya.rnd.android.common.services.apputils.IAppUtils;
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader;
import com.ekenya.rnd.logginglib.core.ILoggingService;
import com.ekenya.rnd.networklib.networking.NetworkService;
import com.ekenya.rnd.seclib.EncryptionService;
import com.ekenya.rnd.validationslib.InputValidationService;
import com.google.gson.Gson;

import dagger.Component;
import dagger.android.AndroidInjector;
import dagger.android.support.AndroidSupportInjectionModule;
import kotlinx.coroutines.CoroutineScope;

import javax.inject.Singleton;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Singleton
@Component(
        modules = {
                AndroidSupportInjectionModule.class,
                AppModule.class,
                ViewModelModule.class,
                ActivityModule.class,
                FragmentModule.class,
                ServicesModule.class
        }
)
public interface AppComponent extends AndroidInjector<DemoApplication> {
    @NotNull
    Gson getGson();

    @NotNull
    IAppRepo getAppRepo();

    @NotNull
    IImageLoader getImageLoader();

    @NotNull
    IAppUtils getAppUtils();

    @NotNull
    IAlertsService getAlertsService();

    @Nullable
    UserAccount getAppUser();

    @NotNull
    Application getApp();

    @NotNull
    CoroutineScope getCoroutineScope();

    @NotNull
    Context getContext();



    //ECLECTICS SERVICES INJECTION

    @NotNull
    NetworkService getNetworkService();

    @NotNull
    ILoggingService getLoggingService();

    @NotNull
    InputValidationService getInputValidationService();

    @NotNull
    IEclecticsSecService getEclecticsSecService();

    @NotNull
    EncryptionService getEncryptionService();

    //END ECLECTICS SERVICES INJECTION

    @Component.Builder
    public abstract static class Builder extends AndroidInjector.Builder<DemoApplication> {
        @NotNull
        public abstract AppComponent build();
    }
}
