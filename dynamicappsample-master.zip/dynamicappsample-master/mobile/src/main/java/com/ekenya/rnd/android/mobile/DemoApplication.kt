package com.ekenya.rnd.android.mobile

import android.app.Activity
import android.app.Service
import androidx.fragment.app.Fragment
import com.ekenya.rnd.android.common.abstractions.BaseApplication
import com.ekenya.rnd.android.mobile.di.AppComponent
import com.ekenya.rnd.android.mobile.di.BaseModuleInjector
import com.ekenya.rnd.android.mobile.di.DaggerAppComponent
import com.ekenya.rnd.android.mobile.di.helpers.features.FeatureModule
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasActivityInjector
import dagger.android.HasServiceInjector
import dagger.android.support.HasSupportFragmentInjector
import javax.inject.Inject

class DemoApplication: BaseApplication(), HasActivityInjector, HasSupportFragmentInjector,HasServiceInjector {

    // ActivityInjector / FragmentInjector used in the main module
    @Inject
    lateinit var dispatchingActivityInjector: DispatchingAndroidInjector<Activity>
    @Inject
    lateinit var dispatchingFragmentInjector: DispatchingAndroidInjector<Fragment>
    @Inject
    lateinit var dispatchingServiceInjector: DispatchingAndroidInjector<Service>

    // List of ActivityInjector / FragmentInjector used in each Feature module
    private val moduleActivityInjectors = mutableListOf<DispatchingAndroidInjector<Activity>>()
    private val moduleFragmentInjectors = mutableListOf<DispatchingAndroidInjector<Fragment>>()

    // AndroidInjector <Activity> that actually injects
    private val activityInjector = AndroidInjector<Activity> { instance ->
        // If true is returned by maybeInject, Inject is successful

        // Main module
        if (dispatchingActivityInjector.maybeInject(instance)) {
            return@AndroidInjector
        }

        // Each Feature module
        moduleActivityInjectors.forEach { injector ->
            if (injector.maybeInject(instance)) {
                return@AndroidInjector
            }
        }
        throw IllegalStateException("Injector not found for $instance")
    }

    // AndroidInjector <Fragment> that actually injects each
    private val fragmentInjector = AndroidInjector<Fragment> { instance ->
        // If true is returned by maybeInject, Inject is successful

        // Main module
        if (dispatchingFragmentInjector.maybeInject(instance)) {
            return@AndroidInjector
        }

        // Each Feature module
        moduleFragmentInjectors.forEach { injector ->
            if (injector.maybeInject(instance)) {
                return@AndroidInjector
            }
        }
        throw IllegalStateException("Injector not found for $instance")
    }

    // Set for determining whether the Injector of the Feature module has been generated
    private val injectedModules = mutableSetOf<FeatureModule>()

    // Used from AppComponent and Component of each Feature module
    val appComponent by lazy {
        DaggerAppComponent.builder().create(this) as AppComponent
    }

    override fun onCreate() {
        super.onCreate()

        appComponent.inject(this)
    }

    override fun activityInjector(): AndroidInjector<Activity> {
        // Returns the actual Injector
        return activityInjector
    }

    override fun supportFragmentInjector(): AndroidInjector<Fragment> {
        // Returns the actual Injector
        return fragmentInjector
    }

    override fun serviceInjector(): AndroidInjector<Service> {
        return dispatchingServiceInjector
    }

    // Add Injector for Feature module
    // Called just before the Feature module is used after installation
    fun addModuleInjector(module: FeatureModule) {
        if (injectedModules.contains(module)) {
            // Do nothing if added
            return
        }

        // Generate Injector for Feature module
        val clazz = Class.forName(module.injectorName)
        val moduleInjector = clazz.newInstance() as BaseModuleInjector
        // Inject Dispatching Android Injector of Injector of Feature module
        moduleInjector.inject(this)

        // Add to list
        moduleActivityInjectors.add(moduleInjector.activityInjector())
        moduleFragmentInjectors.add(moduleInjector.fragmentInjector())

        injectedModules.add(module)
    }
}