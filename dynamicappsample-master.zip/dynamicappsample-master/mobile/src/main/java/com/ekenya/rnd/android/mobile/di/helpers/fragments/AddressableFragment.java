package com.ekenya.rnd.android.mobile.di.helpers.fragments;

import org.jetbrains.annotations.NotNull;

// AddressableFragment.java
public interface AddressableFragment {
    @NotNull
    String getClassName();
}
