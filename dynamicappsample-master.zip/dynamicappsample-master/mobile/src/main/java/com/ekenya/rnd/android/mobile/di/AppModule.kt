package com.ekenya.rnd.android.mobile.di

import android.app.Application
import android.content.Context
import com.eclectics.securitymodule.IEclecticsSecService
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.common.db.AppDb
import com.ekenya.rnd.android.common.models.UserAccount
import com.ekenya.rnd.android.common.repo.AppRepo
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.repo.mappers.AppDataMappers
import com.ekenya.rnd.android.common.services.alertsservice.AlertsService
import com.ekenya.rnd.android.common.services.alertsservice.IAlertsService
import com.ekenya.rnd.android.common.services.apputils.AppUtils
import com.ekenya.rnd.android.common.services.apputils.IAppUtils
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader
import com.ekenya.rnd.android.common.services.imageloader.ImageLoader
import com.ekenya.rnd.logginglib.core.ILoggingService
import com.ekenya.rnd.networklib.networking.NetworkService
import com.ekenya.rnd.networklib.networking.NetworkServiceImp
import com.ekenya.rnd.seclib.EncryptionService
import com.ekenya.rnd.validationslib.InputValidationService
import com.google.gson.ExclusionStrategy
import com.google.gson.FieldAttributes
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.annotations.Expose
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import org.jetbrains.annotations.Nullable
import javax.inject.Singleton

@Module
class AppModule {

    @Singleton
    @Provides
    fun provideContext(app: DemoApplication): Context {
        return app
    }

    @Singleton
    @Provides
    fun provideApp(context: Context): Application {
        return context.applicationContext as Application
    }

    @Singleton
    @Provides
    fun provideImageLoader(context: Context): IImageLoader {
        return ImageLoader(context)
    }

    @Singleton
    @Provides
    fun provideAppUtils(context: Context): IAppUtils {
        return AppUtils(context)
    }
//    @Singleton
//    @Provides
//    fun providePersistenceService(context: Context): PersistenceService {
//        //
//        return PersistenceServiceImp()
//    }

    //ECLECTICS SERVICES INJECTION
    @Singleton
    @Provides
    fun provideNetworkService(context: Context): NetworkService {
        //
        return NetworkServiceImp()
    }
    @Singleton
    @Provides
    fun provideLoggingService(context: Context): ILoggingService {
        //
        return ILoggingService.getImpl()
    }

    @Singleton
    @Provides
    fun provideValidationsService(context: Context): InputValidationService {
        //
        return InputValidationService.getImpl()
    }

    @Singleton
    @Provides
    fun provideSecurityService(context: Context): IEclecticsSecService {
        //
        return IEclecticsSecService.getImpl()
    }
    @Singleton
    @Provides
    fun provideEncryptionService(context: Context): EncryptionService {
        //
        return EncryptionService.getImpl()
    }
    //END ECLECTICS SERVICES INJECTION

    @Singleton
    @Provides
    fun provideCoroutineScope():CoroutineScope{
        return CoroutineScope(Dispatchers.IO)
    }
    @Singleton
    @Provides
    fun provideAppRepository(context: Context,appDb: AppDb): IAppRepo {
        return AppRepo(appDb, context)
    }

    @Singleton
    @Provides
    fun provideAlertsService(context: Context, appRepo: IAppRepo): IAlertsService {
        return AlertsService(context,appRepo)
    }
    @Singleton
    @Provides
    fun provideAppDatabase(app: Context, coroutineScope: CoroutineScope ):AppDb {
        return AppDb.invoke(app, coroutineScope, app.resources)
    }

    @Singleton
    @Provides
    fun provideGson(): Gson = GsonBuilder() //.excludeFieldsWithoutExposeAnnotation()
        .addSerializationExclusionStrategy(object : ExclusionStrategy {
            override fun shouldSkipField(fieldAttributes: FieldAttributes): Boolean {
                val expose = fieldAttributes.getAnnotation(
                    Expose::class.java
                )
                return expose != null && !expose.serialize
            }

            override fun shouldSkipClass(clazz: Class<*>?): Boolean {
                return false
            }
        })
        .addDeserializationExclusionStrategy(object : ExclusionStrategy {
            override fun shouldSkipField(fieldAttributes: FieldAttributes): Boolean {
                val expose = fieldAttributes.getAnnotation(
                    Expose::class.java
                )
                return expose != null && !expose.deserialize
            }

            override fun shouldSkipClass(clazz: Class<*>?): Boolean {
                return false
            }
        }).create()

    //@Singleton
    @Provides
    @Nullable
    fun provideAppUser(appDb: AppDb): UserAccount? {
        return appDb.usersDao().getAll().value?.get(0)?.let {
            AppDataMappers.createFrom(it)
        }
    }
}