package com.ekenya.rnd.android.mobile.ui

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.ekenya.rnd.android.common.abstractions.BaseActivity
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.mobile.databinding.ActivitySplashBinding
import com.ekenya.rnd.android.mobile.di.helpers.activities.ActivityHelperKt
import com.ekenya.rnd.android.mobile.di.helpers.activities.AddressableActivity
import com.ekenya.rnd.android.mobile.di.helpers.features.FeatureModule
import com.ekenya.rnd.android.mobile.di.helpers.features.Modules
import com.google.android.play.core.splitcompat.SplitCompat
import com.google.android.play.core.splitinstall.SplitInstallManager
import com.google.android.play.core.splitinstall.SplitInstallManagerFactory
import com.google.android.play.core.splitinstall.SplitInstallRequest
import com.google.android.play.core.splitinstall.SplitInstallStateUpdatedListener
import com.google.android.play.core.splitinstall.model.SplitInstallSessionStatus
import dagger.android.AndroidInjector
import kotlinx.android.synthetic.main.activity_splash.*
import javax.inject.Inject

class SplashActivity : BaseActivity() {

    private lateinit var binding: ActivitySplashBinding

    private var mApp: DemoApplication? = null

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    @Inject
    lateinit var mAppRepo: IAppRepo

    private val mViewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(MainViewModel::class.java)
    }

    private val module by lazy {
        Modules.FeatureOnboarding.INSTANCE
    }

    private val splitInstallManager: SplitInstallManager by lazy {
        SplitInstallManagerFactory.create(this)
    }

    private val listener = SplitInstallStateUpdatedListener { state ->
        when (state.status()) {
            SplitInstallSessionStatus.DOWNLOADING -> {
                setStatus("DOWNLOADING")
            }
            SplitInstallSessionStatus.INSTALLING -> {
                setStatus("INSTALLING")
            }
            SplitInstallSessionStatus.INSTALLED -> {

                // Enable module immediately
                SplitCompat.install(this)

                setStatus("Module Ready\n\nPress login to continue ..")
                loginButton.visibility = View.VISIBLE
                binding.downloadProgress.isIndeterminate = false
                binding.loginButton.setOnClickListener {
                    //
                    showFeatureModule(module)
                }
                //
                binding.loginButton.postDelayed({
                    showFeatureModule(module)
                },2000)
            }
            SplitInstallSessionStatus.FAILED -> {
                setStatus("FAILED")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //
        mApp = application as DemoApplication
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //
        if (splitInstallManager.installedModules.contains(module.name)) {
            setStatus("Modules Ready\nPress login to continue ..")
            loginButton.visibility = View.VISIBLE
            binding.downloadProgress.isIndeterminate = false
            binding.loginButton.setOnClickListener {
                showFeatureModule(module)
            }
            //
            binding.loginButton.postDelayed({
                showFeatureModule(module)
            },2000)
            return
        }

        val request = SplitInstallRequest
            .newBuilder()
            .addModule(module.name)
            .build()

        splitInstallManager.startInstall(request)
        binding.downloadProgress.isIndeterminate = true
        setStatus("Start install for ${module.name}")

    }

    /**
     *
     */
    private fun showFeatureModule(module:FeatureModule)
    {
        try {
            //Inject
            mApp!!.addModuleInjector(module)
            //
            val tag = "loginFragment"
            //
            //val fragment = supportFragmentManager.findFragmentByTag(tag) as? BottomSheetDialogFragment ?:
            //FragmentHelperKt.newFragment(Fragments.FeatureIdentity.INSTANCE) as BottomSheetDialogFragment

            //
            //fragment.show(supportFragmentManager, tag)
            //supportFragmentManager.beginTransaction().replace(R.id.fragment_container,fragment).commit()

            var intent  = ActivityHelperKt.intentTo(this, module as AddressableActivity)
            //
            //intent.action = action
            this.startActivity(intent)
            //
            finish()
            //
            //
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (e: Exception) {
            e.message?.let { Log.d("SplashActivity", it) }
        }finally {
        }
    }

    override fun supportFragmentInjector(): AndroidInjector<Fragment> {
        // Fragment Injector should use the Application class
        // If necessary, I will use AndroidInjector as well as App class (I have not done this time)
        return (application as DemoApplication).supportFragmentInjector()
    }

    override fun onResume() {
        super.onResume()
        splitInstallManager.registerListener(listener)
    }

    override fun onPause() {
        splitInstallManager.unregisterListener(listener)
        super.onPause()
    }

    private fun setStatus(label: String){
        binding.status.text = label
    }
}