package com.ekenya.rnd.android.accountopening.di.injectables

import androidx.lifecycle.ViewModel
import com.ekenya.rnd.android.accountopening.ui.main.MainFragment
import com.ekenya.rnd.android.accountopening.ui.main.MainViewModel
import com.ekenya.rnd.android.mobile.di.ViewModelKey
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector
import dagger.multibindings.IntoMap

@Module
abstract class AccountOpeningFragmentModules {

    @ContributesAndroidInjector(modules = [MainFragmentModule::class])
    abstract fun contributeMainFragment(): MainFragment

    @Module
    abstract class MainFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(MainViewModel::class)
        abstract fun bindDashboardViewModel(viewModel: MainViewModel): ViewModel
    }

//    @ContributesAndroidInjector(modules = [PaybillsNotificationDetailFragmentModule::class])
//    abstract fun contributeNotificationDetailFragment(): NotificationDetailFragment
//
//    @Module
//    abstract class PaybillsNotificationDetailFragmentModule {
//        @Binds
//        @IntoMap
//        @ViewModelKey(NotificationsViewModel::class)
//        abstract fun bindNotificationsViewModel(viewModel: NotificationsViewModel): ViewModel
//    }

    //LIST THE OTHER INJECTABLE FRAGMENTS AS ABOVE
}
