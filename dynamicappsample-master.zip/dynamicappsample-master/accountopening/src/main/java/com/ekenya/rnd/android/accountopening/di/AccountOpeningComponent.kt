package com.ekenya.rnd.android.accountopening.di

import com.ekenya.rnd.android.accountopening.di.injectables.AccountOpeningActivityModules
import com.ekenya.rnd.android.accountopening.di.injectables.AccountOpeningFragmentModules
import com.ekenya.rnd.android.mobile.di.AppComponent
import com.ekenya.rnd.android.mobile.di.ModuleScope
import com.ekenya.rnd.android.mobile.di.injectables.ViewModelModule
import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule

@ModuleScope
@Component(
    dependencies = [
        AppComponent::class
    ],
    modules = [
        AndroidSupportInjectionModule::class,
        AccountOpeningActivityModules::class,
        AccountOpeningFragmentModules::class,
        ViewModelModule::class
    ]
)
interface AccountOpeningComponent {
    fun inject(injector: AccountOpeningInjector)
}