package com.ekenya.rnd.android.onboarding

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import com.ekenya.rnd.android.common.abstractions.BaseActivity
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.onboarding.databinding.OnboardingActivityBinding
import com.ekenya.rnd.android.onboarding.ui.main.MainFragment
import dagger.android.AndroidInjector
import javax.inject.Inject

class MainActivity : BaseActivity() {

    @Inject
    lateinit var mAppRepo: IAppRepo

    private lateinit var binding: OnboardingActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = OnboardingActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //
        val toolbar: Toolbar = binding.root.findViewById(com.ekenya.rnd.android.common.R.id.toolbar)
        setSupportActionBar(toolbar)
        //
        supportActionBar?.title  = getString(R.string.title_onboarding)
        //

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.container, MainFragment.newInstance())
                .commitNow()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
                //
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
        }
        return true
    }
    override fun supportFragmentInjector(): AndroidInjector<Fragment> {
        // Fragment Injector should use the Application class
        // If necessary, I will use AndroidInjector as well as App class (I have not done this time)
        return (application as DemoApplication).supportFragmentInjector()
    }
}