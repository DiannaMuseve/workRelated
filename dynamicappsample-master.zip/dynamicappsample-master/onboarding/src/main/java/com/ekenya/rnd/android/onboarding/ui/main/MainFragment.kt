package com.ekenya.rnd.android.onboarding.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.ekenya.rnd.android.mobile.di.helpers.activities.ActivityHelperKt
import com.ekenya.rnd.android.mobile.di.helpers.activities.AddressableActivity
import com.ekenya.rnd.android.mobile.di.helpers.features.FeatureModule
import com.ekenya.rnd.android.mobile.di.helpers.features.Modules
import com.ekenya.rnd.android.mobile.di.helpers.fragments.FragmentHelperKt
import com.ekenya.rnd.android.mobile.di.helpers.fragments.Fragments
import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment
import com.ekenya.rnd.android.common.models.UserAccount
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.onboarding.databinding.OnboardingMainFragmentBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.play.core.splitcompat.SplitCompat
import com.google.android.play.core.splitinstall.SplitInstallManager
import com.google.android.play.core.splitinstall.SplitInstallManagerFactory
import com.google.android.play.core.splitinstall.SplitInstallRequest
import com.google.android.play.core.splitinstall.SplitInstallStateUpdatedListener
import com.google.android.play.core.splitinstall.model.SplitInstallSessionStatus
import javax.inject.Inject

class MainFragment : BaseDaggerFragment() {

    companion object {
        fun newInstance() = MainFragment()
    }
    private var _binding: OnboardingMainFragmentBinding? = null

    @Inject
    lateinit var mAppRepo: IAppRepo
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private val authModule by lazy {
        Modules.FeatureAuth.INSTANCE
    }

    private val splitInstallManager: SplitInstallManager by lazy {
        SplitInstallManagerFactory.create(requireActivity())
    }

    private val listener = SplitInstallStateUpdatedListener { state ->
        //val progressDialog = ProgressDialog(requireActivity())
        when (state.status()) {
            SplitInstallSessionStatus.DOWNLOADING -> {
                setStatus("DOWNLOADING")
            }
            SplitInstallSessionStatus.INSTALLING -> {
                setStatus("INSTALLING")
            }
            SplitInstallSessionStatus.INSTALLED -> {

                // Enable module immediately
                SplitCompat.install(requireContext())

                setStatus("Module Ready\n\nPress login to continue ..")
                binding.loginButton.visibility = View.VISIBLE
                binding.downloadProgress.isIndeterminate = false
                binding.loginButton.setOnClickListener {
                    //
                    showFeatureModule(authModule)
                }
                //
                binding.loginButton.postDelayed({
                    showFeatureModule(authModule)
                },1000)
            }
            SplitInstallSessionStatus.FAILED -> {
                setStatus("FAILED")
            }
        }
    }

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    private val mViewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(MainViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = OnboardingMainFragmentBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.status
//        mViewModel.text.observe(viewLifecycleOwner, Observer {
//            textView.text = it
//        })
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (splitInstallManager.installedModules.contains(authModule.name)) {
            setStatus("Modules Ready\nPress login to continue ..")
            binding.loginButton.visibility = View.VISIBLE
            binding.downloadProgress.isIndeterminate = false
            binding.loginButton.setOnClickListener {
                showFeatureModule(authModule)
            }
            //
            binding.loginButton.postDelayed({
                showFeatureModule(authModule)
            },1000)
            return
        }

        startModuleInstall()
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

    private fun startModuleInstall(){
        val request = SplitInstallRequest
            .newBuilder()
            .addModule(authModule.name)
            .build()

        splitInstallManager.startInstall(request)
        binding.downloadProgress.isIndeterminate = true
        setStatus("Start install for $authModule.name")
    }
    /**
     *Defaults to showing Login Module
     */
    private fun showFeatureModule(module: FeatureModule)
    {
        mAppRepo.getUsers().observe(viewLifecycleOwner,object: Observer<List<UserAccount>> {

            override fun onChanged(users: List<UserAccount>?) {

                if(!users.isNullOrEmpty()){
                    var user = users?.get(0)
                    if(user != null){
                        showHomeFeatureModule()
                        return
                    }
                }


                try {
                    //Inject
                    (requireActivity().application as DemoApplication)!!.addModuleInjector(module)
                    //
                    val tag = "loginFragment"
                    //
                    val fragment = parentFragmentManager.findFragmentByTag(tag) as? BottomSheetDialogFragment
                        ?:
                        FragmentHelperKt.newFragment(Fragments.FeatureIdentity.INSTANCE) as BottomSheetDialogFragment


                    fragment.show(parentFragmentManager, tag)
                    //parentFragmentManager.beginTransaction().replace(R.id.fragment_container,fragment).commit()

//            var intent  = ActivityHelperKt.intentTo(requireContext(), module as AddressableActivity)
//            //
//            //intent.action = action
//            this.startActivity(intent)
                } catch (e: Exception) {
                    e.message?.let { Log.d("OnboardingModule", it) };
                }
                //
                mAppRepo.getUsers().removeObserver(this)
            }
        })
    }

    private fun showHomeFeatureModule(){
        try {
                //
                val module = Modules.FeatureHome.INSTANCE
            //Inject
            (requireActivity().application as DemoApplication)!!.addModuleInjector(module)
            //
            //val tag = "loginFragment"
            //
            //val fragment = supportFragmentManager.findFragmentByTag(tag) as? BottomSheetDialogFragment ?:
            //FragmentHelperKt.newFragment(Fragments.FeatureIdentity.INSTANCE) as BottomSheetDialogFragment

            //
            //fragment.show(supportFragmentManager, tag)
            //supportFragmentManager.beginTransaction().replace(R.id.fragment_container,fragment).commit()

            var intent  = ActivityHelperKt.intentTo(requireActivity(), module as AddressableActivity)
            //
            //intent.action = action
            this.startActivity(intent)
            //
            this.activity?.overridePendingTransition(0, android.R.anim.fade_out)
        } catch (e: Exception) {
            e.message?.let { Log.d("OnboardingModule", it) };
        }finally {
            //
        }
    }

    override fun onResume() {
        super.onResume()
        splitInstallManager.registerListener(listener)
    }

    override fun onPause() {
        splitInstallManager.unregisterListener(listener)
        super.onPause()
    }

    private fun setStatus(label: String){
        binding.status.text = label
    }
}