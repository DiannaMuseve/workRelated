package com.ekenya.rnd.android.onboarding.ui.main


import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.ekenya.rnd.android.common.repo.IAppRepo
import javax.inject.Inject

class MainViewModel @Inject constructor(
    private val IAppRepo: IAppRepo,
    private val app: Application
): AndroidViewModel(app) {


}