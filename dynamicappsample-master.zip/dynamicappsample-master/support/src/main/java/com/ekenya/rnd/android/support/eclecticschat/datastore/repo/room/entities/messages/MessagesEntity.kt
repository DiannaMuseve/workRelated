package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages

import androidx.room.*
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUsersEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUsersTableFields
import java.util.*

@Entity(tableName = MessagesTableFields.TABLE_NAME,
    indices = [Index(value = [MessagesTableFields.COLUMN_ID], unique = true)],
    foreignKeys = [ForeignKey(entity = ChatUsersEntity::class,
        parentColumns = arrayOf(ChatUsersTableFields.COLUMN_ID),
        childColumns = arrayOf(MessagesTableFields.COLUMN_SENDER_ID),
        onUpdate = ForeignKey.CASCADE,
        onDelete = ForeignKey.CASCADE),
//    ForeignKey(
//        entity = GroupsEntity::class,
//        onUpdate = ForeignKey.CASCADE,
//        parentColumns = arrayOf(GroupsTableFields.COLUMN_ID),
//        childColumns = arrayOf(MessagesTableFields.COLUMN_GROUP_ID))
])
data class MessagesEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = MessagesTableFields.COLUMN_ID)
    var id: Int = 0,
    @ColumnInfo(name = MessagesTableFields.COLUMN_ITEM_ID)
    var msgId: String = "",
    @ColumnInfo(name = MessagesTableFields.COLUMN_SENDER_ID,index = true)
    var senderId: Int = 0,
    @ColumnInfo(name = MessagesTableFields.COLUMN_GROUP_ID,index = true)
    var groupId: Int? = null,
    @ColumnInfo(name = MessagesTableFields.COLUMN_GROUP_GUID,index = true)
    var groupGUID: String? = null,
    @ColumnInfo(name = MessagesTableFields.COLUMN_RECEIVER_ID,index = true)
    var receiverId: String? = null,
    @ColumnInfo(name = MessagesTableFields.COLUMN_RECEIVER_NAME,index = true)
    var receiverName: String? = null,
    @ColumnInfo(name = MessagesTableFields.COLUMN_SENDER_GUID,index = true)
    var senderGUID: String = "",
    @ColumnInfo(name = MessagesTableFields.COLUMN_SENDER_NAME,index = true)
    var senderName: String = "",
    @ColumnInfo(name = MessagesTableFields.COLUMN_CONTENT)
    var content: String = "",
    @ColumnInfo(name = MessagesTableFields.COLUMN_STATUS)
    var status: Int = 0,
    @ColumnInfo(name = MessagesTableFields.COLUMN_DATE)
    var date: Date = Calendar.getInstance().time,
    @ColumnInfo(name = MessagesTableFields.COLUMN_KIND)
    var kind: Int = 0,
    @ColumnInfo(name = MessagesTableFields.COLUMN_TAGGED_MSG)
    var taggedMsgId: String? = null

){
    //Empty Contractor
    constructor() : this(0,"",0,0,"","",
        "","","","",0, Calendar.getInstance().time,0,"")
}