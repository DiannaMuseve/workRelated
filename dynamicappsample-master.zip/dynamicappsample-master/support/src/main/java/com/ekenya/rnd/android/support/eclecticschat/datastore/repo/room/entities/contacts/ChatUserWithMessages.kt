package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.Relation
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages.MessagesEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages.MessagesTableFields

@Entity
data class ChatUserWithMessages (

    @Embedded
    val user: ChatUsersEntity,

    @Relation(
        parentColumn = ChatUsersTableFields.COLUMN_ID,
        entityColumn = MessagesTableFields.COLUMN_SENDER_ID
    )
    val messages:List<MessagesEntity>// <-- This is a one-to-many relationship, since each contact has many messages,
                                    // hence returning a List here
    )