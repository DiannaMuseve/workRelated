package com.ekenya.rnd.android.support.eclecticschat.datastore.repo

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.MessageItem

interface IChatRepo {

    fun getService():MutableLiveData<EclecticsQssService>

    fun getAllMessages(): LiveData<List<MessageItem>>
    fun getMessage(id: Int): MessageItem?
    fun getMessage(msgId: String): MessageItem?
    suspend fun addOrUpdateMessage(msg: MessageItem)
    fun getMessagesByGroup(groupId: String): LiveData<List<MessageItem>>

    fun getAllContacts(): LiveData<List<ChatUser>>
    fun getContact(id: Int): ChatUser?
    suspend fun getContact(userId: String): ChatUser?
    suspend fun addOrUpdateContact(contact: ChatUser)
    suspend fun deleteContact(contact: ChatUser)

    fun getAllGroups(): LiveData<List<ChatGroup>>
    fun getGroup(id: Int): ChatGroup?
    fun getGroup(groupId: String): ChatGroup?
    suspend fun addOrUpdateGroup(group: ChatGroup)
    suspend fun deleteGroup(group: ChatGroup)
}