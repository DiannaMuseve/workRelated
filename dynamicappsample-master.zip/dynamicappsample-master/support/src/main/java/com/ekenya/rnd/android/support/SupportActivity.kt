package com.ekenya.rnd.android.support

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import com.ekenya.rnd.android.common.abstractions.BaseActivity
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.common.services.qssservice.WakeReceiver
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.qss.QSSClientService
import com.ekenya.rnd.android.qss.QssServiceResultReceiver
import com.ekenya.rnd.android.support.databinding.SupportActivityMainBinding
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatViewModel
import com.ekenya.rnd.logginglib.core.ILoggingService
import com.ekenya.rnd.validationslib.InputValidationService
import com.google.android.material.bottomnavigation.BottomNavigationView
import dagger.android.AndroidInjector
import javax.inject.Inject

class SupportActivity : BaseActivity() {
    private val TAG = "SupportActivity"

    private lateinit var binding: SupportActivityMainBinding

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    @Inject
    lateinit var mAppRepo: IAppRepo

    @Inject
    lateinit var mLoggingService:ILoggingService
    @Inject
    lateinit var mValidationsService:InputValidationService

    private val mEclecticsChatViewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(EclecticsChatViewModel::class.java)
    }

    private val mSupportViewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(SupportViewModel::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = SupportActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //
        val toolbar: Toolbar = binding.root.findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        //
        //mViewModel = ViewModelProviders.of(this, viewModelFactory).get(MainViewModel.class);

        //
        //mViewModel = ViewModelProviders.of(this, viewModelFactory).get(MainViewModel.class);
        val navView = findViewById<BottomNavigationView>(R.id.nav_view)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration.Builder(
            R.id.navigation_eclectics_support, R.id.navigation_moxtra, R.id.navigation_notifications
        )
            .build()
        val navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main)
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration)
        NavigationUI.setupWithNavController(binding.navView, navController)

        //setupActionBarWithNavController(navController, appBarConfiguration)
        //navView.setupWithNavController(navController)
        //
        supportActionBar?.title  = getString(R.string.title_support)
        //
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        Log.i(TAG, "Launch service..")
        // Starts the service..
        //
        WakeReceiver.setQssWakeAlarm(true,this, QssServiceResultReceiver(Handler(),mQssServiceBinder)) /* true will force the broadcast */
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }
        }
        return true
    }
    override fun supportFragmentInjector(): AndroidInjector<Fragment> {
        // Fragment Injector should use the Application class
        // If necessary, I will use AndroidInjector as well as App class (I have not done this time)
        return (application as DemoApplication).supportFragmentInjector()
    }

    override fun onStart()
    {
        super.onStart()
        var intent = Intent(
            this,
            EclecticsQssService::class.java)
        //
        bindService(intent,
            mServiceConnection,
            Context.BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        super.onStop()
        //
        unbindService(mServiceConnection)
    }


    private val mServiceConnection: ServiceConnection = object : ServiceConnection {

        override fun onServiceConnected(name: ComponentName, service: IBinder) {
//            Log.i(TAG, "Service connected.")
//            var mService = (service as QSSClientService.LocalBinder).service as EclecticsQssService
//            //
//            //Update callbacks
//            mEclecticsChatViewModel.getService()?.postValue(mService)
//            mSupportViewModel.getService().postValue(mService)
        }

        override fun onServiceDisconnected(name: ComponentName) {
            //notify callbacks
            mEclecticsChatViewModel.getService()?.postValue(null)
            mSupportViewModel.getService().postValue(null)
        }
    }

    private val mQssServiceBinder = object : QssServiceResultReceiver.IQssServiceBinder {

        override fun onBind(service: QSSClientService) {
            Log.i(TAG, "Service connected.")
            //Update callbacks
            val srv = service as EclecticsQssService
            srv.mAlertEntryActivity =  this@SupportActivity
            mEclecticsChatViewModel.getService()?.postValue(srv)
            mSupportViewModel.getService().postValue(srv)
        }

        override fun onUnbind() {
            //
        }

    }
}