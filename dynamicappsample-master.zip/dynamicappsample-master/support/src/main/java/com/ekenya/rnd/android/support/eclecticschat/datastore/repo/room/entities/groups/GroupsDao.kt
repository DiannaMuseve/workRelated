package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface GroupsDao {

    @Delete
    suspend fun delete(group: GroupsEntity)

    @Update
    suspend fun update(group: GroupsEntity)

    @Transaction
    @Query("SELECT * FROM "+ GroupsTableFields.TABLE_NAME+" WHERE "+ GroupsTableFields.COLUMN_ID+" = :id")
    fun getById(id: Int): GroupWithMembers

    @Transaction
    @Query("SELECT * FROM "+ GroupsTableFields.TABLE_NAME+" WHERE "+ GroupsTableFields.COLUMN_ITEM_ID+" = :groupId")
    fun getById(groupId: String): GroupWithMembers

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(group: List<GroupsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(group: GroupsEntity)

    @Query("SELECT * FROM "+ GroupsTableFields.TABLE_NAME+"  ORDER BY "+ GroupsTableFields.COLUMN_DATE+" DESC")
    fun getAll(): LiveData<List<GroupsEntity>>

    @Transaction
    @Query("SELECT * FROM "+ GroupsTableFields.TABLE_NAME+"  ORDER BY "+ GroupsTableFields.COLUMN_DATE+" DESC")
    fun getGroupsAndMembers():LiveData<List<GroupWithMembers>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(join: GroupToMemberBridgeEntity)
}