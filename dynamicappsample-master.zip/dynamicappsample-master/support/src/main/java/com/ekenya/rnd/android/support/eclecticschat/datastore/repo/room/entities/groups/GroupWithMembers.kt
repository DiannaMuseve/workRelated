package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUsersEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUsersTableFields
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages.MessagesEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages.MessagesTableFields

data class GroupWithMembers(
    @Embedded
    val group: GroupsEntity,

    @Relation(
        parentColumn = GroupsTableFields.COLUMN_ID,
        entity = ChatUsersEntity::class,
        entityColumn = ChatUsersTableFields.COLUMN_ID,
        associateBy = Junction(
            value = GroupToMemberBridgeEntity::class,
            parentColumn = "groupId",
            entityColumn = "userId"
        )
    )
    val members:List<ChatUsersEntity>,

    @Relation(
        parentColumn = GroupsTableFields.COLUMN_ID,
        entityColumn = MessagesTableFields.COLUMN_GROUP_ID
    )
    val lastMessage: MessagesEntity

    )
