package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts


/**
 * Created by Bourne Koloh on 02 July,2020.
 * Eclectics International, Products and R&D
 * PROJECT: Lending Manager
 */
class ChatUsersTableFields {

    companion object {
        const val TABLE_NAME = "contacts_table"

        const val COLUMN_ID = "id"
        const val COLUMN_USER_ID = "userId"
        const val COLUMN_PHONE = "phone"
        const val COLUMN_OTHER_PHONES = "otherPhones"
        const val COLUMN_NAME = "name"
        const val COLUMN_EMAILS = "emails"
        const val COLUMN_PHOTO = "photo"
        const val COLUMN_DATE = "date"
    }
}