package com.ekenya.rnd.android.support.eclecticschat.base;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.ekenya.rnd.android.common.abstractions.BaseBottomSheetDialogFragment;
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService;
import com.ekenya.rnd.android.qss.beans.QssUser;
import com.ekenya.rnd.android.support.databinding.DialogAddGroupBinding;
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatViewModel;
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser;
import com.google.android.material.textfield.TextInputEditText;
import com.stfalcon.chatkit.dialogs.DialogsList;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class NewGroupFragment extends BaseBottomSheetDialogFragment {
    @Inject
    public ViewModelProvider.Factory viewModelFactory;
    DialogAddGroupBinding mBinding;

    private EclecticsChatViewModel mViewModel;

    private DialogsList dialogsList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.BottomSheetTheme);
        //
        mViewModel = ViewModelProviders.of(getActivity(), viewModelFactory).get(EclecticsChatViewModel.class);

    }

    public void onStart()
    {
        super.onStart();    
        //super.onStart() is where dialog.show() is actually called on the underlying dialog, so we have to do it after this point
        AlertDialog d = (AlertDialog)getDialog();
        if(d != null)
        {
            Button positiveButton = (Button) d.getButton(Dialog.BUTTON_POSITIVE);
            positiveButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                   //
                }
            });
        }
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        //
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){

        mBinding = DialogAddGroupBinding.inflate(getLayoutInflater());
        //
        TextInputEditText mName = mBinding.groupName;
        //
        MultiAutoCompleteTextView mGroupMembers = mBinding.groupMembers;
        List<String> membersList = new ArrayList<>();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_dropdown_item_1line,
                membersList);
        mGroupMembers.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        //
        List<ChatUser> usersList = new ArrayList<>();
        //
        mViewModel.getService().observe(this, new Observer<EclecticsQssService>() {
            @Override
            public void onChanged(EclecticsQssService messengerService) {
                //
                messengerService.getOnlineUsers().observe(NewGroupFragment.this, new Observer<List<QssUser>>() {
                    @Override
                    public void onChanged(List<QssUser> qssUsers) {
                        //
                        adapter.clear();
                        //
                        for (QssUser map : qssUsers) {
                            //
                            usersList.add(new ChatUser(map.getId(),map.getName(),map.getPhoto(),false));
                            //
                            adapter.add(map.getName());
                        }
                        //
                        if(qssUsers.size() < 20)
                            mGroupMembers.setThreshold(0);
                        else if(qssUsers.size() < 40)
                            mGroupMembers.setThreshold(1);
                        else
                            mGroupMembers.setThreshold(2);


                        //Force the adapter to filter itself, necessary to show new data.
                        //Filter based on the current text because api call is asynchronous.
                        adapter.notifyDataSetChanged();
                        adapter.getFilter().filter(mGroupMembers.getText(), null);
                        //
                        int count = adapter.getCount();
                    }
                });
            }
        });
        //
        mGroupMembers.setAdapter(adapter);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity(), android.R.style.Theme_Holo_Light_Dialog);
        //
        builder
                .setTitle("Create New Group")
                .setView(mBinding.getRoot())
                .setNeutralButton("Create", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String name = mName.getText().toString();
                        if(name.length() == 0){
                            mName.setError("Please enter a group name ..");
                            return;
                        }
                        String members = mGroupMembers.getText().toString();
                        //
                        List<ChatUser> selection = new ArrayList<>();
                        for (String m: members.split(",")) {
                            //
                            for (ChatUser usr:  usersList) {
                                if(usr.getName().equalsIgnoreCase(m)){
                                    selection.add(usr);
                                    break;
                                }
                            }
                        }
                        //
                        if(selection.isEmpty()){
                            mName.setError("Please select some group members ..");
                            return;
                        }
                        //
                        attemptCreateGroup(name,selection);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                //
        Dialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        return dialog;
    }

    private void attemptCreateGroup(String name, List<ChatUser> members){
        //

        mViewModel.createGroup(name,members).subscribe();
    }
}
