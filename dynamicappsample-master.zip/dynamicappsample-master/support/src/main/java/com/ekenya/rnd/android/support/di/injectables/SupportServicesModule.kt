package com.ekenya.rnd.android.support.di.injectables

import dagger.Module
import dagger.Provides
import dagger.android.ContributesAndroidInjector

@Module
abstract class SupportServicesModule {
//    var mService: EclecticsSupportService
//    @Provides
//    fun provideEclecticsSupportService(): EclecticsSupportService {
//        return mService
//    }
//    init {
//        mService = service
//    }
//    constructor(service: EclecticsSupportService){
//        mService = service
//    }

//    @ContributesAndroidInjector
//    abstract fun contributeSupportService(): EclecticsSupportService
}