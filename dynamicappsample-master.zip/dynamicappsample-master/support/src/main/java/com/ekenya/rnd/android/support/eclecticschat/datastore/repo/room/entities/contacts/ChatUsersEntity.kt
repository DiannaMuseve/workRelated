package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts

import androidx.room.*
import java.util.*


/**
 * Created by Bourne Koloh on 02 July,2020.
 * Eclectics International, Products and R&D
 * PROJECT: Lending Manager
 */
@Entity(tableName = ChatUsersTableFields.TABLE_NAME,
    indices = [Index(value = [ChatUsersTableFields.COLUMN_ID, ChatUsersTableFields.COLUMN_PHONE],
        unique = true)])
data class ChatUsersEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_ID)
    var id: Int,
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_USER_ID)
    var userId: String,
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_NAME)
    var name: String,
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_EMAILS)
    var emails: String,
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_PHONE)
    var phone: String = "",
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_OTHER_PHONES)
    var otherPhones: String,
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_PHOTO)
    var photo: String?,
    @ColumnInfo(name = ChatUsersTableFields.COLUMN_DATE)
    var date: Date

){

    //Empty Contractor
    constructor() : this(0,"","","","","","", Calendar.getInstance().time)
}