package com.ekenya.rnd.android.support

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import javax.inject.Inject

class SupportViewModel  @Inject constructor(
    private val app: Application,
    private val appDb:IAppRepo
): AndroidViewModel(app) {

    private var service: MutableLiveData<EclecticsQssService> = appDb.getService()

    public fun getService():MutableLiveData<EclecticsQssService>{
        return  service
    }
}