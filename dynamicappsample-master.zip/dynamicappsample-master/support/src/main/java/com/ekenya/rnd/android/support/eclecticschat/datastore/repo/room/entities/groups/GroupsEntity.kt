package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = GroupsTableFields.TABLE_NAME,
    indices = [Index(value = [GroupsTableFields.COLUMN_ID], unique = true)])
data class GroupsEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = GroupsTableFields.COLUMN_ID)
    var id: Int,
    @ColumnInfo(name = GroupsTableFields.COLUMN_ITEM_ID)
    var itemId: String,
    @ColumnInfo(name = GroupsTableFields.COLUMN_TITLE)
    var title: String,
    @ColumnInfo(name = GroupsTableFields.COLUMN_CONTENT)
    var content: String,
    @ColumnInfo(name = GroupsTableFields.COLUMN_FULL_CONTENT)
    var fullContent: String,
    @ColumnInfo(name = GroupsTableFields.COLUMN_SEEN)
    var seen: Boolean,
    @ColumnInfo(name = GroupsTableFields.COLUMN_ICON)
    var icon: String?,
    @ColumnInfo(name = GroupsTableFields.COLUMN_DATE)
    var date: Date

){
    //Empty Contractor
    constructor() : this(0,"","","","",false,null, Calendar.getInstance().time)
}