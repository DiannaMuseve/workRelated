package com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels;

import com.ekenya.rnd.android.qss.beans.QssGroup;
import com.google.gson.annotations.Expose;
import com.stfalcon.chatkit.commons.models.IDialog;

import java.util.ArrayList;
import java.util.List;

public class ChatGroup extends QssGroup implements IDialog<MessageItem>  {
    public enum GroupType{
        DIRECT, GROUPED
    }

    @Expose(serialize = false)
    private MessageItem lastMessage;

    @Expose(serialize = false)
    private int unreadCount;

    @Expose(serialize = false)
    private GroupType type = GroupType.GROUPED;

    @Expose(serialize = false)
    private List<ChatUser> members = new ArrayList<>();

    public ChatGroup(String id, String name, String photo, List<ChatUser> users, MessageItem lastMessage, int unreadCount) {
        super(id, name, photo, users);
        this.lastMessage = lastMessage;
        this.unreadCount = unreadCount;
    }

    @Override
    public String getId() {
        return super.getId();
    }

    @Override
    public String getDialogPhoto() {
        return super.getPhoto();
    }

    @Override
    public String getDialogName() {
        return super.getName();
    }

    @Override
    public List<ChatUser> getUsers() {
        return (List<ChatUser>) super.getMembers();
    }

    @Override
    public MessageItem getLastMessage() {
        return lastMessage;
    }

    @Override
    public void setLastMessage(MessageItem lastMessage) {
        this.lastMessage = lastMessage;
    }

    @Override
    public int getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(int unreadCount) {
        this.unreadCount = unreadCount;
    }

    public GroupType getType() {
        return type;
    }

    public void setType(GroupType type) {
        this.type = type;
    }
}
