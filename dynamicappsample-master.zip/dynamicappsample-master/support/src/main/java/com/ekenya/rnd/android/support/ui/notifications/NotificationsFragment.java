package com.ekenya.rnd.android.support.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment;
import com.ekenya.rnd.android.common.models.NotificationItem;
import com.ekenya.rnd.android.common.repo.IAppRepo;
import com.ekenya.rnd.android.common.ui.adapters.GenericRecyclerAdapter;
import com.ekenya.rnd.android.support.SupportViewModel;
import com.ekenya.rnd.android.support.SupportViewModel;
import com.ekenya.rnd.android.support.databinding.FragmentSupportNotificationsBinding;

import java.util.List;

import javax.inject.Inject;


public class NotificationsFragment extends BaseDaggerFragment {
    @Inject
    public ViewModelProvider.Factory viewModelFactory;
    @Inject
    public IAppRepo mAppRepo;
    @Inject
    public NotificationsAdapter mAdapter;

    private RecyclerView mListView;

    private SwipeRefreshLayout mRefreshLayout;

    private View mEmptyLayout;

    private NotificationsViewModel notificationsViewModel;
    private SupportViewModel mSupportViewModel;
    //
    private FragmentSupportNotificationsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //
        notificationsViewModel = new ViewModelProvider(this, viewModelFactory).get(NotificationsViewModel.class);
        mSupportViewModel = new ViewModelProvider(this, viewModelFactory).get(SupportViewModel.class);
        //
        binding = FragmentSupportNotificationsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //
        ViewGroup wrapper = binding.notificationsContent;//root.findViewById<ViewGroup>(R.id.dashboard_content)

        //
        View listGroup = inflater.inflate(com.ekenya.rnd.android.common.R.layout.list_rv_item, container, false);
        mListView = listGroup.findViewById(com.ekenya.rnd.android.common.R.id.list);
        //
        LinearLayoutManager manager = new LinearLayoutManager(requireActivity(), RecyclerView.VERTICAL, false);
        mListView.setLayoutManager(manager);
        //
        //
        LayoutAnimationController controller = AnimationUtils.loadLayoutAnimation( requireActivity(), com.ekenya.rnd.android.common.R.anim.layout_animation_fall_down);
        mListView.setLayoutAnimation(controller);

        mRefreshLayout = listGroup.findViewById(com.ekenya.rnd.android.common.R.id.refresh);
        mEmptyLayout = listGroup.findViewById(com.ekenya.rnd.android.common.R.id.empty_wrapper);
        TextView emptyCaption = listGroup.findViewById(com.ekenya.rnd.android.common.R.id.empty_caption);
        //emptyCaption.setTextColor(getResources().getColor(android.R.color.white));
        emptyCaption.setText("No Alerts");
        wrapper.removeAllViews();
        //
        wrapper.addView(listGroup);

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mAdapter.setMode(GenericRecyclerAdapter.Orientation.VERTICAL);
        mAdapter.getCallbacks().add(new NotificationsAdapter.NotificationsCallback() {
            @Override
            public void onMenuClicked(View row, NotificationItem service, MenuItem menu) {

            }

            @Override
            public void onClick(View row, NotificationItem service) {

            }

            @Override
            public void onLongClick(View row, NotificationItem service) {

            }
        });
        mListView.setAdapter(mAdapter);
        mRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                updateContent();
            }
        });
        //
        updateContent();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        //
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void setUserVisibleHint(boolean visible)
    {
        super.setUserVisibleHint(visible);
        if (visible && isResumed())
        {
            //Only manually call onResume if fragment is already visible
            //Otherwise allow natural fragment lifecycle to call onResume
            onResume();
        }
    }

    @Override
    public void onResume()
    {
        super.onResume();
        if (!getUserVisibleHint())
        {
            return;
        }

        //INSERT CUSTOM CODE HERE
        ((AppCompatActivity)requireActivity()).getSupportActionBar().setTitle("Eclectics Qss Notifications");
    }

    private void updateContent(){
        //
        notificationsViewModel.getAlertList().observe(getViewLifecycleOwner(), new Observer<List<NotificationItem>>() {
            @Override
            public void onChanged(@Nullable List<NotificationItem> list) {

                mAdapter.addAll(list);
                //
                if(list.isEmpty()){
                    mEmptyLayout.setVisibility(View.VISIBLE);
                }else{
                    mEmptyLayout.setVisibility(View.GONE);
                }
                mRefreshLayout.setRefreshing(false);
            }
        });
    }
}