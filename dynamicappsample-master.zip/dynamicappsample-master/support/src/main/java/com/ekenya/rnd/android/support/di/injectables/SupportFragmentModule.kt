package com.ekenya.rnd.android.support.di.injectables

import androidx.lifecycle.ViewModel
import com.ekenya.rnd.android.mobile.di.ViewModelKey
import com.ekenya.rnd.android.support.SupportViewModel
import com.ekenya.rnd.android.support.ui.moxtra.MoxtraChatFragment
import com.ekenya.rnd.android.support.ui.moxtra.MoxtraChatViewModel
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatFragment
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatViewModel
import com.ekenya.rnd.android.support.eclecticschat.base.NewGroupFragment
import com.ekenya.rnd.android.support.ui.eclectics.directchat.QssChatGroupsFragment
import com.ekenya.rnd.android.support.ui.eclectics.directchat.QssMessagesFragment
import com.ekenya.rnd.android.support.ui.eclectics.supportchat.QssSupportFragment
import com.ekenya.rnd.android.support.ui.notifications.NotificationsFragment
import com.ekenya.rnd.android.support.ui.notifications.NotificationsViewModel
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector
import dagger.multibindings.IntoMap

@Module
abstract class SupportFragmentModule {

    @ContributesAndroidInjector(modules = [MainFragmentModule::class])
    abstract fun contributeMoxtraChatFragment(): MoxtraChatFragment

    @Module
    abstract class MainFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(MoxtraChatViewModel::class)
        abstract fun bindMoxtraChatViewModel(viewModel: MoxtraChatViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [HomeFragmentModule::class])
    abstract fun contributeEclecticsChatFragment(): EclecticsChatFragment

    @Module
    abstract class HomeFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(EclecticsChatViewModel::class)
        abstract fun bindEclecticsChatViewModel(viewModel: EclecticsChatViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [NotificationsFragmentModule::class])
    abstract fun contributeNotificationsFragment(): NotificationsFragment

    @Module
    abstract class NotificationsFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(NotificationsViewModel::class)
        abstract fun bindNotificationsViewModel(viewModel: NotificationsViewModel): ViewModel
        @Binds
        @IntoMap
        @ViewModelKey(SupportViewModel::class)
        abstract fun bindSupportViewModel(viewModel: SupportViewModel): ViewModel
    }

    //LIST THE OTHER INJECTABLE FRAGMENTS AS ABOVE

    @ContributesAndroidInjector(modules = [QssChatGroupsFragmentModule::class])
    abstract fun contributeQssChatGroupsFragment(): QssChatGroupsFragment

    @Module
    abstract class QssChatGroupsFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(EclecticsChatViewModel::class)
        abstract fun bindEclecticsChatViewModel(viewModel: EclecticsChatViewModel): ViewModel
        @Binds
        @IntoMap
        @ViewModelKey(SupportViewModel::class)
        abstract fun bindSupportViewModel(viewModel: SupportViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [QssMessagesFragmentModule::class])
    abstract fun contributeQssMessagesFragment(): QssMessagesFragment

    @Module
    abstract class QssMessagesFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(EclecticsChatViewModel::class)
        abstract fun bindEclecticsChatViewModel(viewModel: EclecticsChatViewModel): ViewModel
        @Binds
        @IntoMap
        @ViewModelKey(SupportViewModel::class)
        abstract fun bindSupportViewModel(viewModel: SupportViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [QssSupportFragmentModule::class])
    abstract fun contributeQssSupportFragment(): QssSupportFragment

    @Module
    abstract class QssSupportFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(EclecticsChatViewModel::class)
        abstract fun bindEclecticsChatViewModel(viewModel: EclecticsChatViewModel): ViewModel
        @Binds
        @IntoMap
        @ViewModelKey(SupportViewModel::class)
        abstract fun bindSupportViewModel(viewModel: SupportViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [NewGroupFragmentModule::class])
    abstract fun contributeNewGroupFragment(): NewGroupFragment

    @Module
    abstract class NewGroupFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(EclecticsChatViewModel::class)
        abstract fun bindEclecticsChatViewModel(viewModel: EclecticsChatViewModel): ViewModel
    }
}
