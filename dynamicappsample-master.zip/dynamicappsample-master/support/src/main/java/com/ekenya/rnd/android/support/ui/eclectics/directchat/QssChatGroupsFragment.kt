package com.ekenya.rnd.android.support.ui.eclectics.directchat

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.apputils.IAppUtils
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader
import com.ekenya.rnd.android.support.R
import com.ekenya.rnd.android.support.databinding.FragmentDirectChatDialogsBinding
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatViewModel
import com.ekenya.rnd.android.support.eclecticschat.base.DemoDialogsFragment
import com.ekenya.rnd.android.support.eclecticschat.base.NewGroupFragment
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.dialogs.DialogsList
import com.stfalcon.chatkit.dialogs.DialogsListAdapter
import com.stfalcon.chatkit.utils.DateFormatter
import java.util.*
import javax.inject.Inject

class QssChatGroupsFragment :
    DemoDialogsFragment(), DateFormatter.Formatter {

    private val TAG = QssChatGroupsFragment::class.java.simpleName

    private val mViewModel by lazy {
        ViewModelProviders.of(requireActivity(), viewModelFactory).get(EclecticsChatViewModel::class.java)
    }

    lateinit var binding: FragmentDirectChatDialogsBinding

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    @Inject
    lateinit var mImageLoader: IImageLoader

    @Inject
    lateinit var mAppUtils: IAppUtils

    @Inject
    lateinit var mChatRepo: IChatRepo
    @Inject
    lateinit var mAppRepo: IAppRepo

    private lateinit var dialogsList: DialogsList
    private lateinit var mRefreshLayout: SwipeRefreshLayout
    private lateinit var mEmptyView: TextView

    private lateinit var mFabDirectChat:FloatingActionButton
    private lateinit var mFabGroupChat:FloatingActionButton
    private lateinit var mFabStart:FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //getActionBar().setTitle("Default Dialogs/Groups");
        //
        imageLoader = ImageLoader { imageView, url, payload ->
            mImageLoader.loadImage(url,com.ekenya.rnd.android.common.R.drawable.logo_sm,imageView)
        }
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {

        binding = FragmentDirectChatDialogsBinding.inflate(inflater, container, false)
        val root: View = binding.getRoot()

        dialogsList = root.findViewById<View>(R.id.dialogsList) as DialogsList
        //
        //
        mRefreshLayout = root.findViewById<View>(R.id.swipe_refresh) as SwipeRefreshLayout
        mEmptyView = root.findViewById<View>(R.id.empty_label) as TextView
        mRefreshLayout.isRefreshing = true
        mRefreshLayout.setOnRefreshListener {
            // Your code to refresh the list here.
            // Make sure you call swipeContainer.setRefreshing(false)
            // once the network request has completed successfully.
            reloadGroups()
        }
        mFabDirectChat = root.findViewById<FloatingActionButton>(R.id.fab_direct_chat)
        mFabDirectChat.setOnClickListener { //
            showChooseReceiver()
        }
        mFabGroupChat = root.findViewById<FloatingActionButton>(R.id.fab_group)
        mFabGroupChat.setOnClickListener {
            var fragment: NewGroupFragment? = childFragmentManager.findFragmentByTag(
                NewGroupFragment::class.java.getSimpleName()
            ) as NewGroupFragment?
            if (fragment == null) {
                fragment =
                    NewGroupFragment()
            }
            //
            fragment.show(childFragmentManager, NewGroupFragment::class.java.getSimpleName())
        }

        mFabStart = root.findViewById<FloatingActionButton>(R.id.fab_start)
        mFabStart.setOnClickListener {
            toggleStartFab()
        }
        return root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initAdapter()
        mRefreshLayout.isRefreshing = false


    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)        //
        //getView().setBackgroundColor(getResources().getColor(android.R.color.transparent));
        mViewModel.getService().observe(this ) { messengerService ->
            //
            messengerService.connectQss(false)
        }
        //
        mViewModel.getGroups().observe(this, object : Observer<List<ChatGroup>> {
            override fun onChanged(items: List<ChatGroup>) {
                //
                //Collections.reverse(Arrays.asList(items));
                //Sort descending by date
                Collections.sort(items, object : Comparator<ChatGroup> {
                    override fun compare(lhs: ChatGroup, rhs: ChatGroup): Int {
                        // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                        try {
                            if (lhs.lastMessage != null && rhs.lastMessage != null) {
                                //
                                return if (lhs.lastMessage.createdAt.time > rhs.lastMessage.createdAt.time) -1 else if (lhs.lastMessage.createdAt.time < rhs.lastMessage.createdAt.time) 1 else 0
                            } else if (lhs.lastMessage != null) {
                                return if (lhs.lastMessage.createdAt.time > rhs.dateAdded.time) -1 else if (lhs.lastMessage.createdAt.time < rhs.dateAdded.time) 1 else 0
                            } else if (rhs.lastMessage != null) {
                                return if (rhs.lastMessage.createdAt.time > lhs.dateAdded.time) -1 else if (rhs.lastMessage.createdAt.time < lhs.dateAdded.time) 1 else 0
                            }
                            //
                            return if (lhs.dateAdded.time > rhs.dateAdded.time) -1 else if (lhs.dateAdded.time < rhs.dateAdded.time) 1 else 0
                        } catch (e: Exception) {
                        }
                        return -1
                    }
                })
                //
                dialogsAdapter.addItems(items)
                dialogsAdapter.notifyDataSetChanged()
                //
                if (!items.isEmpty()) {
                    view!!.findViewById<View>(R.id.empty_label).visibility = View.GONE
                } else {
                    view!!.findViewById<View>(R.id.empty_label).visibility = View.VISIBLE
                }
            }
        })
    }

    override fun setUserVisibleHint(visible: Boolean) {
        super.setUserVisibleHint(visible)
        if (visible && isResumed) {
            //Only manually call onResume if fragment is already visible
            //Otherwise allow natural fragment lifecycle to call onResume
            onResume()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!userVisibleHint) {
            return
        }

        //INSERT CUSTOM CODE HERE
        //
        (activity as AppCompatActivity?)!!.supportActionBar!!.setTitle("Eclectics Direct Chat")
        //
        (activity as AppCompatActivity?)!!.supportActionBar!!.setSubtitle("All My Conversations")
    }
    override fun onDialogClick(dialog: ChatGroup) {
        //
        toggleStartFab()
        //
        val tag = QssMessagesFragment::class.java.getSimpleName()
        var fragment: QssMessagesFragment? = childFragmentManager
            .findFragmentByTag(tag) as QssMessagesFragment?
        if (fragment == null) fragment = QssMessagesFragment()
        if(dialog?.type == ChatGroup.GroupType.GROUPED) {
            fragment.setGroup(dialog)
            fragment.setReceiver(null)
        }else{
            //
            fragment.setGroup(null)
            dialog.users.firstOrNull {
                it.id == dialog.id.split('|')[0]
            }?.let {
                fragment.setReceiver(it)
            }?:run{
                Log.w(TAG,"Dialog Owner not found")
                return
            }
        }
        //Replace from Activity elevel

        //Replace from Activity elevel
//        childFragmentManager
//            .beginTransaction()
//            .replace(R.id.dialogs_content, fragment, tag)
//            .addToBackStack(QssMessagesFragment::class.java.getName())
//            .commit()
        fragment.show(childFragmentManager,tag)
        //

    }

    override fun onDialogLongClick(dialog: ChatGroup?) {
        //
        mAppUtils.showToast(dialog!!.dialogName,false)
    }
    override fun format(date: Date): String {
        return if (DateFormatter.isToday(date)) {
            DateFormatter.format(date, DateFormatter.Template.TIME)
        } else if (DateFormatter.isYesterday(date)) {
            getString(R.string.date_header_yesterday)
        } else if (DateFormatter.isCurrentYear(date)) {
            DateFormatter.format(date, DateFormatter.Template.STRING_DAY_MONTH)
        } else {
            DateFormatter.format(date, DateFormatter.Template.STRING_DAY_MONTH_YEAR)
        }
    }

    private fun toggleStartFab(){

        if (!fabsClosed) {
            //
            mFabDirectChat.startAnimation(fromBottom)
            mFabGroupChat.startAnimation(fromBottom)
            mFabStart.startAnimation(rotateOpen)

            //
            mFabDirectChat.visibility = View.VISIBLE
            mFabGroupChat.visibility = View.VISIBLE
        } else {
            //
            mFabDirectChat.startAnimation(toBottom)
            mFabGroupChat.startAnimation(toBottom)
            mFabStart.startAnimation(rotateClose)
            //
            mFabDirectChat.visibility = View.INVISIBLE
            mFabGroupChat.visibility = View.INVISIBLE
        }
        fabsClosed = !fabsClosed
    }

    private  fun reloadGroups(){
        mRefreshLayout.isRefreshing = true
        //
        mViewModel.getGroups().observe(this, object : Observer<List<ChatGroup>>{
            override fun onChanged(list: List<ChatGroup>) {
                //
                dialogsAdapter.setItems(list)
                //
                mEmptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.INVISIBLE
                //
                mRefreshLayout.isRefreshing = false
                //
                //mViewModel.getGroups().removeObserver(this)
            }
        })

    }

    private fun initAdapter() {
        super.dialogsAdapter = DialogsListAdapter(super.imageLoader)
        //
        super.dialogsAdapter.setOnDialogClickListener(this)
        super.dialogsAdapter.setOnDialogLongClickListener(this)
        super.dialogsAdapter.setDatesFormatter(this)
        dialogsList.setAdapter(super.dialogsAdapter)
        //
        reloadGroups()
    }

    protected fun showChooseReceiver() {
        //
        val onlineUsers: MutableList<ChatUser> = ArrayList()
        val adapter = object : ArrayAdapter<ChatUser>(
            requireContext(),
            android.R.layout.select_dialog_singlechoice, android.R.id.text1, onlineUsers
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                // User super class to create the View
                val view = super.getView(position, convertView, parent)
                val tv = view.findViewById<TextView>(android.R.id.text1)

                // Put the image on the TextView
                // tv.setCompoundDrawablesWithIntrinsicBounds(users.get(position).icon, null,null, null);
                tv.text = onlineUsers[position].name
                // Add margin between image and text (support various screen densities)
                val dp10 = (10 * context.resources.displayMetrics.density + 0.5f).toInt()
                tv.compoundDrawablePadding = dp10
                return view
            }
        }
        val svc = mViewModel.getService().value

        svc?.onlineUsers?.observe(this) { chatUsers ->
            onlineUsers.clear()
            for (u in chatUsers) {
                onlineUsers.add(
                    ChatUser(
                        u.id,
                        u.name,
                        u.photo,
                        true
                    )
                )
            }
            adapter.notifyDataSetChanged()
        }
        //
        val builder = AlertDialog.Builder(context, android.R.style.Theme_Holo_Light_Dialog) //
            .setTitle("Select Recipient ..")
            .setAdapter(adapter) { dialogInterface, i ->
                //
                toggleStartFab()
                //
                val usr = onlineUsers[i]
                //
                val tag = QssMessagesFragment::class.java.getSimpleName()
                var fragment: QssMessagesFragment? = childFragmentManager
                    .findFragmentByTag(tag) as QssMessagesFragment?
                if (fragment == null)
                    fragment = QssMessagesFragment()
                fragment.setReceiver(usr)
                fragment.group = null
                fragment.show(childFragmentManager,tag)
            }.setNegativeButton(
                "Cancel"
            ) { dialogInterface, i ->
                //
            }
        val dialog: Dialog = builder.create()
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }
}