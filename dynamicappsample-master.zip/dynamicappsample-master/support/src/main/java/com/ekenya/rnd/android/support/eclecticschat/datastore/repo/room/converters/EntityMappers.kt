package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.converters

import com.ekenya.rnd.android.common.Constants
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups.GroupsEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages.MessagesEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.MessageItem
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUsersEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups.GroupWithMembers
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUserWithMessages
import java.text.SimpleDateFormat
import kotlin.collections.ArrayList

class EntityMappers {
    companion object {

        private val dateFormatter = SimpleDateFormat(Constants.ISO_DATE_FORMAT)

        //MESSAGES
        fun createFrom(entity: MessagesEntity?): MessageItem? {

            entity?.let {
                var msg =
                    MessageItem()
                msg.id = entity.msgId
                msg.groupId = entity.groupId ?: 0
                msg.groupGUID = entity.groupGUID
                msg.receiverId = entity.receiverId
                msg.receiverName = entity.receiverName
                msg.senderName = entity.senderName
                msg.senderGUID = entity.senderGUID
                when (entity.kind) {
                    MessageItem.MessageKind.Contact.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Contact
                        //msg.content = Gson().fromJson(entity.content, ChatUser::class.java)
                    }
                    MessageItem.MessageKind.Emoji.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Emoji
                    }
                    MessageItem.MessageKind.Image.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Image
                        //msg.setImage(Gson().fromJson(entity.content, MessageItem.Image::class.java))
                    }
                    MessageItem.MessageKind.Html.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Html
                    }
                    MessageItem.MessageKind.IsTyping.ordinal -> {
                        msg.kind = MessageItem.MessageKind.IsTyping
                    }
                    MessageItem.MessageKind.Link.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Link
                    }
                    MessageItem.MessageKind.Location.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Location
                    }
                    MessageItem.MessageKind.Voice.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Voice
                        //msg.voice = Gson().fromJson(entity.content, MessageItem.Voice::class.java)
                    }
                    MessageItem.MessageKind.Text.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Text
                    }
                    MessageItem.MessageKind.Video.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Video
                        //msg.video = Gson().fromJson(entity.content, MessageItem.Video::class.java)
                    }
                    MessageItem.MessageKind.Custom.ordinal -> {
                        msg.kind = MessageItem.MessageKind.Custom
                    }
                }
                msg.content = entity.content
                when (entity.status) {
                    MessageItem.MessageStatus.Delivered.ordinal -> {
                        msg.status = MessageItem.MessageStatus.Delivered
                    }
                    MessageItem.MessageStatus.Seen.ordinal -> {
                        msg.status = MessageItem.MessageStatus.Seen
                    }
                    else -> {
                        msg.status = MessageItem.MessageStatus.Sent
                    }
                }
                msg.taggedMessageId = entity.taggedMsgId
                msg.createdAt = entity.date
                msg.user =
                    ChatUser(
                        entity.senderGUID,
                        entity.senderName,
                        "",
                        false
                    )
                //
                return msg
            }?:run {
                return null
            }
        }


        fun createFrom(entity: ChatUserWithMessages): ChatUser? {

            if(entity != null) {
                var contact =
                    ChatUser(
                        entity.user.userId,
                        entity.user.name,
                        entity.user.photo,
                        false
                    )
                //
                contact.messages.addAll(createMessagesFrom(entity.messages))
                //
                return contact
            }
            return entity
        }

        fun createMessagesFrom(entities: List<MessagesEntity>): List<MessageItem> {
            var list = ArrayList<MessageItem>()
            for( entity in entities) {
                createFrom(entity)?.let {
                    //it.user = ChatUser(it.u,it.senderName,"",false)
                    list.add(it)
                }
            }
            //
            return list

        }

        fun convertTo(msg: MessageItem): MessagesEntity {

            var entity = MessagesEntity()
            //Keys
            entity.groupId = msg.groupId
            entity.msgId = msg.id
            //entity.senderId = msg.user.id
            entity.receiverId = msg.receiverId
            entity.receiverName = msg.receiverName
            //Values
            entity.groupGUID = msg.groupGUID//External ID
            entity.senderGUID = msg.user.id//External ID
            entity.senderName = msg.user.name
            //
            entity.date = msg.createdAt
            entity.content = msg.content
            msg.kind?.let { entity.kind = msg.kind.ordinal } ?: kotlin.run { entity.kind = MessageItem.MessageKind.Text.ordinal }
            msg.status?.let { entity.status = msg.status.ordinal } ?: kotlin.run { entity.status = MessageItem.MessageStatus.Sent.ordinal }
            entity.taggedMsgId = msg.taggedMessageId
            return entity

        }

        //CONTACTS

        fun createContactsFrom(entities: List<ChatUsersEntity>): List<ChatUser> {
            var list = ArrayList<ChatUser>()
            for( entity in entities) {
                createFrom(entity)?.let { list.add(it) }
            }
            //
            return list

        }

        fun createFrom(entity: ChatUsersEntity?): ChatUser? {

            entity?.let {
                val contact =
                    ChatUser(
                        entity.userId,
                        entity.name,
                        entity.photo,
                        false
                    )
//            //
//            val phonesTypeToken = object : TypeToken<HashSet<String>>() {}.type
//            contact.AllPhones = Gson().fromJson<HashSet<String>>(entity.otherPhones,phonesTypeToken)
//            //
//            val emailsTypeToken = object : TypeToken<HashSet<String>>() {}.type
//            contact.Emails = Gson().fromJson<HashSet<String>>(entity.otherPhones,emailsTypeToken)
//            //
//            contact.DateCreated = entity.date
//            contact.PrimaryPhone = entity.phone
//
//            entity.photo.let {encodedImage:String? ->
//                val decodedString: ByteArray = Base64.decode(encodedImage, Base64.DEFAULT)
//                contact.Photo = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
//            }

                return contact
            }?:run{
                return null
            }

        }

        fun convertTo(contact: ChatUser): ChatUsersEntity{

            val entity = ChatUsersEntity()
            entity.userId = contact.id
            entity.name = contact.name ?: "Not Available"
            //
            //entity.otherPhones = Gson().toJson(contact.otherPhones)
            //
            //entity.emails = Gson().toJson(contact.email)
            //
            //entity.phone = contact.phone
            entity.photo = contact.photo
//            contact.photo.let {bitmap: Bitmap? ->
//                val byteArrayOutputStream = ByteArrayOutputStream()
//                bitmap?.compress(
//                    Bitmap.CompressFormat.PNG,
//                    100,
//                    byteArrayOutputStream
//                )
//                //
//                entity.photo = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);
//            }
            //entity.date = Calendar.getInstance().time
            return entity
        }

        //GROUPS

        fun createGroupsFrom(entities: List<GroupsEntity>): List<ChatGroup> {
            var list = ArrayList<ChatGroup>()
            for( entity in entities) {
                createFrom(entity)?.let { list.add(it) }
            }
            //
            return list

        }

        fun createGroupsAndMembersFrom(entities: List<GroupWithMembers>): List<ChatGroup> {
            var list = ArrayList<ChatGroup>()
            for( entity in entities) {
                createFrom(entity)?.let {
                    it.members = createContactsFrom(entity.members)
                    it.lastMessage = createFrom(entity.lastMessage)
                    list.add(it)
                }
            }
            //
            return list

        }

        fun createFrom(entity: GroupsEntity?): ChatGroup? {

            entity?.let {
                var group =
                    ChatGroup(
                        "",
                        "",
                        "",
                        ArrayList<ChatUser>(),
                        null,
                        0
                    )

                group.id = entity.itemId


                //
                return group
            }?:run {
                return null
            }
        }

        fun createFrom(entity: GroupWithMembers?): ChatGroup? {

            entity?.let {
                var group =
                    ChatGroup(
                        "",
                        "",
                        "",
                        ArrayList<ChatUser>(),
                        null,
                        0
                    )

                group.id = entity.group.itemId

                group.users.addAll(createContactsFrom(entity.members))

                //
                return group
            }?: run {
                return null
            }
        }

        fun convertTo(group: ChatGroup): GroupsEntity {

            var entity = GroupsEntity()
            entity.itemId = group.id




            return entity

        }

    }
}