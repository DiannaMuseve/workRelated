package com.ekenya.rnd.android.support.di

import com.ekenya.rnd.android.mobile.di.AppComponent
import com.ekenya.rnd.android.mobile.di.ModuleScope
import com.ekenya.rnd.android.mobile.di.injectables.ViewModelModule
import com.ekenya.rnd.android.support.di.injectables.SupportActivityModule
import com.ekenya.rnd.android.support.di.injectables.SupportFragmentModule
import com.ekenya.rnd.android.support.di.injectables.SupportServicesModule
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo
import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule

@ModuleScope
@Component(
    dependencies = [
        AppComponent::class
    ],
    modules = [
        SupportModule::class,
        SupportServicesModule::class,
        AndroidSupportInjectionModule::class,
        SupportActivityModule::class,
        SupportFragmentModule::class,
        ViewModelModule::class
    ]
)
interface SupportComponent {

    fun getSupportRepo(): IChatRepo

    fun inject(injector: SupportInjector)

    //fun inject(service: EclecticsSupportService)
}