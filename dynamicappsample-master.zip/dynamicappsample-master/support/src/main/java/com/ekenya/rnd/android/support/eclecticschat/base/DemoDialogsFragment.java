package com.ekenya.rnd.android.support.eclecticschat.base;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.Nullable;

import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment;
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup;
import com.stfalcon.chatkit.commons.ImageLoader;
import com.stfalcon.chatkit.dialogs.DialogsListAdapter;

/*
 * Created by troy379 on 05.04.17.
 */
public abstract class DemoDialogsFragment extends BaseDaggerFragment
        implements DialogsListAdapter.OnDialogClickListener<ChatGroup>,
        DialogsListAdapter.OnDialogLongClickListener<ChatGroup> {
    private static final String TAG = DemoDialogsFragment.class.getSimpleName();

    //used to check if fab menu are opened or closed
    protected boolean fabsClosed = false;

    // creating variable that handles Animations loading
    // and initializing it with animation files that we have created
    protected Animation rotateOpen;
    protected  Animation rotateClose;
    protected  Animation fromBottom;
    protected  Animation toBottom;

    protected ImageLoader imageLoader;
    protected DialogsListAdapter<ChatGroup> dialogsAdapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        //setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.BottomSheetTheme);

        //
        rotateOpen = AnimationUtils.loadAnimation(requireContext(),com.ekenya.rnd.android.common.R.anim.rotate_open_anim);
        rotateClose = AnimationUtils.loadAnimation(requireContext(),com.ekenya.rnd.android.common.R.anim.rotate_close_anim);
        fromBottom = AnimationUtils.loadAnimation(requireContext(),com.ekenya.rnd.android.common.R.anim.from_bottom_anim);
        toBottom = AnimationUtils.loadAnimation(requireContext(),com.ekenya.rnd.android.common.R.anim.to_bottom_anim);

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //
        //getView().setBackgroundColor(getResources().getColor(android.R.color.transparent));

    }

}
