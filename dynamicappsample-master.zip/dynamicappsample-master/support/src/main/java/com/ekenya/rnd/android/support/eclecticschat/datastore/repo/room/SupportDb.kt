package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room

import android.content.Context
import android.content.res.Resources
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ekenya.rnd.android.common.db.converters.Converters
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUsersDao
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts.ChatUsersEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups.GroupToMemberBridgeEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups.GroupsDao
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups.GroupsEntity
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages.MessagesDao
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages.MessagesEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(version = 1,
    entities = [MessagesEntity::class,
        GroupsEntity::class,
        ChatUsersEntity::class,
        GroupToMemberBridgeEntity::class],
    exportSchema = true)
@TypeConverters(Converters::class)
abstract class SupportDb : RoomDatabase() {

    abstract fun messagesDao(): MessagesDao

    abstract fun groupsDao(): GroupsDao

    abstract fun contactsDao(): ChatUsersDao

    private class PlayerDatabaseCallback(
        private val scope: CoroutineScope,
        private val resources: Resources
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch {
                    val messagesDao = database.messagesDao()
                    prePopulateDatabase(messagesDao)
                }
            }
        }

        private suspend fun prePopulateDatabase(messagesTable: MessagesDao) {
//            val jsonString = resources.openRawResource(R.raw.loans).bufferedReader().use {
//                it.readText()
//            }
//            val typeToken = object : TypeToken<List<LoanItem>>() {}.type
//            val demoLoans = ArrayList<LoanEntity>()
//
//            for (h in Gson().fromJson<List<LoanItem>>(jsonString, typeToken)) {
//                var loan = LoanEntity()
//                loan.id = 0
//                loan.amount = h.Amount
//                loan.contactId = h.ContactId
//                loan.interest = h.Interest
//                loan.period = h.Period
//                loan.date = h.Date
//                loan.currency = h.Currency
//                //
//                demoLoans.add(loan)
//            }
//
//            loanTable.insertAllLoans(demoLoans)
        }
    }

    companion object {

        const val DB_NAME = "md_support_db"

        @Volatile
        var INSTANCE: SupportDb? = null

        fun getDatabase(
            context: Context,
            coroutineScope: CoroutineScope,
            resources: Resources
        ): SupportDb {
            val tempInstance =
                INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }

            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SupportDb::class.java,
                    DB_NAME
                )
                    //.addMigrations( MIGRATION_1_2, MIGRATION_2_3 )
                    .fallbackToDestructiveMigration()
                    .addCallback(
                        PlayerDatabaseCallback(
                            coroutineScope,
                            resources
                        )
                    )
                    .build()
                INSTANCE = instance
                return instance
            }
        }

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE `Messages` (`id` INTEGER, `name` TEXT, " +
                            "PRIMARY KEY(`id`))"
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE Book ADD COLUMN pub_year INTEGER")
            }
        }
    }
}