package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.contacts

import androidx.lifecycle.LiveData
import androidx.room.*


/**
 * Created by Bourne Koloh on 02 July,2020.
 * Eclectics International, Products and R&D
 * PROJECT: Lending Manager
 */
@Dao
interface ChatUsersDao {

    @Delete
    suspend fun deleteContact(contact: ChatUsersEntity)

    @Update
    suspend fun updateContact(contact: ChatUsersEntity)

    @Query("SELECT * FROM "+ ChatUsersTableFields.TABLE_NAME +" WHERE "+ ChatUsersTableFields.COLUMN_ID +" = :id")
    fun getChatUser(id: Int): ChatUsersEntity

    @Query("SELECT * FROM "+ ChatUsersTableFields.TABLE_NAME +" WHERE "+ ChatUsersTableFields.COLUMN_ID +" = :id")
    fun getChatUserAndMessages(id: Int): ChatUserWithMessages

    @Query("SELECT * FROM "+ ChatUsersTableFields.TABLE_NAME +" WHERE "+ ChatUsersTableFields.COLUMN_USER_ID +" = :contactId")
    suspend fun getChatUser(contactId: String): ChatUsersEntity

    @Query("SELECT * FROM "+ ChatUsersTableFields.TABLE_NAME +" WHERE "+ ChatUsersTableFields.COLUMN_PHONE +" = :phone ORDER BY "+ChatUsersTableFields.COLUMN_DATE+" DESC")
    fun findContactByPhone(phone: String): LiveData<List<ChatUsersEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAllChatUsers(contacts: List<ChatUsersEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertChatUser(contact: ChatUsersEntity)

    @Query("SELECT * FROM "+ ChatUsersTableFields.TABLE_NAME+" ORDER BY "+ChatUsersTableFields.COLUMN_DATE+" DESC")
    fun getAllChatUsers(): LiveData<List<ChatUsersEntity>>

    @Transaction
    @Query("SELECT * FROM "+ ChatUsersTableFields.TABLE_NAME+" ORDER BY "+ ChatUsersTableFields.COLUMN_DATE+" DESC")
    fun getAllChatUserAndMessages(): List<ChatUserWithMessages>
}