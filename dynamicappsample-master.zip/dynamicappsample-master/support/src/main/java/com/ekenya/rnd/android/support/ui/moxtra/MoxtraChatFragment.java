package com.ekenya.rnd.android.support.ui.moxtra;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment;
import com.ekenya.rnd.android.support.R;
import com.ekenya.rnd.android.support.databinding.FragmentMoxtraChatBinding;

import javax.inject.Inject;



public class MoxtraChatFragment extends BaseDaggerFragment {
    private final String TAG = MoxtraChatFragment.class.getSimpleName();
    @Inject
    public ViewModelProvider.Factory viewModelFactory;

    private MoxtraChatViewModel dashboardViewModel;
    private FragmentMoxtraChatBinding binding;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel = new ViewModelProvider(this,viewModelFactory).get(MoxtraChatViewModel.class);

        binding = FragmentMoxtraChatBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = root.findViewById(R.id.text_dashboard);
        dashboardViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
    @Override
    public void setUserVisibleHint(boolean visible)
    {
        super.setUserVisibleHint(visible);
        if (visible && isResumed())
        {
            //Only manually call onResume if fragment is already visible
            //Otherwise allow natural fragment lifecycle to call onResume
            onResume();
        }
    }

    @Override
    public void onResume()
    {
        super.onResume();
        if (!getUserVisibleHint())
        {
            return;
        }

        //INSERT CUSTOM CODE HERE
        ((AppCompatActivity)requireActivity()).getSupportActionBar().setTitle("Moxtra Support Chat");
    }
}