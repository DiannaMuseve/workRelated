package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface MessagesDao {

    @Delete
    suspend fun delete(msg: MessagesEntity)

    @Update
    suspend fun update(msg: MessagesEntity)

    @Query("SELECT * FROM "+ MessagesTableFields.TABLE_NAME+" WHERE "+ MessagesTableFields.COLUMN_ID+" = :id")
    fun getById(id: Int): MessagesEntity

//    @Transaction
//    @Query("SELECT * FROM "+ MessagesTableFields.TABLE_NAME+" WHERE "+ MessagesTableFields.COLUMN_ID+" = :id")
//    fun getContactMessagesById(id: Int): ContactsEntityWithMessagesEntity

    @Transaction
    @Query("SELECT * FROM "+ MessagesTableFields.TABLE_NAME+" WHERE "+ MessagesTableFields.COLUMN_ITEM_ID+" = :msgId")
    fun getById(msgId: String): MessagesEntity


//    @Transaction
//    @Query("SELECT * FROM "+ MessagesTableFields.TABLE_NAME+" WHERE "+ MessagesTableFields.COLUMN_ITEM_ID+" = :msgId")
//    fun getContactMessagesById(msgId: String): ContactsEntityWithMessagesEntity


    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(msgs: List<MessagesEntity>)

    //@Transaction
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(msg: MessagesEntity)

    @Query("SELECT * FROM "+ MessagesTableFields.TABLE_NAME+"  ORDER BY "+ MessagesTableFields.COLUMN_DATE+" DESC")
    fun getAll(): LiveData<List<MessagesEntity>>

    @Transaction
    @Query("SELECT * FROM "+ MessagesTableFields.TABLE_NAME+" WHERE "+ MessagesTableFields.COLUMN_GROUP_ID+" = :groupId ORDER BY "+ MessagesTableFields.COLUMN_DATE+" DESC")
    fun getAllGroupMessages(groupId: String): LiveData<List<MessagesEntity>>
}