package com.ekenya.rnd.android.support.eclecticschat.base;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;

import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment;
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService;
import com.ekenya.rnd.android.qss.beans.QssUser;
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup;
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.MessageItem;
import com.ekenya.rnd.android.support.R;
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatViewModel;
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser;
import com.google.android.material.snackbar.Snackbar;
import com.stfalcon.chatkit.commons.ImageLoader;
import com.stfalcon.chatkit.commons.models.IMessage;
import com.stfalcon.chatkit.messages.MessageInput;
import com.stfalcon.chatkit.messages.MessagesListAdapter;

import org.jetbrains.annotations.NotNull;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import io.reactivex.CompletableObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

/*
 * Created by troy379 on 04.04.17.
 */
public abstract class DemoMessagesFragment extends BaseDaggerFragment
        implements MessagesListAdapter.SelectionListener,
        MessagesListAdapter.OnLoadMoreListener,
        MessageInput.TypingListener {
    protected static final String TAG = DemoMessagesFragment.class.getSimpleName();

    private static final int TOTAL_MESSAGES_COUNT = 100;

    protected MessagesListAdapter<IMessage> messagesAdapter;

    private Menu menu;
    private int selectionCount;
    protected Date lastLoadedDate;

    protected ChatGroup mGroup;

    public ChatGroup getGroup() {
        return mGroup;
    }

    public void setGroup(ChatGroup group) {
        this.mGroup = group;
    }

    protected EclecticsChatViewModel mViewModel;

    protected ImageLoader imageLoader;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater,
                             @Nullable @org.jetbrains.annotations.Nullable ViewGroup container,
                             @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        //

        return super.onCreateView(inflater, container, savedInstanceState);

    }

    @Override
    public void onStart() {
        super.onStart();
        //
        //Filter messages for this group
        if(mGroup == null){
            return;
        }

        mViewModel.getMessages(mGroup.getId(), lastLoadedDate).observe(getViewLifecycleOwner(), new Observer<List<IMessage>>() {
            @Override
            public void onChanged(List<IMessage> messageItems) {

                //
                if(!messageItems.isEmpty()){
                    //Sort by date
                    Collections.sort(messageItems, new Comparator<IMessage>() {
                        @Override
                        public int compare(IMessage lhs, IMessage rhs) {
                            // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                            //
                            return lhs.getCreatedAt().getTime() > rhs.getCreatedAt().getTime() ? -1 :
                                    (lhs.getCreatedAt().getTime() < rhs.getCreatedAt().getTime()) ? 1 : 0;
                        }
                    });
                    IMessage last = messageItems.get(messageItems.size()-1);
                    if(messagesAdapter.getItemCount() == 0) {
                        lastLoadedDate = last.getCreatedAt();
                    }
                    //
                    if(last.getUser().getId() == mViewModel.getCurrentSender().getValue().getId()) {
                        messagesAdapter.update(last);
                    }else{
                        messagesAdapter.addToStart(last, true);
                    }
                    messagesAdapter.notifyDataSetChanged();
                }else{
                    //No messages
                }
            }
        });
        //
        mViewModel.getIsTyingObserver()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new io.reactivex.Observer<MessageItem>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(MessageItem messageItem) {
                Log.i(TAG,"Received is typing from "+messageItem.getUser().getName());
                //messagesAdapter.addToStart(messageItem);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
        //
        mViewModel.getService().observe(this, new Observer<EclecticsQssService>() {
            @Override
            public void onChanged(EclecticsQssService messengerService) {

                messengerService.getUserOnlineObserver()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Consumer<QssUser>() {
                            @Override
                            public void accept(QssUser chatUser) throws Exception {
                                if(mGroup.getType() == ChatGroup.GroupType.GROUPED){
                                    //
                                    if(mGroup != null && !mGroup.getUsers().isEmpty()) {
                                        for (ChatUser usr: mGroup.getUsers()) {
                                            //
                                            if(usr.getId() == chatUser.getId()){
                                                Snackbar.make(getView(), chatUser.getName() + " is online", Snackbar.LENGTH_SHORT).show();
                                                break;
                                            }
                                        }
                                    }
                                }else {
                                    if(mGroup.getId() == chatUser.getId()){
                                        //
                                        ((AppCompatActivity)getActivity()).getSupportActionBar().setSubtitle("Online");
                                        Snackbar.make(getView(), chatUser.getName() + " is online", Snackbar.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        });

                messengerService.getUserOfflineObserver()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new Consumer<QssUser>() {
                            @Override
                            public void accept(QssUser chatUser) throws Exception {
                                if(mGroup.getType() == ChatGroup.GroupType.GROUPED){
                                    //
                                    if(mGroup != null && !mGroup.getUsers().isEmpty()) {
                                        for (ChatUser usr: mGroup.getUsers()) {
                                            if(usr.getId() == chatUser.getId()){
                                                Snackbar.make(getView(), chatUser.getName() + " is offline", Snackbar.LENGTH_SHORT).show();
                                                break;
                                            }
                                        }
                                    }
                                }else {
                                    if(mGroup.getId() == chatUser.getId()){
                                        //
                                        ((AppCompatActivity)getActivity()).getSupportActionBar().setSubtitle("Offline");
                                        Snackbar.make(getView(), chatUser.getName() + " is online", Snackbar.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        });
            }
        });
        //
        mViewModel.getNewMessageObserver()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe(new Consumer<MessageItem>() {
                    @Override
                    public void accept(MessageItem messageItem) throws Exception {
                        Log.i(TAG,"Received is new message from "+messageItem.getUser().getName());
                        //messagesAdapter.addToStart(messageItem);

                        //
                        if(mGroup.getType() == ChatGroup.GroupType.GROUPED && messageItem.getGroupGUID() != null
                                && messageItem.getGroupGUID().equalsIgnoreCase(mGroup.getId())){
                            //For group messages
                            messagesAdapter.addToStart(messageItem, true);
                        }else if(
                            //Outgoing
                                messageItem.getReceiverId() != null && messageItem.getReceiverId() .equalsIgnoreCase(mGroup.getId()) ||
                                        //Incoming
                                        messageItem.getUser().getId().equalsIgnoreCase(mGroup.getId()) &&
                                                messageItem.getReceiverId().equalsIgnoreCase(mViewModel.getCurrentSender().getValue().getId())
                        ){
                            //For direct messages
                            messagesAdapter.addToStart(messageItem, true);
                        }else{
                            //Log.w("","Message not for this conversation ..")
                        }
                    }
                });
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        this.menu = menu;
//        getMenuInflater().inflate(R.menu.chat_actions_menu, menu);
//        onSelectionChanged(0);
//        return true;
//    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        this.menu = menu;
        inflater.inflate(R.menu.chat_actions_menu, menu);
        onSelectionChanged(0);
        //return true;
        super.onCreateOptionsMenu(menu,inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_delete:
                messagesAdapter.deleteSelectedMessages();
                break;
            case R.id.action_copy:
                messagesAdapter.copySelectedMessagesText(getContext(), getMessageStringFormatter(), true);
                //mAppUtils.showToast(getContext(), R.string.copied_message, true);
                break;
        }
        return true;
    }
    @Override
    public void onResume() {
        super.onResume();

        if(getView() == null){
            return;
        }

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {

                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK){
                    // handle back button's click listener
                    onBackPressed();
                    return true;
                }
                return false;
            }
        });
    }
//    @Override
    public void onBackPressed() {
        if (selectionCount == 0) {
            //super.onBackPressed();
        } else {
            messagesAdapter.unselectAllItems();
        }
    }

    @Override
    public void onLoadMore(int page, int totalItemsCount) {
        Log.i("TAG", "onLoadMore: " + page + " " + totalItemsCount);
        if (totalItemsCount < TOTAL_MESSAGES_COUNT) {
            loadMessages();
        }
    }

    @Override
    public void onSelectionChanged(int count) {
        this.selectionCount = count;
        menu.findItem(R.id.action_delete).setVisible(count > 0);
        menu.findItem(R.id.action_copy).setVisible(count > 0);
    }

    protected void loadMessages() {

        new Handler().postDelayed(new Runnable() { //imitation of internet connection
            @Override
            public void run() {
                mViewModel.getMessages(mGroup.getId(), lastLoadedDate).observe(getViewLifecycleOwner(), new Observer<List<IMessage>>() {
                    @Override
                    public void onChanged(List<IMessage> groupQueue) {

                        //
                        if(!groupQueue.isEmpty()){
                            //Sort by date
                            Collections.sort(groupQueue, new Comparator<IMessage>() {
                                @Override
                                public int compare(IMessage lhs, IMessage rhs) {
                                    // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                                    //
                                    return lhs.getCreatedAt().getTime() > rhs.getCreatedAt().getTime() ? -1 :
                                            (lhs.getCreatedAt().getTime() < rhs.getCreatedAt().getTime()) ? 1 : 0;
                                }
                            });
                            //
                            lastLoadedDate = groupQueue.get(groupQueue.size() - 1).getCreatedAt();
                            //
                            messagesAdapter.addToEnd(groupQueue, false);
                            //
                            messagesAdapter.notifyDataSetChanged();
                        }else{
                            //No messages
                        }
                    }
                });
            }
        }, 1000);
    }

    protected  void sendMessage(MessageItem msg){
        //
        CompletableObserver observer = new CompletableObserver() {
            @Override
            public void onSubscribe(@NotNull Disposable d) {
                //mMessageInput.getInputEditText().setEnabled(false);

            }

            @Override
            public void onComplete() {
                msg.setStatus(MessageItem.MessageStatus.Sent);
                messagesAdapter.update(msg);
                //mMessageInput.getInputEditText().setEnabled(true);
                mGroup.setLastMessage(msg);
            }

            @Override
            public void onError(@NotNull Throwable e) {
                //mAppUtils.showToast(getContext(),"Send Message Failed: "+e.getMessage(),true);
                //
                msg.setStatus(MessageItem.MessageStatus.Failed);
                messagesAdapter.update(msg);
                //mMessageInput.getInputEditText().setEnabled(true);
            }
        };
        //
        if(mGroup.getType() == ChatGroup.GroupType.GROUPED){
            //
            msg.setGroupGUID(mGroup.getId());
            mViewModel.sendGroupMessage(msg,mGroup.getId()).subscribe(observer);

        }else {
            msg.setReceiverId(mGroup.getId());
            mViewModel.sendDirectMessage(msg,mGroup.getId()).subscribe(observer);
        }
    }

    @Override
    public void onStartTyping() {
        Log.v("Typing listener", getString(R.string.start_typing_status));
        mViewModel.getCurrentSender().observe(this, new Observer<ChatUser>() {
            @Override
            public void onChanged(ChatUser chatUser) {

                MessageItem msg = new MessageItem(UUID.randomUUID().toString(),
                        chatUser,"1",
                        Calendar.getInstance().getTime());
                msg.setKind(MessageItem.MessageKind.IsTyping);
                //
                sendMessage(msg);
                //
                mViewModel.getCurrentSender().removeObserver(this);
            }
        });
    }

    @Override
    public void onStopTyping() {
        Log.v("Typing listener", getString(R.string.stop_typing_status));

//        MessageItem msg = new MessageItem(UUID.randomUUID().toString(),
//                mViewModel.getCurrentSender().getValue(),"0",
//                Calendar.getInstance().getTime());
//        msg.setKind(MessageItem.MessageKind.IsTyping);
//        //
//        sendMessage(msg);
    }

    private MessagesListAdapter.Formatter<IMessage> getMessageStringFormatter() {
        return new MessagesListAdapter.Formatter<IMessage>() {
            @Override
            public String format(IMessage message) {
                String createdAt = new SimpleDateFormat("MMM d, EEE 'at' h:mm a", Locale.getDefault())
                        .format(message.getCreatedAt());

                String text = message.getContent();
                if (text == null) text = "[attachment]";

                return String.format(Locale.getDefault(), "%s: %s (%s)",
                        message.getUser().getName(), text, createdAt);
            }
        };
    }

}
