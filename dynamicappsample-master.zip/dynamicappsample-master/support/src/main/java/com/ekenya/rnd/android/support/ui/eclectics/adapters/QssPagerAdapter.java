package com.ekenya.rnd.android.support.ui.eclectics.adapters;

import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.ekenya.rnd.android.support.ui.eclectics.directchat.QssChatGroupsFragment;
import com.ekenya.rnd.android.support.ui.eclectics.supportchat.QssSupportFragment;
import com.ekenya.rnd.android.support.R;
import com.ekenya.rnd.android.support.ui.eclectics.directchat.QssChatGroupsFragment;
import com.ekenya.rnd.android.support.ui.eclectics.supportchat.QssSupportFragment;

public class QssPagerAdapter extends FragmentStatePagerAdapter {
    private static final String TAG = QssPagerAdapter.class.getSimpleName();
    //
    FragmentManager mManager;

    public QssPagerAdapter(FragmentManager fm) {
        super(fm);
        mManager = fm;
    }

    @Override
    public Fragment getItem(int i) {

        Log.i(TAG,"Get count = "+i);

        switch (i) {
            case 0:
                return new QssSupportFragment();
            case 1:
                return new QssChatGroupsFragment();
        }
        return null;
    }

    @Override
    public int getCount() {
        return 2;
    }

    public QssSupportFragment getDashboardFragment() {
        //
        return (QssSupportFragment) mManager.findFragmentByTag("android:switcher:" + R.id.qss_pager + ":0");
    }


    public QssChatGroupsFragment getCollectionsFragment() {
        //
        return (QssChatGroupsFragment) mManager.findFragmentByTag("android:switcher:" + R.id.qss_pager + ":1");

    }

//    public QssSupportFragment getPreviewFragment() {
//        if (device == HANDSET) {
//            return (CollectionsFragment) getSupportFragmentManager().findFragmentByTag("android:switcher:"+R.id.handset_pager+":1");
//        } else {
//            return (PreviewFragment) getSupportFragmentManager().findFragmentById(R.id.preview);
//        }
//    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "Support Chat";
            case 1:
                return "Direct/Group Chat";
        }
        return null;
    }

}