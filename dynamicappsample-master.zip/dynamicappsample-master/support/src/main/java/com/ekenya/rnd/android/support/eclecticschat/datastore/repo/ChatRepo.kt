package com.ekenya.rnd.android.support.eclecticschat.datastore.repo

import android.content.Context
import android.util.Log
import androidx.lifecycle.*
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.converters.EntityMappers
import com.ekenya.rnd.android.common.models.UserAccount
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.apputils.IAppUtils
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.qss.QSSClientService
import com.ekenya.rnd.android.qss.beans.QssEvents
import com.ekenya.rnd.android.qss.beans.SsData
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.MessageItem
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.SupportDb
import com.google.gson.Gson
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject
import kotlin.collections.ArrayList

class ChatRepo @Inject constructor(
    private var context: Context,
    private var supportDb:SupportDb,
    private var mAppUtils:IAppUtils,
    private var mAppDb:IAppRepo,
    private  var coroutineScope: CoroutineScope
): IChatRepo {
    val TAG = ChatRepo::class.java.simpleName

    private var service = MutableLiveData<EclecticsQssService>()
    //Messages
    private val  messagesLiveCache = MediatorLiveData<List<MessageItem>>()
    val messagesCache: LiveData<List<MessageItem>> get() = messagesLiveCache
    //Contacts/Users
    private val  contactsLiveCache = MediatorLiveData<List<ChatUser>>()
    val contactsCache: LiveData<List<ChatUser>> get() = contactsLiveCache
    //Groups
    private val  groupsLiveCache = MediatorLiveData<List<ChatGroup>>()
    val groupsCache: LiveData<List<ChatGroup>> get() = groupsLiveCache

    private lateinit var mAppUser:UserAccount

    init {
        //Messages Remote Repo
        service.observeForever{
            it.subscribeForData()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe{data ->
                    //
                    when(data.action){
                        //
                        QssEvents.OnlineUsers, QssEvents.UserOffline,QssEvents.UserOnline ->{
                            parseQssUsersContent(data)
                        }
                        //
                        QssEvents.GroupRemoved,QssEvents.LeaveGroup,QssEvents.UserGroups -> {
                            parseQssGroupsContent(data)
                        }
                        //
                        QssEvents.Payload -> {
                            parseQssContent(data)
                        }
                        else -> {
                            //
                            Log.i(TAG, "Unprocessed Payload => " + data.action)
                        }
                    }
                }
        }
        //Messages Local Repo
        messagesLiveCache.addSource(supportDb.messagesDao().getAll()) {
            messagesLiveCache.postValue(EntityMappers.createMessagesFrom(it))
        }
        //Contacts Local Repo
        contactsLiveCache.addSource(supportDb.contactsDao().getAllChatUsers()) {
            contactsLiveCache.postValue(EntityMappers.createContactsFrom(it))
        }
        //Grouped Local Repo
        groupsLiveCache.addSource(supportDb.groupsDao().getGroupsAndMembers()) {

            val groups = EntityMappers.createGroupsAndMembersFrom(it)
            //groups.forEach { it. }
            groupsLiveCache.postValue(groups)
        }
        //
        groupsLiveCache.addSource(getGroupedDirectChats()) {
            groupsLiveCache.postValue(it)
        }
        //
        mAppDb.getUsers().observeForever {
            if(it.isNotEmpty()){
                mAppUser = it[0]
            }
        }
    }
    override fun getService(): MutableLiveData<EclecticsQssService> {
        return service
    }

    //Messages
    override fun getAllMessages() = messagesLiveCache

    override fun getMessage(id: Int): MessageItem? {
        //
        return EntityMappers.createFrom(supportDb.messagesDao().getById(id))
    }

    override fun getMessage(id: String): MessageItem? {

        //
        return EntityMappers.createFrom(supportDb.messagesDao().getById(id))
    }

    override suspend fun addOrUpdateMessage(msg: MessageItem) {
        val entity = EntityMappers.convertTo(msg)
        //Get User/Contact
        var user = supportDb.contactsDao().getChatUser(msg.user.id)
        if(user == null){
            addOrUpdateContact(msg.user)
            user = supportDb.contactsDao().getChatUser(msg.user.id)
        }
        if (user != null) {
            entity.senderId = user.id
            //
            if(supportDb.messagesDao().getById(entity.msgId) != null) {
                supportDb.messagesDao().update(entity)
            }else{
                supportDb.messagesDao().insert(entity)
            }
        }else{
            //
            Log.e(TAG,"Required foreign key record not found in DB,")
        }
    }

    suspend fun deleteMessage(msg: MessageItem) {
        //
        supportDb.messagesDao().delete(EntityMappers.convertTo(msg))
    }

    //Users/Contacts

    override fun getAllContacts(): LiveData<List<ChatUser>> = contactsCache

    override fun getContact(id: Int): ChatUser? {

        return EntityMappers.createFrom(supportDb.contactsDao().getChatUser(id))
    }

    override suspend fun getContact(userId: String): ChatUser? {
//        return supportDb.contactsDao().getChatUser(userId).switchMap {
//            val ld = MutableLiveData<ChatUser>()
//            ld.value = EntityMappers.createFrom(it)
//            ld
//        }
        return EntityMappers.createFrom(supportDb.contactsDao().getChatUser(userId))
    }

    override suspend fun addOrUpdateContact(contact: ChatUser) {
        var entity = EntityMappers.convertTo(contact)
        if(supportDb.contactsDao().getChatUser(contact.id) != null) {
            supportDb.contactsDao().updateContact(entity)
        }else{
            supportDb.contactsDao().insertChatUser(entity)
        }
    }

    override suspend fun deleteContact(contact: ChatUser) {
        var entity = EntityMappers.convertTo(contact)
        supportDb.contactsDao().deleteContact(entity)
    }

    //Groups

    override fun getAllGroups(): LiveData<List<ChatGroup>> = groupsCache

    override fun getGroup(id: Int): ChatGroup? {
        //
        return EntityMappers.createFrom(supportDb.groupsDao().getById(id))
    }

    fun getGroupAndMembers(id: Int): ChatGroup? {
        //
        return EntityMappers.createFrom(supportDb.groupsDao().getById(id))
    }

    override fun getGroup(groupId: String): ChatGroup? {
        //
        return EntityMappers.createFrom(supportDb.groupsDao().getById(groupId))
    }

    override fun getMessagesByGroup(groupId: String): LiveData<List<MessageItem>> {

        return supportDb.messagesDao().getAllGroupMessages(groupId).switchMap {
            val ld = MutableLiveData<List<MessageItem>>()
            ld.postValue(EntityMappers.createMessagesFrom(it))
            ld
        }
    }


    override suspend fun addOrUpdateGroup(group: ChatGroup) {
        var entity = EntityMappers.convertTo(group)
        if(supportDb.groupsDao().getById(entity.itemId) != null){
            supportDb.groupsDao().update(entity)
        }else {
            supportDb.groupsDao().insert(entity)
        }
    }

    override suspend fun deleteGroup(group: ChatGroup) {
        var entity = EntityMappers.convertTo(group)
        //
        supportDb.groupsDao().delete(entity)
    }

    private fun parseQssGroupsContent(data: SsData){

    }

    private fun parseQssUsersContent(data: SsData){

    }
    //
     private fun parseQssContent(data:SsData){
        //We are only receiving messages in this app..
        val messageItem: MessageItem =
            Gson().fromJson(data.getData(), MessageItem::class.java)
        messageItem.senderGUID = data.senderId
        //
        var event = data.getData().asJsonObject["event"].asString
        Log.i(TAG, "Received :: Event => $event \nPayload => " + messageItem.content)

        //
        if (messageItem.id == null || messageItem.id.length === 0
        ) {
            messageItem.id = UUID.randomUUID().toString()
        }
        //
        try {
            messageItem.createdAt = mAppUtils.dateFromString(data.time,
                QSSClientService.SERVICE_DATE_FORMAT
            )
        } catch (ex: Exception) {
            Log.e(TAG, "Parse Date Failed.", ex)
            messageItem.createdAt = Calendar.getInstance().time
        }
        //
        var user = service.value?.onlineUsers?.value?.firstOrNull() {
            it.id == data.senderId
        }
        //
        if (user != null) {
            if (user.id == mAppUser?.id ?: "") {
                //
                messageItem.user =
                    ChatUser(
                        user.id,
                        user.name,
                        user.photo,
                        true
                    )
            } else {
                messageItem.user =
                    ChatUser(
                        user.id,
                        user.name,
                        user.photo,
                        true
                    )
            }
        } else {
            var sender =
                ChatUser(
                    data.senderId,
                    messageItem.senderName,
                    "",
                    true
                )
            messageItem.user = sender
        }
        //
        var rec = service.value?.onlineUsers?.value?.firstOrNull() {
            it.id == messageItem.receiverId
        }
        if (rec == null && messageItem.receiverId == mAppUser.id) {
            messageItem.receiverName = mAppUser.name
        }
        //Check the received event
        if(event == "message"){
            //
            CoroutineScope(IO).launch {
                //
                addOrUpdateMessage(messageItem)
            }
        }
    }

    /**
     * Groups direct conversations
     */
    private fun getGroupedDirectChats() :LiveData<List<ChatGroup>> {

        return supportDb.messagesDao().getAll().switchMap { messagesList ->

            var map = MutableLiveData<List<ChatGroup>>()
            coroutineScope.launch {

                var groups = ArrayList<ChatGroup>()
                //Filter
                for (m in EntityMappers.createMessagesFrom(messagesList.filter { it.groupGUID.isNullOrEmpty() })){
                    //
                    val thread : ChatUser
                    //
                    if(m.receiverId == mAppUser.id){
                        //Incoming
                        m.user =
                            ChatUser(
                                m.senderGUID,
                                m.senderName,
                                "",
                                false
                            )
                        thread = m.user
                    }else{
                        //Outgoing
                        m.user =
                            ChatUser(
                                mAppUser.id,
                                mAppUser.name,
                                "",
                                true
                            )
                        thread =
                            ChatUser(
                                m.receiver.id,
                                m.receiver.name,
                                m.receiver.photo,
                                false
                            )
                    }
                    //
                    var found = false
                    //
                    for(g in groups){
                        if(g.id == "${thread.id}|${mAppUser.id}"){
                            g.unreadCount += if (m.status == MessageItem.MessageStatus.Seen ||
                                m.receiverId != mAppUser.id) 0 else 1
                            found = true
                            break
                        }
                    }
                    //Add it
                    if(!found){
                        val group =
                            ChatGroup(
                                "${thread.id}|${mAppUser.id}",
                                thread.name,
                                "",
                                ArrayList<ChatUser>(),
                                m,
                                0
                            )
                        group.users.add(thread)
                        group.type = ChatGroup.GroupType.DIRECT//For tagging
                        Log.w(TAG, "Users => "+group.users.size)
                        //group.users.add(m.user)
                        EntityMappers.createFrom(supportDb.contactsDao().getChatUser(m.user.id))?.let {owner ->
                            //Overwrite
                            m.user = owner
                            group.name = owner.name
                            group.users.add(owner)
                        } ?: run{Log.w(TAG, "Message owner not found in db")}
                        //Count uread incoming messages
                        group.unreadCount += if (m.status == MessageItem.MessageStatus.Seen ||
                            m.receiverId != mAppUser.id) 0 else 1
                        //
                        groups.add(group)
                    }
                }
                //
                map.postValue(groups)
            }
            map
        }
    }

    //Private Implementations
    fun <T, K, R> LiveData<T>.combineWith( liveData: LiveData<K>, block: (T?, K?) -> R ): LiveData<R> {
        val result = MediatorLiveData<R>()
        result.addSource(this) {
            result.value = block.invoke(this.value, liveData.value)
        }
        result.addSource(liveData) {
            result.value = block.invoke(this.value, liveData.value)
        }
        return result
    }

}