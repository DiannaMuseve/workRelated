package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.groups

import androidx.room.Entity

@Entity(tableName = "gm_bridge",primaryKeys = ["groupId", "userId"])
class GroupToMemberBridgeEntity (
    val groupId: Int,
    val userId: Int
)