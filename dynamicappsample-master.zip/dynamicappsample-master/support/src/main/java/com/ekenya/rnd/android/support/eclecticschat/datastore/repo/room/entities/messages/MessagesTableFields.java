package com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.entities.messages;

public class MessagesTableFields {

    public static final String TABLE_NAME = "msg_table";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_ITEM_ID = "msgId";
    //
    public static final String COLUMN_SENDER_ID = "senderId";
    public static final String COLUMN_SENDER_GUID = "senderGuid";
    public static final String COLUMN_SENDER_NAME = "senderName";
    //
    public static final String COLUMN_RECEIVER_ID = "receiverId";
    public static final String COLUMN_RECEIVER_NAME = "receiverName";
    //
    public static final String COLUMN_GROUP_ID = "groupId";
    public static final String COLUMN_GROUP_GUID = "groupGUID";
    //
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_KIND = "kind";
    public static final String COLUMN_TAGGED_MSG = "taggedMsgId";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_CONTENT = "content";
    public static final String COLUMN_FULL_CONTENT = "_fcontent";
    public static final String COLUMN_SEEN = "_seen";
    public static final String COLUMN_ICON = "photo";
    public static final String COLUMN_DATE = "date";
}
