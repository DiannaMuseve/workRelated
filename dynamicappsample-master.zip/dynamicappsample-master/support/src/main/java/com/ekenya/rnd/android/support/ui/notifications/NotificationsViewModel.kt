package com.ekenya.rnd.android.support.ui.notifications

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import com.ekenya.rnd.android.common.models.NotificationItem
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.qss.beans.SsNotification
import javax.inject.Inject

class NotificationsViewModel @Inject constructor(
    private val app: Application,
    private val appDb: IAppRepo
) : AndroidViewModel(app) {

    private val list  = appDb.getAllAlerts()

    val alertList: LiveData<List<NotificationItem>> get() = list.switchMap { alerts ->
        val md = MutableLiveData<List<NotificationItem>>()
        md.postValue(alerts.map { it as NotificationItem })
        md
    }

    init {

    }
}