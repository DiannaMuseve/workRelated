package com.ekenya.rnd.android.support.ui.eclectics;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment;
import com.ekenya.rnd.android.common.services.apputils.IAppUtils;
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService;
import com.ekenya.rnd.android.support.databinding.FragmentEclecticsChatBinding;
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo;
import com.ekenya.rnd.android.support.ui.eclectics.adapters.QssPagerAdapter;
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo;
import com.google.android.material.snackbar.Snackbar;

import javax.inject.Inject;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


public class EclecticsChatFragment extends BaseDaggerFragment {
    private final String TAG = EclecticsChatFragment.class.getSimpleName();

    @Inject
    public ViewModelProvider.Factory viewModelFactory;

    @Inject
    public IAppUtils mAppUtils;

    @Inject
    public IChatRepo mChatRepo;

    private EclecticsChatViewModel eclecticsChatViewModel;
    private FragmentEclecticsChatBinding binding;

    private static final int STORAGE_REQUEST_CODE = 0x15;

    private QssPagerAdapter mAdapter;

    private String mDataDir;

    private ViewPager mViewPager;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDataDir = requireActivity().getFilesDir().getAbsolutePath()+"/GethDroid";

    }
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        //
        eclecticsChatViewModel = new ViewModelProvider(getActivity(),viewModelFactory).get(EclecticsChatViewModel.class);
        //
        binding = FragmentEclecticsChatBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //
        mAdapter = new QssPagerAdapter(getChildFragmentManager());

        //
        mViewPager = binding.qssPager;
        binding.qssTabLayout.setupWithViewPager(mViewPager,true);
        mViewPager.setAdapter(mAdapter);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        eclecticsChatViewModel.getService().observe(getViewLifecycleOwner(), new Observer<EclecticsQssService>() {
            @Override
            public void onChanged(EclecticsQssService eclecticsSupportService) {
                //
                eclecticsSupportService.subscribeForConnectionState()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(mQssConnectionStateConsumer);
                //
                eclecticsSupportService.connectQss(false).subscribe();
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        //
        //eclecticsChatViewModel.getService().removeObservers(this);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case STORAGE_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] ==  PackageManager.PERMISSION_GRANTED) {
                    Log.e("value", "Permission Granted, Now you can use local drive .");
                    //
                } else {
                    Log.e("value", "Permission Denied, You cannot use local drive .");
                    Snackbar bar = Snackbar.make(
                            mViewPager,
                            "Write Storage permissions a required ",
                            Snackbar.LENGTH_INDEFINITE
                    ).setAction("Allow", new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            requestPermissions(
                                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                    STORAGE_REQUEST_CODE
                            );
                        }
                    });
                    bar.show();
                }
            default:
                //
                break;
        }
    }

    private void reconnectQss(){

        eclecticsChatViewModel.getService().observe(getViewLifecycleOwner(), new Observer<EclecticsQssService>() {
            @Override
            public void onChanged(EclecticsQssService eclecticsQssService) {
                //
                eclecticsQssService.connectQss(false).subscribe();
                //
                eclecticsChatViewModel.getService().removeObserver(this);
            }
        });
    }

    private Consumer<Boolean> mQssConnectionStateConsumer = new Consumer<Boolean>() {
        Snackbar bar;
        @Override
        public void accept(Boolean connected) throws Exception {
            //
            if(mViewPager == null)
                return;
            //
            bar = Snackbar.make(mViewPager, "Qss Connection Lost ..",Snackbar.LENGTH_INDEFINITE);
            //
            if(!connected){
                bar.setAction("Re-Connect", new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        reconnectQss();
                        bar.dismiss();
                    }
                });

                final ViewGroup snackBarView = (ViewGroup)bar.getView();
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) snackBarView.getChildAt(0).getLayoutParams();
                params.setMargins(params.leftMargin,
                        params.topMargin,
                        params.rightMargin,
                        (int) (params.bottomMargin + mAppUtils.convertDpToPixel(100)));
                snackBarView.getChildAt(0).setLayoutParams(params);

                //snackBarView.setTranslationY(-65);
                bar.show();
            }else{
                if(bar != null && bar.isShown()){
                    bar.dismiss();
                }
            }
        }
    };

}