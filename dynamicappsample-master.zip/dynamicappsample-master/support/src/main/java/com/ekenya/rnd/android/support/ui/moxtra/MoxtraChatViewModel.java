package com.ekenya.rnd.android.support.ui.moxtra;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

public class MoxtraChatViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    @Inject
    public MoxtraChatViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Moxtra Chat goes here ..");
    }

    public MutableLiveData<String> getText() {
        return mText;
    }
}