package com.ekenya.rnd.android.support.di

import android.content.Context
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.apputils.IAppUtils
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.ChatRepo
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.room.SupportDb
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

@Module
class SupportModule {

    //@Singleton
    @Provides
    fun provideSupportRepository(context: Context,utils:IAppUtils, supportDb: SupportDb, appDb:IAppRepo,scope: CoroutineScope): IChatRepo {
        return ChatRepo(context,supportDb,utils,appDb,scope)
    }

    //@Singleton
    @Provides
    fun provideSupportDatabase(app: Context) = SupportDb.getDatabase(app,
        CoroutineScope(SupervisorJob()),app.resources)
}