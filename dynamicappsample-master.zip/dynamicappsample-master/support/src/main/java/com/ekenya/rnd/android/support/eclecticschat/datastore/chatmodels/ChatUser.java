package com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels;

import com.ekenya.rnd.android.qss.beans.QssUser;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.stfalcon.chatkit.commons.models.IUser;

import java.util.ArrayList;

public class ChatUser extends QssUser implements IUser {

    @SerializedName("online")
    @Expose(serialize = false)
    private boolean online = true;

    @Expose(serialize = false)
    private ArrayList<MessageItem> messages = new ArrayList<>();

    public ChatUser(String id, String name, String avatar, boolean online) {
        super(id, name, avatar);
        this.online = online;
    }

    @Override
    public String getId() {
        return super.getId();
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public String getAvatar() {
        return super.getPhoto();
    }

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public ArrayList<MessageItem> getMessages() {
        return messages;
    }
}
