package com.ekenya.rnd.android.support.ui.eclectics.directchat

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.ListAdapter
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.apputils.IAppUtils
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.qss.QSSClientService
import com.ekenya.rnd.android.support.R
import com.ekenya.rnd.android.support.databinding.FragmentDirectChatMessagesBinding
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatViewModel
import com.ekenya.rnd.android.support.eclecticschat.base.DemoMessagesModalFragment
import com.ekenya.rnd.android.support.eclecticschat.base.holders.IncomingVoiceMessageViewHolder
import com.ekenya.rnd.android.support.eclecticschat.base.holders.OutcomingVoiceMessageViewHolder
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.MessageItem
import com.ekenya.rnd.android.support.eclecticschat.datastore.fixtures.MessagesFixtures
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo
import com.ekenya.rnd.android.support.ui.eclectics.supportchat.QssSupportFragment
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.snackbar.Snackbar
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.commons.models.IMessage
import com.stfalcon.chatkit.messages.MessageHolders
import com.stfalcon.chatkit.messages.MessageInput
import com.stfalcon.chatkit.messages.MessagesList
import com.stfalcon.chatkit.messages.MessagesListAdapter
import io.reactivex.CompletableObserver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.util.*
import javax.inject.Inject

class QssMessagesFragment :
    DemoMessagesModalFragment(), MessageInput.InputListener,
    MessageInput.AttachmentsListener, MessageHolders.ContentChecker<MessageItem>, DialogInterface.OnClickListener {

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    @Inject
    lateinit var mImageLoader: IImageLoader
    @Inject
    lateinit var mAppUtils: IAppUtils
    @Inject
    lateinit var mChatRepo: IChatRepo
    @Inject
    lateinit var mAppRepo:IAppRepo

    private var messagesList: MessagesList? = null

    private lateinit var mChatTitle:TextView
    private lateinit var binding:FragmentDirectChatMessagesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(BottomSheetDialogFragment.STYLE_NORMAL, com.ekenya.rnd.android.common.R.style.BottomSheetTheme)
        //
        mViewModel = ViewModelProviders.of(requireActivity(), viewModelFactory).get(EclecticsChatViewModel::class.java)
        //
        imageLoader = ImageLoader { imageView, url, payload ->
            mImageLoader.loadImage(url,null,imageView)
        }
    }
    override fun onStart() {
        super.onStart()
        //

    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentDirectChatMessagesBinding.inflate(inflater, container, false)
        val rootView: View = binding.getRoot()

        messagesList = rootView.findViewById<View>(R.id.messagesList) as MessagesList
        mChatTitle = rootView.findViewById(R.id.chat_title) as TextView
        //
        val input = rootView.findViewById<View>(R.id.input) as MessageInput
        input.setInputListener(this)
        input.setAttachmentsListener(this)

        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initAdapter()
        //
        //mChatTitle.text = if(mGroup != null) mGroup.dialogName else mReceiver.name
        mChatTitle.text = mGroup?.let{it.dialogName} ?: run{ mReceiver.name }
        binding.closeButton.setOnClickListener {

            dismiss()
        }
        //
        mViewModel.getService().observe(viewLifecycleOwner,
            Observer<EclecticsQssService> { messengerService ->
                if(mGroup == null && mReceiver == null) {
                    updateContent(messengerService)
                }
            })
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        //
        (requireView().parent as View).setBackgroundColor(resources.getColor(android.R.color.transparent))
        //
        mViewModel.getService().observe(viewLifecycleOwner, object : Observer<QSSClientService> {
            override fun onChanged(qssClientService: QSSClientService) {
                qssClientService.subscribeForConnectionState()
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : io.reactivex.Observer<Boolean> {
                        override fun onSubscribe(d: Disposable) {}
                        override fun onNext(connected: Boolean) {
                            if (!connected!!) {
                                val bar = Snackbar.make(
                                    messagesList!!,
                                    "Service Connection Lost",
                                    Snackbar.LENGTH_INDEFINITE
                                )
                                bar.setAction("Connect") {
                                    qssClientService.connectQss(true).subscribe()
                                    bar.dismiss()
                                }
                                bar.show()
                            }
                        }

                        override fun onError(e: Throwable) {}
                        override fun onComplete() {}
                    })
            }
        })
    }

    override fun onSubmit(input: CharSequence): Boolean {
//        super.messagesAdapter.addToStart(
//                MessagesFixtures.getTextMessage(input.toString()), true);
        mViewModel.currentSender.observe(this, object : Observer<ChatUser> {

            override fun onChanged(sender: ChatUser) {

                val msg =
                    MessageItem(
                        UUID.randomUUID().toString(),
                        sender,
                        input.toString(),
                        Calendar.getInstance().time
                    )
                msg.kind = MessageItem.MessageKind.Text
                //messagesAdapter.addToStart(msg, true)
                //
                val observer: CompletableObserver = object : CompletableObserver {
                    override fun onSubscribe(d: Disposable) {
                        //mMessageInput.getInputEditText().setEnabled(false);
                    }

                    override fun onComplete() {
                        msg.setStatus(MessageItem.MessageStatus.Sent)
                        messagesAdapter.update(msg)
                        //mMessageInput.getInputEditText().setEnabled(true);
                    }

                    override fun onError(e: Throwable) {
                        mAppUtils.showToast("Send Message Failed: " + e.message, true)
                        //
                        msg.setStatus(MessageItem.MessageStatus.Failed)
                        messagesAdapter.update(msg)
                        //mMessageInput.getInputEditText().setEnabled(true);
                    }
                }
                //
                if(mGroup != null && mGroup.type == ChatGroup.GroupType.GROUPED) {
                    msg.groupGUID = mGroup!!.id
                    mViewModel.sendGroupMessage(msg, mGroup!!.id).subscribe(observer)
                }else{
                    msg.receiverId = mReceiver.id
                    msg.receiverName = mReceiver!!.name
                    mViewModel.sendDirectMessage(msg, mReceiver!!.id).subscribe(observer)
                }
                //
                mViewModel.currentSender.removeObserver(this)
            }
        })

        return true
    }

    override fun onAddAttachments() {
        AlertDialog.Builder(context)
            .setItems(R.array.view_types_dialog, this)
            .show()
    }

    override fun hasContentFor(message: MessageItem, type: Byte): Boolean {
        when (type) {
            CONTENT_TYPE_VOICE -> return message.getVoice() != null && message.getVoice()
                .getUrl() != null && !message.getVoice().getUrl().isEmpty()
        }
        return false
    }

    override fun onClick(dialogInterface: DialogInterface, i: Int) {
        when (i) {
            0 -> messagesAdapter.addToStart(MessagesFixtures.getImageMessage(), true)
            1 -> messagesAdapter.addToStart(MessagesFixtures.getVoiceMessage(), true)
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)//BottomSheetDialog(requireContext(), theme)
        dialog.setOnShowListener {
            val bottomSheetDialog = it as BottomSheetDialog
            val parentLayout = bottomSheetDialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            parentLayout?.let { it ->
                val behaviour = BottomSheetBehavior.from(it)
                setupFullHeight(it)
                behaviour.state = BottomSheetBehavior.STATE_EXPANDED
            }
        }

//        dialog.setOnShowListener { dialog ->
//            val dialogc =
//                dialog as BottomSheetDialog
//            // When using AndroidX the resource can be found at com.google.android.material.R.id.design_bottom_sheet
//            val bottomSheet = dialogc.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
//            val bottomSheetBehavior: BottomSheetBehavior<*> = BottomSheetBehavior.from(bottomSheet!!)
//            bottomSheetBehavior.peekHeight = Resources.getSystem().getDisplayMetrics().heightPixels
//            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED)
//        }
        return dialog
    }

    private fun setupFullHeight(bottomSheet: View) {
        val layoutParams = bottomSheet.layoutParams
        layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT
        bottomSheet.layoutParams = layoutParams
    }

    fun updateContent(qssService: EclecticsQssService) {
        val users: List<ChatUser> = qssService.onlineUsers.value?.map { qssUser ->
            ChatUser(
                qssUser.id,
                qssUser.name,
                qssUser.photo,
                true
            )
        } ?: ArrayList<ChatUser>()
        //
        val names: MutableList<String> = ArrayList()
        if (users != null) {
            for (u in users) {
                names.add(u.getName())
            }
        }
        //
        val adapter: ListAdapter = object : ArrayAdapter<ChatUser?>(
            requireContext(),
            android.R.layout.select_dialog_singlechoice, android.R.id.text1, users
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                // User super class to create the View
                val view = super.getView(position, convertView, parent)
                val tv = view.findViewById<TextView>(android.R.id.text1)

                // Put the image on the TextView
                // tv.setCompoundDrawablesWithIntrinsicBounds(users.get(position).icon, null,null, null);
                tv.setText(users[position].getName())
                // Add margin between image and text (support various screen densities)
                val dp10 = (10 * context.resources.displayMetrics.density + 0.5f).toInt()
                tv.compoundDrawablePadding = dp10
                return view
            }
        }
        //
        val builder = AlertDialog.Builder(context, android.R.style.Theme_Holo_Light_Dialog) //
            .setTitle("Select Recipient ..")
            .setAdapter(adapter) { dialogInterface, i ->
                var rec = users[i]
                //
                mGroup =
                    ChatGroup(
                        rec!!.id,
                        rec!!.name,
                        "",
                        ArrayList<ChatUser>(),
                        null,
                        0
                    )
                //
                (activity as AppCompatActivity?)!!.supportActionBar
                    ?.setSubtitle("Chat with " + rec!!.name)
            }.setNegativeButton(
                "Cancel"
            ) { dialogInterface, i ->
                //
            }
        val dialog: Dialog = builder.create()
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.show()
    }

    private fun initAdapter() {
        val holders = MessageHolders()
            .registerContentType(
                CONTENT_TYPE_VOICE,
                IncomingVoiceMessageViewHolder::class.java,
                R.layout.item_custom_incoming_voice_message,
                OutcomingVoiceMessageViewHolder::class.java,
                R.layout.item_custom_outcoming_voice_message,
                this
            )

        //
        mViewModel.currentSender.observe(viewLifecycleOwner, Observer {
            super.messagesAdapter = MessagesListAdapter<IMessage>(it.id, holders, imageLoader)
            super.messagesAdapter.enableSelectionMode(this)
            super.messagesAdapter.setLoadMoreListener(this)
            messagesList!!.setAdapter<IMessage>(super.messagesAdapter)
        })
    }

    companion object {
        private const val CONTENT_TYPE_VOICE: Byte = 1
        fun open(context: Context) {
            context.startActivity(Intent(context, QssSupportFragment::class.java))
        }
    }
}