package com.ekenya.rnd.android.support.ui.eclectics

import android.app.Application
import android.util.Log
import androidx.lifecycle.*
import androidx.lifecycle.Observer
import com.ekenya.rnd.android.common.models.UserAccount
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.apputils.IAppUtils
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.qss.QSSClientService
import com.ekenya.rnd.android.qss.beans.QssEvents
import com.ekenya.rnd.android.qss.beans.SsData
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.MessageItem
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.stfalcon.chatkit.commons.models.IMessage
import io.reactivex.Completable
import io.reactivex.SingleObserver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.PublishSubject
import kotlinx.coroutines.*
import java.util.*
import javax.inject.Inject
import kotlin.collections.ArrayList

class EclecticsChatViewModel @Inject constructor(
    private val app: Application,
    private val mAppRepo: IAppRepo,
    private val mGson: Gson,
    private val mAppUtils:IAppUtils,
    private val mChatRepo: IChatRepo
): AndroidViewModel(app) {

    override fun onCleared() {
        super.onCleared()
        //mService.
    }

    fun getMessages(threadId: String, lastLoadDate: Date?): LiveData<List<IMessage>> {
        //
        var ld = MutableLiveData<List<IMessage>>()
        //
        return mChatRepo.getAllMessages().switchMap { msgsRepo ->

            var list = msgsRepo.filter {
                //Outgoing
                it.receiverId == threadId ||
                        //Incoming
                    it.user?.id == threadId && it.receiverId == mCurrentUser.value?.id ?: "`"
            }.also {
                    it.filter { msg ->
                        if(lastLoadDate != null)  msg.createdAt <= lastLoadDate else true
                    }
            }
            ld.postValue(list)
            ld
        }.also {
            //
        }
    }

    val currentSender: LiveData<ChatUser> get() = mCurrentUser

    //Reference the instance defined in repo
    fun getService(): MutableLiveData<EclecticsQssService> = mChatRepo.getService()

    fun getGroups(): LiveData<List<ChatGroup>> = mChatRepo.getAllGroups()

    fun getIsTyingObserver():io.reactivex.Observable<MessageItem> = isTypingObserver

    fun getNewMessageObserver():io.reactivex.Observable<MessageItem> = onNewMessageObserver

    fun sendDirectMessage(messageItem: MessageItem, receiver: String): Completable {
        //
        return Completable.create { emitter ->
            getService().value?.let { svc ->
                //App specific event label
                var jobject = mGson.toJsonTree(messageItem)
                jobject.asJsonObject.addProperty("event", "message")
                jobject.asJsonObject.addProperty("kind", messageItem.kind.name)
                //
                val data = SsData()
                data.setData(jobject)
                //
                svc.sendDirectData(data, receiver)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : SingleObserver<Boolean> {
                        override fun onSubscribe(d: Disposable) {
                            //
                        }

                        override fun onSuccess(t: Boolean) {
                            emitter.onComplete()
                            //
                            if(messageItem.kind !== MessageItem.MessageKind.IsTyping) {
                                //appendMessage(msg, recId)
                                if(messageItem.user == null) {
                                    messageItem.user = currentSender.value
                                }
                                CoroutineScope(Dispatchers.IO).launch {
                                    mChatRepo.addOrUpdateMessage(messageItem)
                                }
                            }else{
                                //
                            }

                        }

                        override fun onError(e: Throwable) {
                            emitter.onError(e)
                        }
                    })
            } ?: emitter.onError(Exception("QSS Service is Not Bound"))
        }
    }

    fun sendGroupMessage(msg: MessageItem, threadId: String): Completable {

        return Completable.create { emitter ->
            getService()?.value?.let { svc ->
                //
                var jobject = mGson.toJsonTree(msg)
                if(msg.kind == MessageItem.MessageKind.IsTyping) {
                    jobject.asJsonObject.addProperty("event", "isTyping")
                }else{
                    jobject.asJsonObject.addProperty("event", "message")
                }
                //
                val data = SsData()
                data.setData(jobject)
                //
                svc.sendGroupData(data, threadId)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : SingleObserver<Boolean> {
                        override fun onSubscribe(d: Disposable) {
                            //
                        }

                        override fun onSuccess(t: Boolean) {
                            emitter.onComplete()
                            //
                            msg.groupGUID = threadId
                            //
                            viewModelScope.launch {
                                mChatRepo.addOrUpdateMessage(msg)
                            }
                        }

                        override fun onError(e: Throwable) {
                            emitter.onError(e)
                        }
                    })
            } ?: emitter.onError(Exception("QSS Service is Not Bound"))
        }
    }

    fun createGroup(name: String, users: List<ChatUser>): Completable {
        return Completable.create { emitter ->
            getService()?.value?.let { svc ->
                //
                var members = JsonArray()
                for(s in users){
                    members.add(s.id)
                }
                //
                svc.createGroup(name, Gson().toJsonTree(members))
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(object : SingleObserver<Boolean> {
                        override fun onSubscribe(d: Disposable) {
                            //
                        }

                        override fun onSuccess(t: Boolean) {
                            emitter.onComplete()
                        }

                        override fun onError(e: Throwable) {
                            emitter.onError(e)
                        }
                    })
            } ?: emitter.onError(Exception("QSS Service is Not Bound"))
        }
    }

    private val mQssDataObserver: io.reactivex.Observer<SsData> =
        object : io.reactivex.Observer<SsData> {
            override fun onSubscribe(d: Disposable) {}
            override fun onNext(data: SsData) {
                Log.i(TAG, "Received Data => " + mGson.toJson(data))
                //
                when(data.action){
                    //
                    QssEvents.Payload -> {
                        //We are only receiving messages in this app..
                        val messageItem: MessageItem =
                            Gson().fromJson(data.getData(), MessageItem::class.java)
                        //
                        var event = data.getData().asJsonObject["event"].asString
                        Log.i(TAG, "Received :: Event => $event \nPayload => " + messageItem.content)

                        //
                        if (messageItem.id == null || messageItem.id.length === 0
                        ) {
                            messageItem.id = UUID.randomUUID().toString()
                        }
                        //
                        try {
                            messageItem.createdAt = mAppUtils.dateFromString(data.time,
                                QSSClientService.SERVICE_DATE_FORMAT
                            )
                        } catch (ex: Exception) {
                            Log.e(TAG, "Parse Date Failed.", ex)
                            messageItem.createdAt = Calendar.getInstance().time
                        }
                        //
                        var user = getService().value?.onlineUsers?.value?.firstOrNull() {
                            it.id == data.senderId
                        }
                        //
                        if (user != null) {
                            if (user.id == currentSender.value?.id ?: "") {
                                //
                                messageItem.user =
                                    ChatUser(
                                        user.id,
                                        user.name,
                                        user.photo,
                                        true
                                    )
                            } else {
                                messageItem.user =
                                    ChatUser(
                                        user.id,
                                        user.name,
                                        user.photo,
                                        true
                                    )
                            }
                        } else {
                            var sender =
                                ChatUser(
                                    data.senderId,
                                    messageItem.senderName,
                                    "",
                                    true
                                )
                            messageItem.user = sender
                        }
                        //
                        var rec = getService().value?.onlineUsers?.value?.firstOrNull() {
                            it.id == messageItem.receiverId
                        }
                        if (rec != null) {
                            messageItem.receiver.name = rec.name
                        }
                        //Check the received event
                        if(event == "isTyping"){
                            //
                            isTypingObserver.onNext(messageItem)
                            return
                        }else if(event == "deliveryReceipt"){
                            //
                            return
                        }else if(event == "approval"){
                            //TODO:Post a notification
                            return
                        }else{
                            //Default
                            CoroutineScope(Dispatchers.IO).launch {  //viewModelScope.launch {
                                mChatRepo.addOrUpdateMessage(messageItem)
                                //appendMessage(messageItem, data.senderId)
                            }
                            //
                            onNewMessageObserver.onNext(messageItem)
                        }

                    }
                    else -> {
                        //
                        Log.i(TAG, "Unprocessed Payload => " + data.action)
                    }
                }
            }

            override fun onError(e: Throwable) {}
            override fun onComplete() {}
        }

    init {
        //
        mAppRepo.getUsers().observeForever(object : Observer<List<UserAccount>> {
            override fun onChanged(userAccounts: List<UserAccount>) {
                if (userAccounts.isEmpty()) {
                    return
                }
                //
                val user = userAccounts[0]
                mCurrentUser.postValue(
                    ChatUser(
                        user.id,
                        user.name,
                        user.photo,
                        false
                    )
                )
            }
        })
        getService().observeForever { eclecticsQssService ->
            //
            eclecticsQssService.subscribeForData()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(mQssDataObserver)
            //
            eclecticsQssService.onlineUsers
                .observeForever { qssUsers ->
                    //
                    val users: MutableList<ChatUser> =
                        (mOnlineUsers.value as? MutableList<ChatUser>) ?: ArrayList<ChatUser>()
                    //
                    users.clear()
                    //
                    for (user in qssUsers) {
                        users.add(
                            ChatUser(
                                user.id,
                                user.name,
                                user.photo,
                                true
                            )
                        )
                    }
                    mOnlineUsers.postValue(users)
                }
        }
    }

    companion object{

        private val TAG = EclecticsChatViewModel::class.java.simpleName

        private val mCurrentUser = MutableLiveData<ChatUser>()

        private val mOnlineUsers = MutableLiveData<List<ChatUser>>().apply {
            value = ArrayList<ChatUser>()
        }


        private val mDialogs = MutableLiveData<List<ChatGroup>>().apply {
            value = ArrayList<ChatGroup>()
        }

        private var isTypingObserver = PublishSubject.create<MessageItem>()

        private var onNewMessageObserver = PublishSubject.create<MessageItem>()
    }
}
