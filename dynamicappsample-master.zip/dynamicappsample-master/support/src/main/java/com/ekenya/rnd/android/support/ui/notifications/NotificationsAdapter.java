package com.ekenya.rnd.android.support.ui.notifications;

import android.content.Context;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ekenya.rnd.android.common.models.NotificationItem;
import com.ekenya.rnd.android.common.services.apputils.IAppUtils;
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader;
import com.ekenya.rnd.android.common.ui.adapters.GenericRecyclerAdapter;
import com.ekenya.rnd.android.support.R;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import javax.inject.Inject;

public class NotificationsAdapter extends GenericRecyclerAdapter<NotificationItem> {
    private static final String TAG = NotificationsAdapter.class.getSimpleName();

    @Inject
    public IImageLoader mImageLoader;

    @Inject
    public IAppUtils mAppUtils;


    @Override
    protected List<NotificationItem> getFilteredResults(String constraint) {
        List<NotificationItem> results = new ArrayList<>();
        for (NotificationItem item : mOriginalItems) {
            if (item.getTitle().toLowerCase().contains(constraint)) {
                results.add(item);
            }
        }
        return results;
    }


    public interface NotificationsCallback {
        void onMenuClicked(View row, NotificationItem service, MenuItem menu);

        void onClick(View row, NotificationItem service);

        void onLongClick(View row, NotificationItem service);
    }

    private final LinkedList<NotificationsCallback> mCallbacks = new LinkedList<>();

    private GenericRecyclerAdapter.Orientation mMode = GenericRecyclerAdapter.Orientation.VERTICAL;

    public void setMode(GenericRecyclerAdapter.Orientation mode){
        mMode = mode;
    }
    public List<NotificationsCallback> getCallbacks() {
        return mCallbacks;
    }

    @Inject
    public NotificationsAdapter(Context context){
        super(context);
    }
    public NotificationsAdapter(Context context, List<NotificationItem> items, GenericRecyclerAdapter.Orientation mode) {
        super(context);
        //
        mMode = mode;
        mOriginalItems = items;
        mFilteredItems = mOriginalItems;

    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public long getItemId(int position) {
        //return mFilteredList.get(position).getId();
        return position;
    }

    @Override
    public int getItemCount() {
        //Log.i(TAG, "Get count :; Returned  = " + mFilteredList.size());
        //
        //Sort descending by date
        Collections.sort(mFilteredItems, new Comparator<NotificationItem>() {
            @Override
            public int compare(NotificationItem lhs, NotificationItem rhs) {
                // -1 - less than, 1 - greater than, 0 - equal, all inversed for descending
                return lhs.getTime().getTime() > rhs.getTime().getTime() ? -1 : (lhs.getTime().getTime() < rhs.getTime().getTime()) ? 1 : 0;
            }
        });
        //
        return mFilteredItems.size();
    }


    @Override
    public NotificationsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //
        View rootView = null;
        if(mMode == NotificationsAdapter.Orientation.VERTICAL)
            rootView = LayoutInflater.from(mContext).inflate(R.layout.alerts_row_item, parent, false);
        else//
            rootView = LayoutInflater.from(mContext).inflate(R.layout.alerts_row_item, parent, false);
        //
        return new NotificationsAdapter.ViewHolder(rootView);
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int position) {
        //Log.d(TAG,"Get view at "+position);

        NotificationsAdapter.ViewHolder holder = (NotificationsAdapter.ViewHolder)h;
        //
        final NotificationItem item = mFilteredItems.get(position);
        //

        //
        holder.Title.setText(item.getTitle());
        holder.Message.setText(item.getContent());
        if(item.isSeen()) {
            holder.Status.setText("✓✓");
            holder.Status.setTextColor(mContext.getResources().getColor(android.R.color.holo_blue_light));
        }else{
            holder.Status.setText("✓");
            holder.Status.setTextColor(mContext.getResources().getColor(android.R.color.darker_gray));
        }
        //
        holder.Time.setText(mAppUtils.formatDateAndTime(item.getTime()));
        //
        mImageLoader.loadImage(item.getPhotoPath(),com.ekenya.rnd.android.common.R.drawable.ic_alert,holder.Image);
        //
        Animation spinAnimation = AnimationUtils.loadAnimation(mContext, com.ekenya.rnd.android.common.R.anim.spin_animation);
        Drawable loader = null;
        //
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                loader = ImageDecoder.decodeDrawable(ImageDecoder.createSource(mContext.getResources(), com.ekenya.rnd.android.common.R.drawable.loading));
            } catch (IOException e) {
                e.printStackTrace();
            }
            //
            if (loader != null && loader instanceof AnimatedImageDrawable) {
                ((AnimatedImageDrawable) loader).start();
            }
        }else{
            loader = mContext.getResources().getDrawable(com.ekenya.rnd.android.common.R.drawable.logo);
        }
        //
        mImageLoader.loadImage(item.getPhotoPath(),loader,holder.Image);
        //
        holder.Options.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Creating the instance of PopupMenu
                PopupMenu popup = new PopupMenu(mContext, v);
                //Inflating the Popup using xml file
                //popup.getMenuInflater().inflate(R.menu.alert_options_menu, popup.getMenu());
                //registering popup with OnMenuItemClickListener
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem menu) {
                        for(NotificationsCallback callback: mCallbacks)
                            callback.onMenuClicked(holder.RootView,item,menu);
                        return true;
                    }
                });
                //
                mAppUtils.showPopupMenuIcons(popup);
                //
                popup.show(); //showing popup menu
            }
        });
        //
        holder.RootView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (NotificationsCallback cb : mCallbacks)
                    cb.onClick(v, item);
            }
        });
        //
        holder.RootView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                for (NotificationsCallback cb : mCallbacks)
                    cb.onLongClick(v, item);
                //
                return true;
            }

        });
    }

    @Override
    public void addAll(List<NotificationItem> items) {
        //Clear first
        mOriginalItems.clear();
        mFilteredItems.clear();
        //
        for (NotificationItem item : items) {
            //
            boolean added = false;
            //
            for (NotificationItem key : mOriginalItems) {
                //Found source
                if (key.getId() == item.getId()) {
                    added = true;
                    break;
                }
            }
            //
            if (!added) {
                mOriginalItems.add(item);
            }
        }
        //Apply any active filter
        getFilter().filter(currentFilterConstraint);
    }

    @Override
    public boolean addItem(NotificationItem item) {
        //All sources
        boolean added = false;
        //
        for (NotificationItem key : mOriginalItems) {
            //Found source
            if (key.getId() == item.getId()) {
                added = true;
                break;
            }
        }
        //
        if (!added) {
            mOriginalItems.add(item);
        }
        //Apply any active filter
        getFilter().filter(currentFilterConstraint);
        //
        return added;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView Image;
        public TextView Title;
        public TextView Message;
        public TextView Time;
        public TextView Status;
        public ImageButton Options;
        //
        public View RootView;

        public ViewHolder(final View root) {
            super(root);
            Title = (TextView) root.findViewById(R.id.tv_title);
            Image = (ImageView) root.findViewById(R.id.img_photo);
            Message = (TextView) root.findViewById(R.id.tv_content);
            Time = (TextView) root.findViewById(R.id.tv_time);
            Status = (TextView) root.findViewById(R.id.tv_seen);
            Options = root.findViewById(R.id.btn_options);
            //
            RootView = root;
        }
    }
}