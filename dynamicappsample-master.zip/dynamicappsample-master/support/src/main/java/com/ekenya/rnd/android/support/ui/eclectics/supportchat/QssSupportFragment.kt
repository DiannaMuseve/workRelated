package com.ekenya.rnd.android.support.ui.eclectics.supportchat

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.apputils.IAppUtils
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.qss.beans.QssUser
import com.ekenya.rnd.android.support.R
import com.ekenya.rnd.android.support.ui.eclectics.EclecticsChatViewModel
import com.ekenya.rnd.android.support.eclecticschat.base.DemoMessagesFragment
import com.ekenya.rnd.android.support.eclecticschat.base.holders.IncomingVoiceMessageViewHolder
import com.ekenya.rnd.android.support.eclecticschat.base.holders.OutcomingVoiceMessageViewHolder
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatGroup
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.ChatUser
import com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels.MessageItem
import com.ekenya.rnd.android.support.eclecticschat.datastore.fixtures.MessagesFixtures
import com.ekenya.rnd.android.support.eclecticschat.datastore.repo.IChatRepo
import com.google.android.material.snackbar.Snackbar
import com.stfalcon.chatkit.commons.ImageLoader
import com.stfalcon.chatkit.commons.models.IMessage
import com.stfalcon.chatkit.messages.MessageHolders
import com.stfalcon.chatkit.messages.MessageHolders.ContentChecker
import com.stfalcon.chatkit.messages.MessageInput
import com.stfalcon.chatkit.messages.MessageInput.AttachmentsListener
import com.stfalcon.chatkit.messages.MessageInput.InputListener
import com.stfalcon.chatkit.messages.MessagesList
import com.stfalcon.chatkit.messages.MessagesListAdapter
import io.reactivex.CompletableObserver
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.util.*
import javax.inject.Inject

class QssSupportFragment : DemoMessagesFragment() , InputListener,
    AttachmentsListener, ContentChecker<MessageItem>, DialogInterface.OnClickListener {

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    @Inject
    lateinit var mImageLoader: IImageLoader

    @Inject
    lateinit var mAppUtils: IAppUtils

    @Inject
    lateinit var mChatRepo: IChatRepo
    @Inject
    lateinit var mAppRepo: IAppRepo

    private var mReceiver: QssUser? = null
    private var messagesList: MessagesList? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //
        mViewModel = ViewModelProviders.of(requireActivity(), viewModelFactory).get(EclecticsChatViewModel::class.java)

        //
        mGroup =
            ChatGroup(
                "support@eclectics.io",
                "Support Chat",
                null,
                ArrayList<ChatUser>(),
                null,
                0
            )
        mReceiver =
            ChatUser(
                "support@eclectics.io",
                "Support Chat",
                "",
                true
            )
        //
        imageLoader = ImageLoader { imageView, url, payload ->
            mImageLoader.loadImage(url,null,imageView)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView: View =
            inflater.inflate(R.layout.fragment_messages_list, container, false)

        messagesList = rootView.findViewById<View>(R.id.messagesList) as MessagesList
        val input = rootView.findViewById<View>(R.id.input) as MessageInput
        input.setInputListener(this)
        input.setAttachmentsListener(this)

        return rootView
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initAdapter()
        //
        mViewModel.getService().observe(viewLifecycleOwner,
            Observer<EclecticsQssService> {  messengerService ->
                //updateContent(messengerService)
            })
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        mViewModel.getService().observe(viewLifecycleOwner) { qssClientService -> //
            //
            qssClientService.subscribeForConnectionState()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : io.reactivex.Observer<Boolean> {
                    override fun onSubscribe(d: Disposable) {}
                    override fun onNext(connected: Boolean) {
                        if (!connected!!) {
                            val bar = Snackbar.make(
                                messagesList!!,
                                "Service Connection Lost",
                                Snackbar.LENGTH_INDEFINITE
                            )
                            bar.setAction("Connect") {
                                qssClientService.connectQss(true).subscribe()
                                bar.dismiss()
                            }
                            bar.show()
                        }
                    }

                    override fun onError(e: Throwable) {}
                    override fun onComplete() {}
                })
            //Start the connections
            qssClientService.connectQss(false).subscribe()
        }
    }

    override fun setUserVisibleHint(visible: Boolean) {
        super.setUserVisibleHint(visible)
        if (visible && isResumed) {
            //Only manually call onResume if fragment is already visible
            //Otherwise allow natural fragment lifecycle to call onResume
            onResume()
        }
    }

    override fun onResume() {
        super.onResume()
        if (!userVisibleHint) {
            return
        }

        //INSERT CUSTOM CODE HERE
        //
        (activity as AppCompatActivity?)!!.supportActionBar!!.setTitle("Eclectics Support Chat")
        //
        (activity as AppCompatActivity?)!!.supportActionBar!!.setSubtitle(null)
    }

    override fun onSubmit(input: CharSequence): Boolean {
//        super.messagesAdapter.addToStart(
//                MessagesFixtures.getTextMessage(input.toString()), true);

        mViewModel.currentSender.observe(this, object : Observer<ChatUser> {

            override fun onChanged(it: ChatUser) {

                val msg =
                    MessageItem(
                        UUID.randomUUID().toString(), it, input.toString(),
                        Calendar.getInstance().time
                    )
                messagesAdapter.addToStart(msg, true)
                //
                val observer: CompletableObserver = object : CompletableObserver {
                    override fun onSubscribe(d: Disposable) {
                        //mMessageInput.getInputEditText().setEnabled(false);
                    }

                    override fun onComplete() {
                        msg.setStatus(MessageItem.MessageStatus.Sent)
                        messagesAdapter.update(msg)
                        //mMessageInput.getInputEditText().setEnabled(true);
                    }

                    override fun onError(e: Throwable) {
                        mAppUtils.showToast("Send Message Failed: " + e.message, true)
                        //
                        msg.setStatus(MessageItem.MessageStatus.Failed)
                        messagesAdapter.update(msg)
                        //mMessageInput.getInputEditText().setEnabled(true);
                    }
                }
                //
                msg.setReceiverId(mReceiver!!.id)
                mViewModel.sendDirectMessage(msg, mReceiver!!.id).subscribe(observer)
                //
                mViewModel.currentSender.removeObserver(this)
            }
        })
        return true
    }

    override fun onAddAttachments() {
        AlertDialog.Builder(context)
            .setItems(R.array.view_types_dialog, this)
            .show()
    }

    override fun hasContentFor(message: MessageItem, type: Byte): Boolean {
        when (type) {
            CONTENT_TYPE_VOICE -> return message.getVoice() != null && message.getVoice()
                .getUrl() != null && !message.getVoice().getUrl().isEmpty()
        }
        return false
    }

    override fun onClick(dialogInterface: DialogInterface, i: Int) {
        when (i) {
            0 -> messagesAdapter.addToStart(MessagesFixtures.getImageMessage(), true)
            1 -> messagesAdapter.addToStart(MessagesFixtures.getVoiceMessage(), true)
        }
    }


    private fun initAdapter() {
        val holders = MessageHolders()
            .registerContentType(
                CONTENT_TYPE_VOICE,
                IncomingVoiceMessageViewHolder::class.java,
                R.layout.item_custom_incoming_voice_message,
                OutcomingVoiceMessageViewHolder::class.java,
                R.layout.item_custom_outcoming_voice_message,
                this
            )
        //
        mViewModel.currentSender.observe(viewLifecycleOwner, Observer {
            super.messagesAdapter = MessagesListAdapter<IMessage>(it.id, holders, imageLoader)
            super.messagesAdapter.enableSelectionMode(this)
            super.messagesAdapter.setLoadMoreListener(this)
            messagesList!!.setAdapter<IMessage>(super.messagesAdapter)
        })
    }

    companion object {
        private const val CONTENT_TYPE_VOICE: Byte = 1
        fun open(context: Context) {
            context.startActivity(Intent(context, QssSupportFragment::class.java))
        }
    }
}
