package com.ekenya.rnd.android.support.eclecticschat.datastore.chatmodels;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import com.ekenya.rnd.android.qss.beans.QssUser;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.stfalcon.chatkit.commons.models.IMessage;
import com.stfalcon.chatkit.commons.models.MessageContentType;

/**
 * Created by Bourne Koloh on 11 October,2019.
 * Eclectics International, Products and R&D
 * PROJECT: Qss Sample
 */
public class MessageItem implements IMessage,
        MessageContentType.Image, /*this is for default image messages implementation*/
        MessageContentType /*and this one is for custom content type (in this case - voice message)*/ ,
        Serializable {
    public enum MessageKind{

        IsTyping("isTyping"),
        DeliveryReport("delivered"),
        ReadReport("read"),
        //
        Text("text"),
        Voice("audio"),
        Image("photo"),
        Video("video"),
        Location("location"),
        Emoji("emoji"),
        Contact("contact"),
        Link("link"),
        Custom("custom"),
        Html("html");

        private final String text;

        /**
         * @param text
         */
        MessageKind(final String text) {
            this.text = text;
        }

        /* (non-Javadoc)
         * @see java.lang.Enum#toString()
         */
        @Override
        public String toString() {
            return text;
        }
    }

    public enum MessageStatus{
        Sent,Delivered,Seen,Failed
    }
    @SerializedName("id")
    private String id;
    @SerializedName("recName")
    private String receiverName;
    @SerializedName("rec")
    private String receiverId;
    @SerializedName("senderId")
    private String senderGUID;
    @SerializedName("senderName")
    private String senderName;
    @SerializedName("content")
    private String content;
    @SerializedName("gid")
    private String groupGUID;
    //@SerializedName("uid")
    @Expose(serialize = false,deserialize = false)
    private int groupId;
    @SerializedName("linkedMsg")
    private String linkedMessageId;
    @SerializedName("video")
    private Video video;
    @SerializedName("kind")
    private MessageKind kind = MessageKind.Text;
    @SerializedName("time")
    @Expose(serialize = false)
    private Date createdAt = Calendar.getInstance().getTime();
    @Expose(serialize = false)
    private ChatUser user;
    @SerializedName("img")
    private Image image;
    @SerializedName("audio")
    private Voice voice;
    private MessageStatus status = MessageStatus.Sent;
    private boolean read;

    public MessageItem(){ kind = MessageKind.Text;

    }
    public MessageItem(String id, ChatUser user, String content) {
        this(id, user, content, new Date());
    }

    public MessageItem(String id, ChatUser user, String content, Date createdAt) {
        this.id = id;
        this.content = content;
        this.user = user;
        this.createdAt = createdAt;
        this.kind = MessageKind.Text;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(String id) {
        this.receiverId = id;
    }

    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    @Override
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String getContent() {
        return content;
    }


    public void setContent(String content) {
        this.content = content;
    }

    public void setLinkedMessageId(String linkedMessageId) {
        this.linkedMessageId = linkedMessageId;
    }

    @Override
    public Date getCreatedAt() {
        return createdAt;
    }

    public void setUser(ChatUser user) {
        this.user = user;
    }

    @Override
    public ChatUser getUser() {
        return this.user;
    }


    public QssUser getReceiver() {
        if (receiverId == user.getId()){
            return getUser();
        }
        return new ChatUser(receiverId,receiverName,null,false);
    }

    @Override
    public String getImageUrl() {
        return image == null ? null : image.url;
    }

    public void setImage(Image image) {
        this.image = image;
    }

    public Voice getVoice() {
        return voice;
    }

    public MessageStatus getStatus() {
        return status;
    }

    public void setStatus(MessageStatus status) {
        this.status = status;
    }

    public MessageKind getKind() {
        return kind;
    }

    public void setKind(MessageKind kind) {
        this.kind = kind;
    }

    public void setVoice(Voice voice) {
        this.voice = voice;
    }

    public Video getVideo() {
        return video;
    }

    public void setVideo(Video video) {
        this.video = video;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int group) {
        this.groupId = group;
    }

    public String getSenderGUID() {
        return senderGUID;
    }

    public void setSenderGUID(String senderGUID) {
        this.senderGUID = senderGUID;
    }

    public String getGroupGUID() {
        return groupGUID;
    }

    public void setGroupGUID(String groupGUID) {
        this.groupGUID = groupGUID;
    }

    public String getTaggedMessageId() {
        return linkedMessageId;
    }

    public void setTaggedMessageId(String taggedMessageId) {
        this.linkedMessageId = taggedMessageId;
    }
    public static class Image {

        private String url;

        public Image(String url) {
            this.url = url;
        }
    }
    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public static class Voice {

        private String url;
        private int duration;

        public Voice(String url, int duration) {
            this.url = url;
            this.duration = duration;
        }

        public String getUrl() {
            return url;
        }

        public int getDuration() {
            return duration;
        }
    }

    public static class Video {

        private String url;
        private int duration;

        public Video(String url, int duration) {
            this.url = url;
            this.duration = duration;
        }

        public String getUrl() {
            return url;
        }

        public int getDuration() {
            return duration;
        }
    }

    public class MessageResponse{
        @SerializedName("id")
        public String id;
        @SerializedName("action")
        public String action;
        @SerializedName("sender")
        public String sender;
        @SerializedName("payload")
        public MessageBody data;
    }

    public class MessageBody{
        @SerializedName("name")
        public String name;
        @SerializedName("group")
        public String group;
        @SerializedName("msg")
        public String body;
    }
}
