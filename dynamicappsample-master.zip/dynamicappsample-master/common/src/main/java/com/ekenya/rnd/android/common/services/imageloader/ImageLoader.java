package com.ekenya.rnd.android.common.services.imageloader;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;

import javax.inject.Inject;

public class ImageLoader implements IImageLoader{

    private Context mContext;

    @Inject
    public  ImageLoader(Context context){
        mContext = context;
    }
    @Override
    public void loadImage(String urlPath, int placeholder, ImageView imageView) {

        Glide.with(mContext)
                .load(urlPath)
                .placeholder(placeholder)
                .error(placeholder)
                .into(imageView);
//        Ion.with(getContext())
//                .load(result.getIconPath())
//                .withBitmap()
//                .placeholder(R.drawable.ic_action_help)
//                .error(R.drawable.nophoto)
//                .intoImageView(ivImage);
    }

    public void loadImage(String urlPath, @Nullable Drawable placeholder, ImageView imageView){
        //
    }

    @Override
    public void loadImage(ImageView imageView, @Nullable String url, @Nullable Object payload) {
//        Picasso.with(getContext())
//                .load(basePath+"/"+url)
//                .placeholder(R.drawable.user_def)
//                .error(R.drawable.user_def)
//                .into(imageView);
    }
}
