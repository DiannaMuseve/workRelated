package com.ekenya.rnd.android.common.db.entities.users;

public class UsersTableFields {
    public static final String TABLE_NAME = "users";
    //
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USER_ID = "_uid";
    public static final String COLUMN_NAME = "_name";
    public static final String COLUMN_EMAIL = "_email";
    public static final String COLUMN_PHONE = "_phone";
    public static final String COLUMN_ROLE = "_role";
    public static final String COLUMN_AVATAR = "_avatar";
    public static final String COLUMN_CLIENT_ID = "_cid";
    public static final String COLUMN_CLIENT_SECRET = "_csec";
    public static final String COLUMN_DATE = "_date";
}
