package com.ekenya.rnd.android.common.services.alertsservice

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.graphics.drawable.IconCompat
import com.ekenya.rnd.android.common.R
import com.ekenya.rnd.android.common.models.NotificationItem
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import javax.inject.Inject

public class AlertsService
@Inject constructor(
    private val  context:Context,
    private val appDb: IAppRepo
) :IAlertsService {

    //
    private var mNotificationManager: NotificationManager? = null

    //
    private val mOreoNotification: Notification? = null

    private val OREO_NOTIFICATION_ID = 0x23

    init {
        //
        mNotificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        //
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //
            val channel = NotificationChannel(
                EclecticsQssService.NOTIFICATION_CHANNEL_ID,
                EclecticsQssService.NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            )
            //
            channel.enableVibration(true)
            channel.lightColor = Color.BLUE
            channel.enableLights(true)
            //            channel.setSound(Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" +
//                            getApplicationContext().getPackageName() + "/" + R.raw.tone),
//                    new AudioAttributes.Builder()
//                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
//                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
//                            .build());
            //
            channel.setShowBadge(true)
            //
            mNotificationManager!!.createNotificationChannel(channel)
        }
    }

    override fun postNotification(item: NotificationItem,icon:IconCompat, activity:Activity) {
        //
        //
        val intent1 = Intent(context, activity.javaClass)
        intent1.putExtra("nid", item.getId())
        val pendingIntent =
            PendingIntent.getActivity(context, 1, intent1, PendingIntent.FLAG_IMMUTABLE)

        val inboxStyle = NotificationCompat.BigTextStyle()

        //
        inboxStyle.setBigContentTitle(item.getTitle())
        inboxStyle.bigText(item.getContent())
        inboxStyle.setSummaryText(item.getCategory())
        //
        //
        val notificationBuilder: NotificationCompat.Builder = NotificationCompat.Builder(
            context,
            EclecticsQssService.NOTIFICATION_CHANNEL_ID
        )
         //Extend for wear and multi-device sync
        .extend(
            NotificationCompat.WearableExtender()
                .setDismissalId("alert-"+item.id)
                .setBridgeTag("-"+item.id)
        )
            .setLocalOnly(false)//Push to connected wearables
                //
            .setVibrate(longArrayOf(0, 100))
            .setPriority(Notification.PRIORITY_MAX)
            .setLights(Color.BLUE, 3000, 2000)
            .setAutoCancel(true)
            .setContentTitle(item.getTitle())
            .setContentIntent(pendingIntent)
            .setWhen(item.getTime().getTime())
            .setSmallIcon(icon)
            .setStyle(inboxStyle) //   .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.mipmap.ic_launcher))
            .setContentText(item.getContent())
        //
        //
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            //
            notificationBuilder.setChannelId(EclecticsQssService.NOTIFICATION_CHANNEL_ID)
        }
        //
        //
        mNotificationManager!!.notify(
            EclecticsQssService.NOTIFICATION_CHANNEL_ID,
            1,
            notificationBuilder.build()
        )
        //Store it in DB
//        BuildersKt.launch(GlobalScope.INSTANCE,
//                (CoroutineContext) Dispatchers.getMain(),//context to be ran on
//                CoroutineStart.DEFAULT,
//                (coroutineScope, continuation) -> mAppRepo.addAlert((NotificationItem) item,continuation)
//        );
    }
}