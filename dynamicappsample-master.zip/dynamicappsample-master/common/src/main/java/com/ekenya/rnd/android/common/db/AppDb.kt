package com.ekenya.rnd.android.common.db

import android.content.Context
import android.content.res.Resources
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ekenya.rnd.android.common.db.converters.Converters
import com.ekenya.rnd.android.common.db.entities.alerts.AlertsDao
import com.ekenya.rnd.android.common.db.entities.alerts.AlertsEntity
import com.ekenya.rnd.android.common.db.entities.users.UsersDao
import com.ekenya.rnd.android.common.db.entities.users.UsersEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(version = 1, entities = [UsersEntity::class, AlertsEntity::class], exportSchema = true)
@TypeConverters(Converters::class)
abstract class AppDb : RoomDatabase() {

    abstract fun usersDao(): UsersDao

    abstract fun alertsDao(): AlertsDao

    private class AppDatabaseCallback(
        private val scope: CoroutineScope,
        private val resources: Resources) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            //
            INSTANCE?.let { database ->
                scope.launch {
                    Log.i(TAG,"Coroutine launch ...")

                    prePopulateDatabase(database)
                }
            }
        }

        private suspend fun prePopulateDatabase(database: AppDb) {
            Log.i(TAG,"Pre-populating appDB ...")
//            //
//            var defUser = UsersEntity()
//            defUser.userId = "rnd@eclectics.io"
//            defUser.name = "John Doe"
//            defUser.role = "user"
//            defUser.email = "rnd@eclectics.io"
//            //
//            database.usersDao().insert(defUser)
//            //
//            Log.i(TAG,"Users count after Pre-populate "+ (database.usersDao().getAll().value?.size
//                ?: 0))

        }
    }

    companion object {
        val TAG = AppDb::class.java.simpleName

        const val DB_NAME = "mb_app_db"

        @Volatile
        private var INSTANCE: AppDb? = null
        // Makes sure no threads making the same thing at the same time
        private val LOCK = Any()

        operator fun invoke(context: Context,
                            coroutineScope: CoroutineScope,
                            resources: Resources) = INSTANCE ?: synchronized(LOCK) {
            INSTANCE ?: buildDatabase(context,coroutineScope,resources).also { INSTANCE = it }
        }

        private fun buildDatabase(
            context: Context,
            coroutineScope: CoroutineScope,
            resources: Resources): AppDb {

            val instance = Room.databaseBuilder(
                context.applicationContext,
                AppDb::class.java,
                DB_NAME
            )
                //.addMigrations( MIGRATION_1_2, MIGRATION_2_3 )
                .fallbackToDestructiveMigration()
                .addCallback(
                    AppDatabaseCallback(
                        coroutineScope,
                        resources
                    )
                )
                .build()
            INSTANCE = instance
            return instance
        }

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE `users` (`id` INTEGER, `name` TEXT, " +
                            "PRIMARY KEY(`id`))"
                )
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE Book ADD COLUMN pub_year INTEGER")
            }
        }
    }
}