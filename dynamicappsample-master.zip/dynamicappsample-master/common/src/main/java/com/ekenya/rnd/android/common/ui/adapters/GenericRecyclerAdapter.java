package com.ekenya.rnd.android.common.ui.adapters;

import android.content.Context;
import android.widget.Filter;
import android.widget.Filterable;

import java.util.ArrayList;
import java.util.List;

import androidx.recyclerview.widget.RecyclerView;

public abstract class GenericRecyclerAdapter<E> extends RecyclerView.Adapter implements Filterable
{

    public enum Orientation {
        VERTICAL,HORIZONTAL
    }

    protected List<E> mFilteredItems = new ArrayList<>();
    protected List<E> mOriginalItems = new ArrayList<>();
    protected Context mContext;
    protected CharSequence currentFilterConstraint = "";

    public GenericRecyclerAdapter(Context context)
    {
        this.mFilteredItems = this.mOriginalItems;
        this.mContext = context;
    }


    @Override
    public Filter getFilter() {
        return new Filter() {
            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                mFilteredItems = (List<E>) results.values;
                notifyDataSetChanged();
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                currentFilterConstraint = constraint;
                //
                List<E> filteredResults = null;
                if (constraint.length() == 0) {
                    filteredResults = mOriginalItems;
                } else {

                    filteredResults = getFilteredResults(constraint.toString().toLowerCase());
                }

                FilterResults results = new FilterResults();
                results.values = filteredResults;

                return results;
            }
        };
    }

    protected abstract List<E> getFilteredResults(String constraint) ;

    protected abstract boolean addItem(E item);

    protected abstract void addAll(List<E> items);
}
