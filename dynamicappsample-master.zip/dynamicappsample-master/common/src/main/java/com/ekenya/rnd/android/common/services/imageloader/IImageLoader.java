package com.ekenya.rnd.android.common.services.imageloader;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import androidx.annotation.DrawableRes;
import androidx.annotation.IdRes;
import androidx.annotation.Nullable;

public interface IImageLoader {

    void loadImage(String urlPath, @DrawableRes int placeholder, ImageView imageView);

    void loadImage(String urlPath, @Nullable Drawable placeholder, ImageView imageView);

    void loadImage(ImageView imageView, @Nullable String url, @Nullable Object payload);
}
