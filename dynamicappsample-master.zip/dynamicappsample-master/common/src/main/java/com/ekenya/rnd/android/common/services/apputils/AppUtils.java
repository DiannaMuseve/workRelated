package com.ekenya.rnd.android.common.services.apputils;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.text.format.DateFormat;
import android.text.format.DateUtils;
import android.util.DisplayMetrics;
import android.widget.Toast;

import androidx.annotation.StringRes;
import android.widget.PopupMenu;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.inject.Inject;

public class AppUtils implements IAppUtils{
    public Context context;

    @Inject
    public AppUtils(Context ctx){context = ctx;}

    public void showPopupMenuIcons(PopupMenu menu){

    }

    public  void showToast( @StringRes int text, boolean isLong) {
        showToast(context.getString(text), isLong);
    }

    public  void showToast(String text, boolean isLong) {
        Toast.makeText(context, text, isLong ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
    }


    public float convertDpToPixel(float dp) {
        return dp * ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    public float convertPixelsToDp(float px) {
        return px / ((float) context.getResources().getDisplayMetrics().densityDpi / DisplayMetrics.DENSITY_DEFAULT);
    }

    @Override
    public Date dateFromString(String dateString, String dateFormat) throws ParseException {
        //
        SimpleDateFormat mDateFormatter = new SimpleDateFormat(dateFormat);
        //
        try{
            return mDateFormatter.parse(dateString);
        } catch (ParseException e) {
            throw e;
        }
    }

    @Override
    public String formatDateAndTime(Date dateTime) {

//        if(DateUtils.isToday(dateTime.getTime())){
//            return "Today, "+new SimpleDateFormat("hh:mm a").format(dateTime);
//        }else if(DateUtils.isToday(dateTime.getTime() + DateUtils.DAY_IN_MILLIS)){
//            return "Yesterday, "+new SimpleDateFormat("hh:mm a").format(dateTime);
//        }else{
//            return new SimpleDateFormat("EEE, dd MMM yyyy hh:mm a").format(dateTime);
//        }

        Calendar smsTime = Calendar.getInstance();
        smsTime.setTimeInMillis(dateTime.getTime());

        Calendar now = Calendar.getInstance();

        final String timeFormatString = "h:mm aa";
        final String dateTimeFormatString = "EEEE, d MMMM, h:mm aa";
        //final long HOURS = 60 * 60 * 60;
        if (now.get(Calendar.DATE) == smsTime.get(Calendar.DATE) ) {
            return "Today, " + DateFormat.format(timeFormatString, smsTime);
        } else if (now.get(Calendar.DATE) - smsTime.get(Calendar.DATE) == 1  ){
            return "Yesterday, " + DateFormat.format(timeFormatString, smsTime);
        } else if (now.get(Calendar.YEAR) == smsTime.get(Calendar.YEAR)) {
            return DateFormat.format(dateTimeFormatString, smsTime).toString();
        } else {
            return DateFormat.format("dd MMMM yyyy, h:mm aa", smsTime).toString();
        }
    }

    public Bitmap drawableToBitmap(final Drawable drawable, final Context context) {

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }
}
