package com.ekenya.rnd.android.common.db.entities.users

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = UsersTableFields.TABLE_NAME,
    indices = [Index(value = [UsersTableFields.COLUMN_ID], unique = true)])
data class UsersEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = UsersTableFields.COLUMN_ID)
    var id: Int,
    @ColumnInfo(name = UsersTableFields.COLUMN_USER_ID)
    var userId: String,
    @ColumnInfo(name = UsersTableFields.COLUMN_NAME)
    var name: String,
    @ColumnInfo(name = UsersTableFields.COLUMN_EMAIL)
    var email: String,
    @ColumnInfo(name = UsersTableFields.COLUMN_PHONE)
    var phone: String,
    @ColumnInfo(name = UsersTableFields.COLUMN_ROLE)
    var role: String,
    @ColumnInfo(name = UsersTableFields.COLUMN_AVATAR)
    var avatar: String,
    @ColumnInfo(name = UsersTableFields.COLUMN_CLIENT_ID)
    var clientId: String ,
    @ColumnInfo(name = UsersTableFields.COLUMN_CLIENT_SECRET)
    var clientSecret: String ,
    @ColumnInfo(name = UsersTableFields.COLUMN_DATE)
    var date: Date
    ){
    //Empty Contractor
    constructor() : this(0,"","","","","","","","", Calendar.getInstance().time)
}