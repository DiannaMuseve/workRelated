package com.ekenya.rnd.android.common.db.entities.alerts

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.*

@Entity(tableName = AlertTableFields.TABLE_NAME,
    indices = [Index(value = [AlertTableFields.COLUMN_ID], unique = true)])
data class AlertsEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = AlertTableFields.COLUMN_ID)
    var id: Int,
    @ColumnInfo(name = AlertTableFields.COLUMN_ITEM_ID)
    var itemId: String,
    @ColumnInfo(name = AlertTableFields.COLUMN_TITLE)
    var title: String,
    @ColumnInfo(name = AlertTableFields.COLUMN_CONTENT)
    var content: String,
    @ColumnInfo(name = AlertTableFields.COLUMN_FULL_CONTENT)
    var fullContent: String,
    @ColumnInfo(name = AlertTableFields.COLUMN_SEEN)
    var seen: Boolean,
    @ColumnInfo(name = AlertTableFields.COLUMN_ICON)
    var icon: String?,
    @ColumnInfo(name = AlertTableFields.COLUMN_DATE)
    var date: Date

){
    //Empty Contractor
    constructor() : this(0,"","","","",false,null, Calendar.getInstance().time)
}