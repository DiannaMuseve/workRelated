package com.ekenya.rnd.android.common;

import java.util.concurrent.TimeUnit;

public class Constants {
    /**
     * The Base Package ID path for the application module
     *
     * The app module and all other modules should be relative to this path
     * E.G if base = 'com.ekenya.rnd', then app id would be 'com.ekenya.rnd.app', then module id, like support should be 'com.ekenya.rnd.android.support'
     */
    public static final String BASE_PACKAGE_NAME = "com.ekenya.rnd.android";
    /**
     *
     */
    public static final String CALLING_ACTIVITY = "calling-activity";
    /**
     *
     */
    public static final String ISO_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZ";//"yyyyMMdd'T'HHmmsszz";//";

    // Shared
    public static final long  CONNECTION_TIME_OUT_MS = TimeUnit.SECONDS.toMillis(5);

    public static final String  KEY_COMM_TYPE = "communicationType";

    public static final String  KEY_PAYLOAD = "payload";

    // Requests
    public static final int  COMM_TYPE_REQUEST_PROMPT_PERMISSION = 1;

    public static final int  COMM_TYPE_REQUEST_DATA = 2;

    // Responses
    public static final int  COMM_TYPE_RESPONSE_PERMISSION_REQUIRED = 1001;
    public static final int  COMM_TYPE_RESPONSE_USER_APPROVED_PERMISSION = 1002;
    public static final int  COMM_TYPE_RESPONSE_USER_DENIED_PERMISSION = 1003;
    public static final int  COMM_TYPE_RESPONSE_DATA = 1004;

    // Phone
    public static final String CAPABILITY_PHONE_APP = "phone_app_runtime_permissions";
    public static final String MESSAGE_PATH_PHONE = "/phone_message_path";

    // Wear
    public static final String CAPABILITY_WEAR_APP = "wear_app_runtime_permissions";
    public static final String  MESSAGE_PATH_WEAR = "/wear_message_path";
}
