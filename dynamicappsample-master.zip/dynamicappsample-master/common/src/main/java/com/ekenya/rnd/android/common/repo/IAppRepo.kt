package com.ekenya.rnd.android.common.repo

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.ekenya.rnd.android.common.models.NotificationItem
import com.ekenya.rnd.android.common.models.UserAccount
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.qss.beans.SsNotification

public interface IAppRepo {
    fun getService(): MutableLiveData<EclecticsQssService>
    //
    fun getUser(userId:String) :UserAccount
    suspend fun addUser(user:UserAccount)
    suspend fun deleteUser(user:UserAccount)
    fun getUsers() :LiveData<List<UserAccount>>
    //
    fun getAllAlerts(): LiveData<List<out SsNotification>>
    fun getAlert(id: Int): NotificationItem
    fun getAlert(id: String): NotificationItem
    suspend fun updateAlert(alert: NotificationItem)
    suspend fun addAlert(alert: NotificationItem)
    suspend fun deleteAlert(alert: NotificationItem)
}
