package com.ekenya.rnd.android.common.models;

import android.graphics.drawable.Drawable;

import java.io.Serializable;


/**
 * Created by Bourne Koloh on 08 October,2018.
 * Eclectics International, Products and R&D
 * PROJECT: EasyRent
 */
public class SearchAutocompleteItem implements Serializable {
    private int id;
    private String title = "";
    private String subTitle;
    private String iconPath;
    public SearchAutocompleteItem(){}
    public SearchAutocompleteItem(String title){
        this.title = title;
    }
    public SearchAutocompleteItem(int id,String title){
        this.title = title;
        this.id = id;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public String getIconPath() {
        return iconPath;
    }

    public void setIconPath(String iconPath) {
        this.iconPath = iconPath;
    }

    @Override
    public String toString(){
        return this.title;
    }
}
