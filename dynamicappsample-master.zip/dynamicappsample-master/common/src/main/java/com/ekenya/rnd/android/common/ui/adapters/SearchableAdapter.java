package com.ekenya.rnd.android.common.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;


import com.ekenya.rnd.android.common.R;
import com.ekenya.rnd.android.common.services.imageloader.IImageLoader;
import com.ekenya.rnd.android.common.models.SearchAutocompleteItem;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

/**
 * Created by Bourne Koloh on 08 October,2018.
 * Eclectics International, Products and R&D
 * PROJECT: EasyRent
 */
public class SearchableAdapter extends ArrayAdapter<SearchAutocompleteItem> {

    @Inject
    public IImageLoader mImageLoader;

    List<SearchAutocompleteItem> results, tempResult, suggestions;

    public SearchableAdapter(Context context, List<SearchAutocompleteItem> objects) {
        super(context, android.R.layout.simple_list_item_1, objects);
        this.results = objects;
        this.tempResult = new ArrayList<SearchAutocompleteItem>(objects);
        this.suggestions = new ArrayList<SearchAutocompleteItem>(objects);

    }
    public List<SearchAutocompleteItem> getEntries(){
        return results;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SearchAutocompleteItem result = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.search_row_item, parent, false);
        }
        TextView txtTitle = convertView.findViewById(R.id.tvTitle);
        TextView txtSubTitle = convertView.findViewById(R.id.tvSubTitle);
        ImageView ivImage = convertView.findViewById(R.id.ivItemImage);
        ImageView ivGo = convertView.findViewById(R.id.iv_go);

        // Now assign alternate color for rows

        txtTitle.setText(result.getTitle());
        if (result.getIconPath()!= null) {
            //
            mImageLoader.loadImage(result.getIconPath(),R.drawable.logo_sm,ivImage);
        }else{
            ivImage.setVisibility(View.INVISIBLE);
        }
        //
        if(result.getSubTitle() != null){
            txtSubTitle.setText(result.getSubTitle());
            txtSubTitle.setVisibility(View.VISIBLE);
        }else{
            txtSubTitle.setVisibility(View.GONE);
        }
        return convertView;
    }


    @Override
    public Filter getFilter() {
        return myFilter;
    }

    Filter myFilter = new Filter() {
        @Override
        public CharSequence convertResultToString(Object resultValue) {
            SearchAutocompleteItem item = (SearchAutocompleteItem) resultValue;
            return item.getTitle();
        }

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            if (constraint != null) {
                suggestions.clear();
                for (SearchAutocompleteItem item: tempResult) {
                    if (item.getTitle().toLowerCase().startsWith(constraint.toString().toLowerCase()) ||( item.getSubTitle() != null &&
                            item.getSubTitle().toLowerCase().startsWith(constraint.toString().toLowerCase()))) {
                        //
                        suggestions.add(item);
                    }
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = suggestions;
                filterResults.count = suggestions.size();
                return filterResults;
            } else {
                return new FilterResults();
            }
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            ArrayList<SearchAutocompleteItem> c = (ArrayList<SearchAutocompleteItem>) results.values;
            if (results != null && results.count > 0) {
                clear();
                for (SearchAutocompleteItem cust: c) {
                    add(cust);
                    notifyDataSetChanged();
                }
            }
        }
    };
}
