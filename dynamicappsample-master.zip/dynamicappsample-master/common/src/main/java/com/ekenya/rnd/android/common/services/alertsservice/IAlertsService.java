package com.ekenya.rnd.android.common.services.alertsservice;

import android.app.Activity;

import androidx.core.graphics.drawable.IconCompat;

import com.ekenya.rnd.android.common.abstractions.BaseActivity;
import com.ekenya.rnd.android.common.models.NotificationItem;

public interface IAlertsService {

    void postNotification(NotificationItem alert, IconCompat icon, Activity pendingIntentActivity);
}
