package com.ekenya.rnd.android.common.services.qssservice;

import static com.ekenya.rnd.android.qss.QSSClientService.EXTRA_QSS_SERVICE_BINDER;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.ResultReceiver;
import android.util.Log;

import com.ekenya.rnd.android.qss.QssServiceResultReceiver;
import com.ekenya.rnd.android.qss.QssWakeReceiver;

/**
 * Created by Bourne Koloh on 29 November,2019.
 * Eclectics International, Products and R&D
 * PROJECT: Qss Sample
 */
public class WakeReceiver extends QssWakeReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        //
        Log.i(TAG,"Received intent action => "+intent.getAction());
        //ResultReceiver receiver = intent.getParcelableExtra(EXTRA_QSS_SERVICE_BINDER);
        if(mBinder != null){
            intent.putExtra(EXTRA_QSS_SERVICE_BINDER,mBinder);
        }
        //Enqueue Work
        EclecticsQssService.enqueueWork(context, intent);

//        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
//            //
//            //context.startService(new Intent(context, EclecticsQssService.class));
//        }else{
//            super.onReceive(context,intent);
//        }
    }


    public static void cancelQssWakeAlarm(Context ctx) {
        AlarmManager alarm = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);

        /* cancel any pending alarm */
        assert alarm != null;
        alarm.cancel(getPendingIntent(ctx));
    }

    public static void setQssWakeAlarm(boolean force, Context ctx, QssServiceResultReceiver binder) {
        if(binder != null) {
            mBinder = binder;
        }
        cancelQssWakeAlarm(ctx);
        Log.i(TAG,"Qss Wake Alarm Started");
        AlarmManager alarm = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        // EVERY 2 MINUTES
        long delay = (1000 * 60 * 2);
        long when = System.currentTimeMillis();
        if (!force) {
            when += delay;
        }

        /* fire the broadcast */
        int SDK_INT = Build.VERSION.SDK_INT;
        if (SDK_INT < Build.VERSION_CODES.KITKAT) {
            assert alarm != null;
            alarm.set(AlarmManager.RTC_WAKEUP, when, getPendingIntent(ctx));
        } else if (SDK_INT < Build.VERSION_CODES.M) {
            assert alarm != null;
            alarm.setExact(AlarmManager.RTC_WAKEUP, when, getPendingIntent(ctx));
        } else {
            assert alarm != null;
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, getPendingIntent(ctx));
        }
    }

    private static PendingIntent getPendingIntent(Context ctx) {
        Intent alarmIntent = new Intent(ctx, WakeReceiver.class);
       // alarmIntent.putExtra(EXTRA_QSS_SERVICE_BINDER, mBinder);
        alarmIntent.setAction(CUSTOM_INTENT);

        PendingIntent intent = PendingIntent.getBroadcast(ctx, 0, alarmIntent, PendingIntent.FLAG_IMMUTABLE);

        Log.i(TAG,"Alarm Pending Intent => ["+intent+"]");
        return intent;
    }
}
