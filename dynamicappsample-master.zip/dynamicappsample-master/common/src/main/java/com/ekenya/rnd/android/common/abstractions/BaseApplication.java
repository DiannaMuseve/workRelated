package com.ekenya.rnd.android.common.abstractions;

import android.util.Log;

import com.google.android.play.core.splitcompat.SplitCompatApplication;

import io.reactivex.functions.Consumer;
import io.reactivex.plugins.RxJavaPlugins;

/**
 * Created by Bourne Koloh on 17 March,2021.
 * Eclectics International, Products and R&D
 * PROJECT: Dynamic Modules Sample
 */
public abstract class BaseApplication extends SplitCompatApplication {
    private static final String TAG = "BaseApplication";
    @Override
    public void onCreate() {
        super.onCreate();
        //Global RXJava Error Handler
        RxJavaPlugins.setErrorHandler(new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                Log.e(TAG, "Unhandled Error => "+throwable.getMessage());
            }
        });
    }
}
