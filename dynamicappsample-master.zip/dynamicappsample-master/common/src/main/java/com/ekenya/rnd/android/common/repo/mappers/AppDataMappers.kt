package com.ekenya.rnd.android.common.repo.mappers

import android.util.Base64
import com.ekenya.rnd.android.common.db.entities.alerts.AlertsEntity
import com.ekenya.rnd.android.common.db.entities.users.UsersEntity
import com.ekenya.rnd.android.common.models.NotificationItem
import com.ekenya.rnd.android.common.models.UserAccount

public class AppDataMappers {

    companion object{

        fun mapUsers(from:List<UsersEntity>) : List<UserAccount>{
            var list = ArrayList<UserAccount>()
            for(u in from){
                list.add(createFrom(u))
            }
            return list
        }

        fun createFrom(from:UsersEntity) : UserAccount{
            var user = UserAccount(from.userId,from.name,from.email,from.phone,from.avatar, from.role)
            user.qssClientId = from.clientId
            user.qssClientSecret = from.clientSecret
            return user
        }


        fun convertTo(user: UserAccount): UsersEntity {

            val entity = UsersEntity()
            entity.userId = user.id
            entity.email = user.email
            //
            entity.avatar = user.photo
            //
            entity.name = user.name
            //
            entity.role = user.role
            //
            entity.clientId = user.qssClientId
            entity.clientSecret = user.qssClientSecret

//            alert.Photo.let {bitmap: Bitmap? ->
//                val byteArrayOutputStream = ByteArrayOutputStream()
//                bitmap?.compress(
//                    Bitmap.CompressFormat.PNG,
//                    100,
//                    byteArrayOutputStream
//                )
//                //
//                entity.icon = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);
//            }

            return entity
        }

        //ALERTS

        fun createFrom(from:List<AlertsEntity>) : List<NotificationItem>{
            var list = ArrayList<NotificationItem>()
            for(u in from){
                list.add(createFrom(u))
            }
            return list
        }

        fun createFrom(entity: AlertsEntity): NotificationItem {

            val alert = NotificationItem()
            alert.id = entity.itemId
            alert.title = entity.title
            //
            alert.content = entity.content
            //
            //alert.expandedContent = entity.fullContent
            //
            alert.time = entity.date
            //alert.seen = entity.seen

            entity.icon?.let {encodedImage:String? ->
                val decodedString: ByteArray = Base64.decode(encodedImage, Base64.DEFAULT)
                //alert.photo = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
            }

            return alert
        }

        fun convertTo(alert: NotificationItem): AlertsEntity {

            val entity = AlertsEntity()
            entity.itemId = alert.id
            entity.title = alert.title
            //
            entity.content = alert.content
            //
            //entity.fullContent = alert.expandedContent
            //
            //entity.seen = alert.seen

//            alert.Photo.let {bitmap: Bitmap? ->
//                val byteArrayOutputStream = ByteArrayOutputStream()
//                bitmap?.compress(
//                    Bitmap.CompressFormat.PNG,
//                    100,
//                    byteArrayOutputStream
//                )
//                //
//                entity.icon = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);
//            }

            return entity
        }
    }
}