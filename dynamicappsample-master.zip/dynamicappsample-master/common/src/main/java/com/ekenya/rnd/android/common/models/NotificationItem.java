package com.ekenya.rnd.android.common.models;

import com.ekenya.rnd.android.qss.beans.SsNotification;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Calendar;
import java.util.Date;


/**
 * Created by Bourne Koloh on 11 October,2019.
 * Eclectics International, Products and R&D
 * PROJECT: Qss Sample
 */
public class NotificationItem extends SsNotification {

    @SerializedName("id")
    private String id;
    @SerializedName("title")
    private String title;
    @SerializedName("content")
    private String content;
    @SerializedName("category")
    private String category;
    @SerializedName("time")
    private Date time;
    @SerializedName("origin")
    private String senderId;
    @SerializedName("photo")
    private String photoPath;

    @Expose(serialize = false)
    private boolean seen = false;

    public NotificationItem(){
        time = Calendar.getInstance().getTime();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public String getCategory() {
        return category == null ? "" : category;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCollapseId() {
        return category;
    }

    public void setCollapseId(String category) {
        this.category = category;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }

    public boolean isSeen() {
        return seen;
    }

    public void setSeen(boolean seen) {
        this.seen = seen;
    }

    public class NotificationResponse{
        @SerializedName("title")
        public String title;
        @SerializedName("content")
        public String content;
        @SerializedName("category")
        public String category;
        @SerializedName("id")
        public String id;
        @SerializedName("time")
        public String time;
        @SerializedName("photo")
        public String photo;
    }
}
