package com.ekenya.rnd.android.common.db.converters

import androidx.room.TypeConverter
import java.util.*


/**
 * Created by Bourne Koloh on 03 July,2020.
 * Eclectics International, Products and R&D
 * PROJECT: Lending Manager
 */
object DateConverter {
    @TypeConverter
    @JvmStatic
    fun calendarFromTimestamp(value: String?): Calendar? {
        if (value == null) {
            return null
        }
        val cal: Calendar = GregorianCalendar()
        cal.setTimeInMillis(value.toLong() * 1000)
        return cal
    }

    @TypeConverter
    @JvmStatic
    fun dateToTimestamp(cal: Calendar?): String? {
        return if (cal == null) {
            null
        } else "" + cal.getTimeInMillis() / 1000
    }
}
