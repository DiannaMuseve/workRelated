package com.ekenya.rnd.android.common.services.qssservice;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import androidx.core.app.JobIntentService;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.drawable.IconCompat;
import androidx.lifecycle.LiveDataReactiveStreams;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import com.ekenya.rnd.android.common.R;
import com.ekenya.rnd.android.common.abstractions.BaseActivity;
import com.ekenya.rnd.android.common.models.NotificationItem;
import com.ekenya.rnd.android.common.models.UserAccount;
import com.ekenya.rnd.android.common.repo.IAppRepo;
import com.ekenya.rnd.android.common.services.alertsservice.IAlertsService;
import com.ekenya.rnd.android.qss.QSSClientService;
import com.ekenya.rnd.android.qss.QssServiceResultReceiver;
import com.ekenya.rnd.android.qss.beans.QssEvents;
import com.ekenya.rnd.android.qss.beans.QssGroup;
import com.ekenya.rnd.android.qss.beans.QssUser;
import com.ekenya.rnd.android.qss.beans.SsData;
import com.ekenya.rnd.android.qss.beans.SsNotification;
import com.ekenya.rnd.logginglib.core.ILoggingService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.reactivestreams.Publisher;
import org.reactivestreams.Subscription;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.android.AndroidInjection;
import io.reactivex.Flowable;
import io.reactivex.FlowableSubscriber;
import io.reactivex.Observable;
import io.reactivex.Single;
import io.reactivex.SingleEmitter;
import io.reactivex.SingleOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.PublishSubject;

public class EclecticsQssService extends QSSClientService {

    private static final String TAG = EclecticsQssService.class.getSimpleName();

    public static final String NOTIFICATION_CHANNEL_ID = "com.ekenya.rnd.chat.notifications";
    public static final String NOTIFICATION_CHANNEL_NAME = "QSS Alerts";

    private QssUser mCurrentUser;

    private MutableLiveData<List<QssGroup>> mGroups = new MutableLiveData<List<QssGroup>>();

    public MutableLiveData<List<QssGroup>> getGroups() {
        if(mGroups.getValue() == null){
            mGroups.setValue(new ArrayList<>());
        }
        return mGroups;
    }

    public MutableLiveData<List<QssUser>> getOnlineUsers() {
        if(mOnlineUsers.getValue() == null){
            mOnlineUsers.setValue(new ArrayList<>());
        }
        return mOnlineUsers;
    }

    private MutableLiveData<List<QssUser>> mOnlineUsers = new MutableLiveData<List<QssUser>>();

    private PublishSubject<QssUser> userOnlineObserver;
    private PublishSubject<QssUser> userOfflineObserver;

    public Activity mAlertEntryActivity;

    @Inject
    public IAppRepo mAppRepo;
    @Inject
    public IAlertsService mAlertsService;
    @Inject
    public Gson mGson;
    @Inject
    public ILoggingService loggerService;
    @Override
    public void onCreate() {
        AndroidInjection.inject(this);
        super.onCreate();
        mGroups.setValue(new ArrayList<QssGroup>());
        userOnlineObserver = PublishSubject.create();
        userOfflineObserver = PublishSubject.create();
        //
        ComponentName receiver = new ComponentName(this, WakeReceiver.class);
        this.getPackageManager().setComponentEnabledSetting(receiver, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);

        //
        LiveDataReactiveStreams.toPublisher(EclecticsQssService.this,mAppRepo.getUsers())
                .subscribe(new FlowableSubscriber<List<UserAccount>>() {
                    @Override
                    public void onSubscribe(Subscription s) {

                    }

                    @Override
                    public void onNext(List<UserAccount> userAccounts) {
                        if(userAccounts.isEmpty()){
                            return;
                        }
                        //
                        UserAccount account = userAccounts.get(0);
                        mCurrentUser = new QssUser();
                        //Load from secure config ..
                        mCurrentUser.setClientId(account.getQssClientId());
                        mCurrentUser.setClientSecret(account.getQssClientSecret());
                        //
                        mCurrentUser.setId(account.getId());
                        mCurrentUser.setName(account.getName());
                        mCurrentUser.setPhoto(account.getPhoto());
                    }

                    @Override
                    public void onError(Throwable t) {

                    }

                    @Override
                    public void onComplete() {

                    }
                });
        //
        enrollForEvents();
        //Override fault value with user configured value
        mServiceHost = mSharedPreferences.getString(KEY_SERVICE_URL,mServiceHost);
        //mServiceHost = "http://192.168.20.106:5000";
    }
//    @Override
//    public int onStartCommand(Intent startIntent, int flags, int startId) {
//        super.onStartCommand(startIntent, flags, startId);
//        try {
//            String className = startIntent.getStringExtra(CALLING_ACTIVITY);
//            mAlertEntryActivity = (Class<? extends BaseActivity>) Class.forName(className).asSubclass(Activity.class);
//        } catch (ClassNotFoundException e) {
//            Log.e(TAG, "Notification action class not specified in service launcher intent", e);
//            stopSelf();
//        }
//        //
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            Intent notificationIntent = new Intent(this, mAlertEntryActivity);
//            PendingIntent pendingIntent = PendingIntent.getActivity(this,
//                    0, notificationIntent, 0);
//            mOreoNotification = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
//                    .setContentTitle(getResources().getString(R.string.app_name))
//                    .setContentText("Eclectics notifications service is running in the background")
//                    .setSmallIcon(R.drawable.ic_alert)
//                    .setContentIntent(pendingIntent)
//                    .setAutoCancel(true)
//                    .setOngoing(false)
//                    .setPriority(0)
//                    .setSilent(true)
//                    .build();
//            //
//            startForeground(OREO_NOTIFICATION_ID, mOreoNotification);
//            //
//            new Handler(getMainLooper()).postDelayed(new Runnable() {
//                @Override
//                public void run() {
//                    mNotificationManager.cancel(OREO_NOTIFICATION_ID);
//                }
//            }, 5000);
//        }
//        //
//        return START_NOT_STICKY;
//    }

    public PublishSubject<QssUser> getUserOnlineObserver() {
        return userOnlineObserver;
    }

    public PublishSubject<QssUser> getUserOfflineObserver() {
        return userOfflineObserver;
    }


    @Override
    protected void postNotification(SsNotification item){
        Log.i(TAG,"Posting Notification...");
        IconCompat icon = IconCompat.createWithResource(this,R.drawable.ic_alert);
        //
        mAlertsService.postNotification((NotificationItem) item,icon, mAlertEntryActivity);

    }

    @Override
    public void onHandleWork(Intent intent) {
        super.onHandleWork(intent);
        //
        if(mBaseQssServiceBinder == null){
            //
            mBaseQssServiceBinder = intent.getParcelableExtra(EXTRA_QSS_SERVICE_BINDER);
        }
        //
        try {
            Bundle bundle = new Bundle();
            bundle.putBinder(EXTRA_QSS_SERVICE_BINDER, mInstance.mBinder);
            mBaseQssServiceBinder.send(QSS_BIND_RESULT, bundle);
        }catch (Exception e){
            e.printStackTrace();
        }
        //
        WakeReceiver.setQssWakeAlarm(false,this,null);
    }

    @Override
    protected Class<? extends SsNotification> getNotificationClass() {
        return NotificationItem.class;
    }

    public static void enqueueWork(Context ctx, Intent intent) {
        QssServiceResultReceiver binder = intent.getParcelableExtra(EXTRA_QSS_SERVICE_BINDER);
        if(mInstance != null && mInstance.mBaseQssServiceBinder != null){
            Bundle bundle = new Bundle();
            bundle.putBinder(EXTRA_QSS_SERVICE_BINDER, mInstance.mBinder);
            binder.send(QSS_BIND_RESULT, bundle);
        }else {
            JobIntentService.enqueueWork(ctx, EclecticsQssService.class, QSS_JOB_ID, intent);
        }
    }

    @Override
    protected Single<QssUser> getCurrentUser() {
        //
        return  Single.create(new SingleOnSubscribe<QssUser>() {
            @Override
            public void subscribe(SingleEmitter<QssUser> emitter) throws Exception {

                if(mCurrentUser == null){
                    //
                    Observable<List<UserAccount>> flowable = Observable.
                            fromPublisher(LiveDataReactiveStreams.toPublisher(EclecticsQssService.this,
                                    mAppRepo.getUsers()));
                    List<UserAccount> userAccounts = flowable.blockingFirst();
                    UserAccount account = userAccounts.get(0);
                    mCurrentUser = new QssUser();
                    //Load from secure config ..
                    mCurrentUser.setClientId(account.getQssClientId());
                    mCurrentUser.setClientSecret(account.getQssClientSecret());
                    //
                    mCurrentUser.setId(account.getId());
                    mCurrentUser.setName(account.getName());
                    mCurrentUser.setPhoto(account.getPhoto());
                    //
                    emitter.onSuccess(mCurrentUser);
                    return;
                }
                //
                emitter.onSuccess(mCurrentUser);
            }
        });
    }

    private void enrollForEvents(){
        Log.i(TAG,"Enrolling for QSS Global Events ... ");
        //
        subscribeForData()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.from(this.getMainLooper()))
                .subscribe(new Consumer<SsData>() {
                    @Override
                    public void accept(SsData data) throws Exception {

                        Log.i(TAG,"Received Data => "+mGson.toJson(data));

                        switch (data.action){
                            //
                            case QssEvents.OnlineUsers : {
                                //
                                Log.i(TAG, "Online Users => " + data.getData());
                                List<QssUser>  users = mGson.fromJson(
                                        data.getData(),new TypeToken<List<QssUser>>() {}.getType() );
                                //
                                mOnlineUsers.postValue(users);
                            }
                            break;
                            //
                            case QssEvents.UserOnline : {
                                //
                                Log.i(TAG, "New User has Joined => " + data.getData());
                                QssUser user  = mGson.fromJson( data.getData(), QssUser.class );
                                //
                                userOnlineObserver.onNext(user);
                                List<QssUser> curList  = mOnlineUsers.getValue();
                                //
                                if (curList != null) {
                                    boolean d = false;
                                    for (QssUser h : curList) {
                                        if (h.getId().equalsIgnoreCase(user.getId())) {
                                            //h.setOnline(true);
                                            d = true;
                                            break;
                                        }
                                    }
                                    if (!d)
                                        curList.add(user);
                                } else {
                                    curList = new ArrayList<QssUser>();
                                    curList.add(user);
                                }
                                //
                                mOnlineUsers.postValue(curList);
                            }
                            break;
                            //
                            case QssEvents.UserOffline : {
                                //
                                Log.i(TAG, "User has Left => " + data.getData());
                                QssUser usr  = mGson.fromJson(data.getData(), QssUser.class);
                                //
                                userOfflineObserver.onNext(usr);
                                //
                                List<QssUser> ll = mOnlineUsers.getValue();
                                if (ll != null) {
                                    int index = -1;
                                    for (QssUser h : ll) {
                                        index++;
                                        if (h.getId().equalsIgnoreCase(usr.getId())) {
                                            //h.setOnline(false);
                                            break;
                                        }
                                    }
//                                    if (index != -1)
//                                        ll.removeAt(index)
                                    //
                                    mOnlineUsers.postValue(ll);
                                }
                            }
                            break;
                            //
                            case QssEvents.UserGroups : {
                                Log.i(TAG, "Users Groups => " + data.getData());
                                List<QssGroup> groups  = mGson.fromJson( data.getData(), new TypeToken<List<QssGroup>> () {}.getType()
                                );
//                        for (QssGroup g : groups) {
//                            g.setType(QssGroup.GroupType.GROUPED);
//                        }
                                //
                                mGroups.postValue(groups);
                            }
                            break;
                            //
                            case QssEvents.NewGroup : {
                                //
                                Log.i(TAG, "User New Group => " + data.getData());
                                QssGroup group  = mGson.fromJson(data.getData(), QssGroup.class);
                                //group.setType(ChatGroup.GroupType.GROUPED);
                                List<QssGroup> groups = mGroups.getValue();
                                if (groups != null) {
                                    groups.add(group);
                                } else {
                                    groups = new ArrayList<QssGroup>();
                                }
                                //
                                mGroups.postValue(groups);
                            }
                            break;
                            //
                            case QssEvents.GroupRemoved : {
                                //
                                Log.i(TAG, "User Group Removed => " + data.getData());
                                QssGroup grp = mGson.fromJson(data.getData(), QssGroup.class);
                                List<QssGroup> groups = mGroups.getValue();
                                if (groups != null) {
                                    int index = -1;
                                    for (QssGroup h : groups) {
                                        index++;
                                        if (h.getId().equalsIgnoreCase(grp.getId())) {
                                            break;
                                        }
                                    }

                                    if (index != -1)
                                        groups.remove(index);
                                    //
                                    mGroups.postValue(groups);
                                }
                            }
                            break;
                        }
                    }
                });
    }
}
