package com.ekenya.rnd.android.common.db.entities.users

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface UsersDao {

    @Delete
    suspend fun delete(user: UsersEntity)

    @Update
    suspend fun update(user: UsersEntity)

    @Query("SELECT * FROM "+ UsersTableFields.TABLE_NAME+" WHERE "+ UsersTableFields.COLUMN_ID+" = :id")
    fun getById(id: Int): UsersEntity

    @Query("SELECT * FROM "+ UsersTableFields.TABLE_NAME+" WHERE "+ UsersTableFields.COLUMN_USER_ID+" = :userId")
    fun getById(userId: String): UsersEntity

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(users: List<UsersEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(user: UsersEntity)

    @Query("SELECT * FROM "+ UsersTableFields.TABLE_NAME+" ORDER BY "+ UsersTableFields.COLUMN_DATE+" DESC")
    fun getAll(): LiveData<List<UsersEntity>>
}