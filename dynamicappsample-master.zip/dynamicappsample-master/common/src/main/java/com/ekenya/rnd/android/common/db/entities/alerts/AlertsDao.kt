package com.ekenya.rnd.android.common.db.entities.alerts

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface AlertsDao {

    @Delete
    suspend fun delete(alert: AlertsEntity)

    @Update
    suspend fun update(alert: AlertsEntity)

    @Query("SELECT * FROM "+ AlertTableFields.TABLE_NAME +" WHERE "+ AlertTableFields.COLUMN_ID +" = :id")
    fun getById(id: Int): AlertsEntity

    @Query("SELECT * FROM "+ AlertTableFields.TABLE_NAME +" WHERE "+ AlertTableFields.COLUMN_ITEM_ID +" = :alertId")
    fun getById(alertId: String): AlertsEntity

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(alerts: List<AlertsEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAlert(alert: AlertsEntity)

    @Query("SELECT * FROM "+ AlertTableFields.TABLE_NAME+" ORDER BY "+ AlertTableFields.COLUMN_DATE+" DESC")
    fun getAll(): LiveData<List<AlertsEntity>>
}