package com.ekenya.rnd.android.common.services.apputils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.widget.PopupMenu;

import androidx.annotation.StringRes;

import java.text.ParseException;
import java.util.Date;

public interface IAppUtils {
    void showPopupMenuIcons(PopupMenu menu);

    void showToast(@StringRes int text, boolean isLong);

    void showToast(String text, boolean isLong);

    float convertDpToPixel(float dp);

    float convertPixelsToDp(float px);

    Date dateFromString(String dateString, String dateFormat) throws ParseException;

    String formatDateAndTime(Date dateTime);

    Bitmap drawableToBitmap(final Drawable drawable, final Context context);
}
