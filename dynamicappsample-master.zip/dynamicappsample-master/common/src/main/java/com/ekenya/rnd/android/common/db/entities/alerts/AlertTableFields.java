package com.ekenya.rnd.android.common.db.entities.alerts;

public class AlertTableFields {
    public static final String TABLE_NAME = "alerts_table";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_ITEM_ID = "item_id";
    public static final String COLUMN_TITLE = "_title";
    public static final String COLUMN_CONTENT = "_content";
    public static final String COLUMN_FULL_CONTENT = "_fcontent";
    public static final String COLUMN_SEEN = "_seen";
    public static final String COLUMN_ICON = "_photo";
    public static final String COLUMN_DATE = "_date";
}
