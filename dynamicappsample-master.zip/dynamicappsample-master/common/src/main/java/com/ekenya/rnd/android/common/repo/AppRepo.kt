package com.ekenya.rnd.android.common.repo;

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import com.ekenya.rnd.android.common.db.AppDb
import com.ekenya.rnd.android.common.models.NotificationItem
import com.ekenya.rnd.android.common.models.UserAccount
import com.ekenya.rnd.android.common.repo.mappers.AppDataMappers
import com.ekenya.rnd.android.common.services.qssservice.EclecticsQssService
import com.ekenya.rnd.android.qss.beans.SsNotification
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

class AppRepo @Inject constructor(
    private val appDb: AppDb,
    private var context:Context
) : IAppRepo {
    //
    private var _service = MutableLiveData<EclecticsQssService>()
    //Alerts
    private val  alertsLiveCache = MediatorLiveData<List<out SsNotification>>()
    val alertsCache: LiveData<List<out SsNotification>> get() = alertsLiveCache

    private val  usersLiveCache = MediatorLiveData<List<UserAccount>>()

    init {

        //Alerts Remote Repo
        _service.observeForever{
            it.subscribeForNotifications()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe{data ->
                    //POST NOTIFICATIONS
                    alertsLiveCache.postValue(listOf(data))
                    //Insert
                    CoroutineScope(Dispatchers.IO).launch {
                        //
                        appDb.alertsDao()
                            .insertAlert(AppDataMappers.convertTo(data as NotificationItem))
                    }
                }
        }
        //Alerts Local Repo
        alertsLiveCache.addSource(appDb.alertsDao().getAll()) {
            //
            alertsLiveCache.postValue(AppDataMappers.createFrom(it))
        }
        //Users Local Repo
        usersLiveCache.addSource(appDb.usersDao().getAll()){
            //
            usersLiveCache.postValue(AppDataMappers.mapUsers(it))
        }
    }
    override fun getService(): MutableLiveData<EclecticsQssService> {
        return _service
    }

    override fun getUser(userId: String): UserAccount {
        //
        return AppDataMappers.createFrom(appDb.usersDao().getById(userId))
    }

    override suspend fun addUser(user: UserAccount) {
        //
        appDb.usersDao().insert(AppDataMappers.convertTo(user))
    }

    override suspend fun deleteUser(user: UserAccount) {
        //
        appDb.usersDao().delete(AppDataMappers.convertTo(user))
    }

    override fun getUsers()  = usersLiveCache

    //ALERTS

    override fun getAllAlerts(): LiveData<List<out SsNotification>>  = alertsCache

    override fun getAlert(id: Int): NotificationItem {
        //
        return AppDataMappers.createFrom(appDb.alertsDao().getById(id))
    }

    override fun getAlert(itemId: String): NotificationItem {
        //
        return AppDataMappers.createFrom(appDb.alertsDao().getById(itemId))
    }

    override suspend fun updateAlert(alert: NotificationItem) {
        var entity = AppDataMappers.convertTo(alert)
        //
        appDb.alertsDao().update(entity)
    }

    override suspend fun addAlert(alert: NotificationItem) {
        //
        if(appDb.alertsDao().getById(alert.id) == null) {
            var entity = AppDataMappers.convertTo(alert)
            appDb.alertsDao().insertAlert(entity)
        }
    }

    override suspend fun deleteAlert(alert: NotificationItem) {
        var entity = AppDataMappers.convertTo(alert)
        appDb.alertsDao().delete(entity)
    }

}
