package com.ekenya.rnd.android.common.db.converters

import androidx.room.TypeConverter
import java.util.*


/**
 * Created by Bourne Koloh on 03 July,2020.
 * Eclectics International, Products and R&D
 * PROJECT: Lending Manager
 */

object Converters {
    @TypeConverter
    @JvmStatic
    fun fromTimestamp(value: Long): Date {
        return Date(value)
    }

    @TypeConverter
    @JvmStatic
    fun dateToTimestamp(date: Date): Long? {
        return date.time.toLong()
    }
}