package com.ekenya.rnd.android.auth.di


import com.ekenya.rnd.android.auth.di.injectables.AuthFragmentModule
import com.ekenya.rnd.android.mobile.di.AppComponent
import com.ekenya.rnd.android.mobile.di.ModuleScope
import com.ekenya.rnd.android.mobile.di.injectables.ViewModelModule
import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule

@ModuleScope
@Component(
    dependencies = [
        AppComponent::class
    ],
    modules = [
        AndroidSupportInjectionModule::class,
        AuthFragmentModule::class,
        ViewModelModule::class
    ]
)
interface AuthComponent {
    fun inject(injector: AuthInjector)
}