package com.ekenya.rnd.android.auth.di.injectables

import dagger.Module

@Module
abstract class AuthActivityModule {
}