package com.ekenya.rnd.android.auth.ui

import android.app.Activity
import android.app.Dialog
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.annotation.Keep
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProviders
import com.ekenya.rnd.android.auth.databinding.AuthLoginFragmentBinding
import com.ekenya.rnd.android.common.abstractions.BaseBottomSheetDialogFragment
import com.ekenya.rnd.android.common.models.UserAccount
import com.ekenya.rnd.android.common.repo.IAppRepo
import com.ekenya.rnd.android.mobile.DemoApplication
import com.ekenya.rnd.android.mobile.di.helpers.activities.ActivityHelperKt
import com.ekenya.rnd.android.mobile.di.helpers.activities.AddressableActivity
import com.ekenya.rnd.android.mobile.di.helpers.features.FeatureModule
import com.ekenya.rnd.android.mobile.di.helpers.features.Modules
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.splitcompat.SplitCompat
import com.google.android.play.core.splitinstall.SplitInstallManager
import com.google.android.play.core.splitinstall.SplitInstallManagerFactory
import com.google.android.play.core.splitinstall.SplitInstallRequest
import com.google.android.play.core.splitinstall.SplitInstallStateUpdatedListener
import com.google.android.play.core.splitinstall.model.SplitInstallSessionStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import javax.inject.Inject

@Keep
class LoginDialogFragment : BaseBottomSheetDialogFragment() {
    private val TAG = LoginDialogFragment::class.java.simpleName

    private lateinit var binding: AuthLoginFragmentBinding
    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory
    @Inject
    lateinit var mAppRepo:IAppRepo

    private lateinit var mRootView:View

    private lateinit var progressDialog:ProgressDialog

    private val viewModel by lazy {
        ViewModelProviders.of(this, viewModelFactory).get(LoginViewModel::class.java)
    }


    private val homeModule by lazy {
        Modules.FeatureHome.INSTANCE
    }

    private val splitInstallManager: SplitInstallManager by lazy {
        SplitInstallManagerFactory.create(requireActivity())
    }

    private val listener = SplitInstallStateUpdatedListener { state ->
        when (state.status()) {
            SplitInstallSessionStatus.DOWNLOADING -> {
                progressDialog.setMessage("DOWNLOADING ...")
            }
            SplitInstallSessionStatus.INSTALLING -> {
                progressDialog.setMessage("INSTALLING ...")
            }
            SplitInstallSessionStatus.INSTALLED -> {

                // Enable module immediately
                SplitCompat.install(requireActivity())

                progressDialog.isIndeterminate = false

                showFeatureModule(homeModule)
            }
            SplitInstallSessionStatus.FAILED -> {
                progressDialog.setMessage("FAILED ...")

                var bar = Snackbar.make(mRootView,"$homeModule.name module not installed",Snackbar.LENGTH_INDEFINITE)
                bar.setAction("Install") {
                    startModuleInstall()
                    bar.dismiss()
                }
                bar.show()
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = AuthLoginFragmentBinding.inflate(inflater, container, false);

        mRootView = binding.rootView

        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        //
        (requireView().parent as View).setBackgroundColor(resources.getColor(android.R.color.transparent))

        val data = viewModel.getUserName()


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mRootView.setOnClickListener {
            val inputMethodManager = context?.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager?.hideSoftInputFromWindow(it.windowToken, 0)
        }
        binding.clientSecret.setText("77lsHJP2pxVJZpXBsLWDnfRFnzvmDiTdhbxf8gzD6kvo3WQCKJW3Dnn")
        binding.clientId.setText("3szgpupeqUCKJXdRQzoXQ")

        binding.closeButton.setOnClickListener {

            dismiss()
        }

        binding.loginButton.setOnClickListener {
            progressDialog = ProgressDialog(requireContext())
            //
            if (splitInstallManager.installedModules.contains(homeModule.name)) {
                progressDialog.isIndeterminate = false
                showFeatureModule(homeModule)
            }else {
                startModuleInstall()
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(BottomSheetDialogFragment.STYLE_NORMAL, com.ekenya.rnd.android.common.R.style.BottomSheetTheme)

    }


    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialog = super.onCreateDialog(savedInstanceState)
        //
        return dialog
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {

        }
        //
    }

    override fun onActivityResult( requestCode: Int, resultCode: Int, data: Intent? ) {
        if (resultCode === Activity.RESULT_OK) {
            when (requestCode) {

            }
        } else {
            //Log.w(TAG, "Warning: activity result not ok")
        }
    }

    private fun startModuleInstall(){

        val request = SplitInstallRequest
            .newBuilder()
            .addModule(homeModule.name)
            .build()

        splitInstallManager.startInstall(request)
        progressDialog.isIndeterminate = true
        progressDialog.setMessage("Start install for $homeModule.name")
    }
    /**
     *
     */
    private fun showFeatureModule(module: FeatureModule)
    {
        //Validate
        val name = binding.name.text.toString()
        if(name.isNullOrEmpty()){
            binding.name.error = "This field is required"
            return
        }
        val email = binding.email.text.toString()
        if(email.isNullOrEmpty()){
            binding.email.error = "This field is required"
            return
        }
        val phone = binding.phone.text.toString()
        if(phone.isNullOrEmpty()){
            binding.phone.error = "This field is required"
            return
        }
        val cid = binding.clientId.text.toString()
        if(cid.isNullOrEmpty()){
            binding.clientId.error = "This field is required"
            return
        }
        val csec = binding.clientSecret.text.toString()
        if(csec.isNullOrEmpty()){
            binding.clientSecret.error = "This field is required"
            return
        }
        mAppRepo.getUsers().observeForever(object :Observer<List<UserAccount>>{
            override fun onChanged(list: List<UserAccount>?) {
                //Save user details
                CoroutineScope(Dispatchers.IO).async {
                    //Clear all other user accounts
                    mAppRepo.getUsers().value?.let {
                        for (u in it){
                            mAppRepo.deleteUser(u)
                        }
                    }
                    //Insert user
                    var usr = UserAccount(email,name,email,phone,"","user")
                    usr.qssClientId = cid//"3szgpupeqUCKJXdRQzoXQ"
                    usr.qssClientSecret = csec//"77lsHJP2pxVJZpXBsLWDnfRFnzvmDiTdhbxf8gzD6kvo3WQCKJW3Dnn"
                    mAppRepo.addUser(usr)
                    Log.i(TAG,"Client ID = $cid")
                }
                mAppRepo.getUsers().removeObserver(this)

                try {
                    //Inject
                    (requireActivity().application as DemoApplication)!!.addModuleInjector(module)
                    //
                    //val tag = "loginFragment"
                    //
                    //val fragment = supportFragmentManager.findFragmentByTag(tag) as? BottomSheetDialogFragment ?:
                    //FragmentHelperKt.newFragment(Fragments.FeatureIdentity.INSTANCE) as BottomSheetDialogFragment

                    //
                    //fragment.show(supportFragmentManager, tag)
                    //supportFragmentManager.beginTransaction().replace(R.id.fragment_container,fragment).commit()

                    var intent  = ActivityHelperKt.intentTo(requireActivity(), module as AddressableActivity)
                    //
                    //intent.action = action
                    startActivity(intent)
                    //
                    activity?.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                } catch (e: Exception) {
                    e.message?.let { Log.d("AuthModule", it) };
                }finally {
                    //
                    dismiss()
                }
            }
        })


    }
    override fun onResume() {
        super.onResume()
        splitInstallManager.registerListener(listener)
    }

    override fun onPause() {
        splitInstallManager.unregisterListener(listener)
        super.onPause()
    }
}