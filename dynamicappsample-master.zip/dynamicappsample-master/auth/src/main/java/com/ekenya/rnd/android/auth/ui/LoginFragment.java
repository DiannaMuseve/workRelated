package com.ekenya.rnd.android.auth.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;

import com.ekenya.rnd.android.auth.databinding.AuthLoginFragmentBinding;
import com.ekenya.rnd.android.common.abstractions.BaseDaggerFragment;

import org.jetbrains.annotations.NotNull;

import javax.inject.Inject;

public class LoginFragment extends BaseDaggerFragment {

    private AuthLoginFragmentBinding binding;
    @Inject
    public ViewModelProvider.Factory viewModelFactory;
    private LoginViewModel viewModel;

    private View mRootView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, viewModelFactory).get(LoginViewModel.class);
    }

    @Override
    public void onActivityCreated(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        binding = AuthLoginFragmentBinding.inflate(inflater, container, false);

        mRootView = binding.rootView;


        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull @NotNull View view, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel.getUserName().observe(this, new Observer<String>() {
            @Override
            public void onChanged(String s) {

                viewModel.getUserName().removeObserver(this);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
