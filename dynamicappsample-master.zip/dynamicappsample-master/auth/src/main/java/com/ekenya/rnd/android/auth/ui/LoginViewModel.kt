package com.ekenya.rnd.android.auth.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import com.ekenya.rnd.android.common.repo.IAppRepo
import javax.inject.Inject

class LoginViewModel @Inject constructor(
    private val IAppRepo: IAppRepo,
    private val app:Application
) : AndroidViewModel(app) {
    //
    fun getUserName(): LiveData<String> {
        return IAppRepo.getUsers().switchMap {
            val p = MutableLiveData<String>()
            p.value = it[0].name
            p
        }
    }
}
