package com.ekenya.rnd.android.auth.di.injectables

import androidx.lifecycle.ViewModel
import com.ekenya.rnd.android.auth.ui.LoginDialogFragment
import com.ekenya.rnd.android.auth.ui.LoginFragment
import com.ekenya.rnd.android.auth.ui.LoginViewModel
import com.ekenya.rnd.android.mobile.di.ViewModelKey
import dagger.Binds
import dagger.Module
import dagger.android.ContributesAndroidInjector
import dagger.multibindings.IntoMap

@Module
abstract class AuthFragmentModule {

    @ContributesAndroidInjector(modules = [LoginDialogFragmentModule::class])
    abstract fun contributeLoginDialogFragment(): LoginDialogFragment

    @Module
    abstract class LoginDialogFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(LoginViewModel::class)
        abstract fun bindLoginViewModel(viewModel: LoginViewModel): ViewModel
    }

    @ContributesAndroidInjector(modules = [LoginFragmentModule::class])
    abstract fun contributeLoginFragment(): LoginFragment

    @Module
    abstract class LoginFragmentModule {
        @Binds
        @IntoMap
        @ViewModelKey(LoginViewModel::class)
        abstract fun bindLoginViewModel(viewModel: LoginViewModel): ViewModel
    }

}
