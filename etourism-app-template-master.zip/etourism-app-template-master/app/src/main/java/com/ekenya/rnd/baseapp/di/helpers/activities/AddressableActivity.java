package com.ekenya.rnd.baseapp.di.helpers.activities;

public interface AddressableActivity {
    String getClassName();
}
// ActivityHelperKt.java

