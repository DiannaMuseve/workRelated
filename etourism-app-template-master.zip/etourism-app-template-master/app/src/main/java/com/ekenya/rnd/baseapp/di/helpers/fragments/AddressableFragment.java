package com.ekenya.rnd.baseapp.di.helpers.fragments;

import org.jetbrains.annotations.NotNull;

// AddressableFragment.java
public interface AddressableFragment {
    @NotNull
    String getClassName();
}
