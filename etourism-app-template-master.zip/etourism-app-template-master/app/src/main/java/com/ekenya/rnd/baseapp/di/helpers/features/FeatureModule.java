package com.ekenya.rnd.baseapp.di.helpers.features;

public interface FeatureModule {

    String getName();

    String getInjectorName();
}
