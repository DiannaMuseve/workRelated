package com.ekenya.rnd.common.repo;

public interface SampleRepository {
    String getData();
}
