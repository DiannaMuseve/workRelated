package com.ekenya.rnd.common.abstractions;

import com.google.android.play.core.splitcompat.SplitCompatApplication;

/**
 * Created by Bourne Koloh on 17 March,2021.
 * Eclectics International, Products and R&D
 * PROJECT: Dynamic Modules Sample
 */
public abstract class BaseApplication extends SplitCompatApplication {
    @Override
    public void onCreate() {
        super.onCreate();
        //
    }
}
